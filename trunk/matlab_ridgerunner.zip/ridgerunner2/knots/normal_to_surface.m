function [N]=normal_to_surface(f,v,delta);
% [N]=normal_to_surface_at_endpoints(f,v,delta);
% this function computes vectors normal to the surface z=f(x,y) 
% at the point v by constructing the grid of size delta around v
% delta allows to control the accuracy
x=[v(1)-delta v(1) v(1)+delta];
y=[v(2)-delta v(2) v(2)+delta];
[X,Y]=meshgrid(x,y);
Z=feval(f,X,Y);
[Nx,Ny,Nz]=surfnorm(X,Y,Z);
N=[Nx(2) Ny(2) Nz(2)];
