function [saveas_file_name,movie_file_name]=GraphicalUserInterface_Knots;

% [current_ode_solver,saveas_file_name,movie_file_name]=GraphicalUserInterface_Knots;
% First, we setup some global variables

global numcomp;
global GLOB_HANDLES;
global verts;
global GLOB_FVDATA;

global GLOB_FVCALLS;
global GLOB_UGCALLS;

% We have some debugging globals, as well.

global GLOB_CONFIGS;

%We initialize the original data. 

verts = [];
GLOB_STOP = 0;
GLOB_FVCALLS = 0;
GLOB_UGCALLS = 0;
GLOB_CONFIGS = {};

% Define GUI window

   GLOB_HANDLES.gui_figure=figure('Units','characters','Position',[14 22 112 32.3077],'IntegerHandle','off',...
    'MenuBar','none','Name','Knots','Tag','Knots_figure','Color',[0.8 0.8 0.8],'NumberTitle','off');

% Define uicontols

% Checkboxes
    GLOB_HANDLES.tubes=uicontrol('Style','checkbox','String','Tubes','Foregroundcolor',[0 0 0],...
    'Tag','Tubes','Tooltipstring','Display polygons only','Units','normalized',...
    'Position',[0.84 0.9 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'CallBack','updategraphics('''',verts,'''')');

    GLOB_HANDLES.vector_field=uicontrol('Style','checkbox','String','Vector Field','Foregroundcolor',[0 0 0],...
    'Tag','Vector Field','Tooltipstring','Display vector field','Units','normalized',...
    'Position',[0.84 0.82 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'CallBack','updategraphics('''',verts,'''')');

    GLOB_HANDLES.curves=uicontrol('Style','checkbox','String','Curves','Foregroundcolor',[0 0 0],...
    'Tag','Curves','Tooltipstring','Display curves','Units','normalized',...
    'Position',[0.84 0.74 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'CallBack','updategraphics('''',verts,'''')');

    GLOB_HANDLES.struts=uicontrol('Style','checkbox','String','Struts','Foregroundcolor',[0 0 0],...
    'Tag','Struts','Tooltipstring','Display struts','Units','normalized',...
    'Position',[0.84 0.66 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'CallBack','updategraphics('''',verts,'''')');

    GLOB_HANDLES.constraints=uicontrol('Style','checkbox','String','Constraints','Foregroundcolor',[0 0 0],...
    'Tag','Constraints','Tooltipstring','Display constraints','Units','normalized',...
    'Position',[0.84 0.58 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'CallBack','updategraphics('''',verts,'''')');

    GLOB_HANDLES.showgraph=uicontrol('Style','checkbox','String','Show Graph','Foregroundcolor',[0 0 0],...
    'Tag','Show Graph','Tooltipstring','Graph length over time','Units','normalized',...
    'Position',[0.84 0.26 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'CallBack','showgraphcallback');

    GLOB_HANDLES.record=uicontrol('Style','checkbox','String','Record','Foregroundcolor',[0 0 0],...
    'Tag','Record','Tooltipstring','Record movie frames','Units','normalized',...
    'Position',[0.84 0.18 .14 .06],'callback','recordcallback','BackgroundColor',[0.8 0.8 0.8]);

% Pushbuttons

    GLOB_HANDLES.go=uicontrol('Style','pushbutton','String','GO','Foregroundcolor',[0 0 0],...
    'Tag','GO','Tooltipstring','Start simulation','Units','normalized',...
    'Position',[0.84 0.5 .14 .06],'callback','gocallback','BackgroundColor',[0.8 0.8 0.8],...
    'Interruptible','On');

    GLOB_HANDLES.stop=uicontrol('Style','togglebutton','String','STOP','Foregroundcolor',[0 0 0],...
    'Tag','STOP','Tooltipstring','Pause simulation','Units','normalized',...
    'Position',[0.84 0.42 .14 .06],'BackgroundColor',[0.8 0.8 0.8]);

    GLOB_HANDLES.clear=uicontrol('Style','pushbutton','String','CLEAR','Foregroundcolor',[0 0 0],...
    'Tag','CLEAR','Tooltipstring','Clear figure','Units','normalized',...
    'Position',[0.84 0.34 .14 .06],'callback','clearcallback','BackgroundColor',[0.8 0.8 0.8]);
    
    GLOB_HANDLES.spin=uicontrol('Style','pushbutton','String','Spin','Foregroundcolor',[0 0 0],...
    'Tag','SPIN','Tooltipstring','Spin the picture','Units','normalized',...
    'Position',[0.84 0.1 .14 .06],'callback','spincallback','BackgroundColor',[0.8 0.8 0.8]);


% Static text

    GLOB_HANDLES.filename_text=uicontrol('Style','text','String','Input Filename','Foregroundcolor',[0 0 0],...
    'Tag','InputFilename','Units','normalized',...
    'Position',[0.84 0.1 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'Visible','off');

% Editible text

    GLOB_HANDLES.filename_edit_text=uicontrol('Style','edit','String','Movie_1','Foregroundcolor',[0 0 0],...
    'Tag','EditFileName','Tooltipstring','Specify file of record','Units','normalized',...
    'Position',[0.84 0.05 .14 .06],'callback','editfilenamecallback','BackgroundColor',[1 1 1],'Visible','off');

% Define axes

    GLOB_HANDLES.picture_main=axes('Tag','Picture Main','Units','normalized',...
    'Position',[0.04 0.05 .75 .93]);


% Define uimenu

    GLOB_HANDLES.menu_file=uimenu(GLOB_HANDLES.gui_figure,'Label','File','Tag','File');

        GLOB_HANDLES.menu_file_open=uimenu(GLOB_HANDLES.menu_file,'Label','Open','Tag','Open','Callback','opencallback');
            
        GLOB_HANDLES.menu_file_save=uimenu(GLOB_HANDLES.menu_file,'Label','Save','Tag','Save','Callback','savecallback');
        
        GLOB_HANDLES.menu_file_save_as=uimenu(GLOB_HANDLES.menu_file,'Label','Save as','Tag','Saveas','Callback','saveascallback');
        
        GLOB_HANDLES.menu_file_import=uimenu(GLOB_HANDLES.menu_file,'Label','Import','Tag','Import','Callback','importcallback');
        
        GLOB_HANDLES.menu_file_export=uimenu(GLOB_HANDLES.menu_file,'Label','Export','Tag','Export','Callback','exportcallback');


    GLOB_HANDLES.menu_edit=uimenu(GLOB_HANDLES.gui_figure,'Label','Edit','Tag','Edit');

        GLOB_HANDLES.menu_edit_properties=uimenu(GLOB_HANDLES.menu_edit,'Label','Data properties','Tag','DataProperties','Callback','datapropertiescallback');
        
        GLOB_HANDLES.menu_edit_constraints=uimenu(GLOB_HANDLES.menu_edit,'Label','Constraints','Tag','Constraints','Callback','editconstraints');
                
        
% Initialize

saveas_file_name=[];
GLOB_HANDLES.picture_length_time=-1;
movie_file_name=[];
numcomp=0;


% We now setup some standard graphics options.

set(GLOB_HANDLES.picture_main,'DataAspectRatio',[1 1 1]);
camproj(GLOB_HANDLES.picture_main,'perspective');
lighting gouraud;
set(GLOB_HANDLES.gui_figure,'Renderer','OpenGL');

   
   