 function V=adjust(i,V,f);
 % given a list of vertices V size (number of vertices, 3) and an index i to it
 % adjust if needed the coordinates of a point V(i,:) to satisfy z=f(x,y)
 z=f(V(i,1),V(i,2));
 V(i,3)=z;