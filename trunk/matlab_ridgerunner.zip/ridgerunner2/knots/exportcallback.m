% exportcallback

[export_file_name,export_path_name]=uiputfile('*.vect','EXPORT FILE',100,100);
fid = fopen(export_file_name,'w');

% first line 

fprintf(fid,'%s\n','VECT');
[l,k]=size(verts);

p=[numcomp l/3 numcomp];
fprintf(fid,'%d %d %d\n',p);
compstart=1;
for i=1:numcomp
    compend=link.endpoints(i);
    p=compend-compstart+1;
    if strcmpi('closed',link.closed(i))
        p=-p;
    end;
    fprintf(fid,'%d',p);
    compstart=compend+1;
end;
fprintf(fid,'\n');
for i=1:numcomp
    fprintf(fid,'%d',1);
end;
fprintf(fid,'\n');
for i=1:l/3
    p=[verts(3*(i-1)+[1:3])]';
    fprintf(fid,'%f %f %f\n',p);
end;
for i=1:numcomp
    if strcmpi('Opaque',link.transparency(i))
        ct=1;
    elseif strcmpi('Transparent',link.transparency(i))
        ct=0.5;
    else
        ct=0;
    end;
    p=[link.colorvalues(i,:) ct];
    fprintf(fid,'%f %f %f %f\n',p);
end;
fclose(fid);


 