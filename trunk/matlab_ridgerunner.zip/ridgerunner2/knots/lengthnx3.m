function nv = lengthnx3(v)

% lengthnx3 finds the lengths of an nx3 matrix of vectors in 3-space
%
% Input:  v, an nx3 list of vectors in R^3
%
% Output: nv, an nx1 list of the norms of the result

% Note that zero-length vectors aren't given any special treatment, and
% will show up as NaN's in the results.

nv=sqrt((v(:,1)).^2+(v(:,2)).^2+(v(:,3)).^2);    