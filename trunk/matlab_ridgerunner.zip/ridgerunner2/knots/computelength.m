function NL=computelength(V, link, inComponentIndex );
NL=0;

% This makes the code robust.  Now computelength can handle the vertex matrix in any form.
[rows,cols] = size(V);
if(cols == 1)
  V = reshape(V,3,rows/3)';
end;

if( inComponentIndex == 1 )
    startIndex = 1;
else
    startIndex = link.endpoints(inComponentIndex-1) + 1;
end;

for i=startIndex:link.endpoints(inComponentIndex)-1
  NL=NL+norm(V(i+1,:)-V(i,:),2);
end;

if(strcmp(link.closed(inComponentIndex),'closed') == 1)
  if(inComponentIndex == 1)
    NL = NL + norm(V(link.endpoints(inComponentIndex),:) - V(1,:),2);
  else
    NL = NL + norm(V(link.endpoints(inComponentIndex),:) - V(link.endpoints(inComponentIndex-1)+1,:),2);
  end;
end;
