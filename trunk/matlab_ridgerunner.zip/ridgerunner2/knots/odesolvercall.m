


%
%        a1            axis limits for the 3d display of the link 
%        a2            axis limits for the (optional) graph of ropelength over time 
%        h             list of handles in the following order:
%                            h_picture_main;
%                            h_showgraph;
%                            h_picture_length_time
%                            h_tubes_off; 
%                            h_curves;
%                            h_vector_field;
%                            h_constraints;
%                            h_struts;