% Script testevolution loads up a knot and evolves it.

global numcomp;
global COUNTER;
global GLOB_HANDLES;
global GLOB_STOP;
global GLOB_FVDATA;

[saveas_file_name,movie_file_name]=GraphicalUserInterface_Knots;

[link,verts,dummy] = importmingfile('/home/students/rawdon/ridgerunner2/June2003knots/tref32/3.1.32');
% load overnighttref.160.mat link verts;

set(GLOB_HANDLES.tubes,'Value',1);      % Turn on tubes
set(GLOB_HANDLES.curves,'Value',1);     % Turn on curves
set(GLOB_HANDLES.struts,'Value',1);     % Turn on struts
set(GLOB_HANDLES.vector_field,'Value',0);     % Turn off vector field.

figure(GLOB_HANDLES.gui_figure);

GLOB_FVDATA.link.endpoints       = link.endpoints;
GLOB_FVDATA.link.thickness       = [0.5];
GLOB_FVDATA.link.closed          = link.closed;
GLOB_FVDATA.link.colorvalues     = link.colorvalues;
GLOB_FVDATA.link.edgecolorvalues = link.edgecolorvalues;
GLOB_FVDATA.link.tension         = link.tension;
GLOB_FVDATA.link.constraints     = link.constraints;
GLOB_FVDATA.link.surface         = link.surface;
GLOB_FVDATA.link.transparency    = [0.3];                     % make the tubes very ghostly
      
GLOB_FVDATA.dVdt = [];
GLOB_FVDATA.strutStartPoints = [];
GLOB_FVDATA.strutEndPoints = [];
GLOB_FVDATA.compressions = [];
GLOB_FVDATA.strutField = [];

updategraphics('',verts,'init');

[vfinal] = experimental_rkode_with_bsearch(GLOB_FVDATA.link,verts,1000,0.01)

axis vis3d;
rotate3d;
