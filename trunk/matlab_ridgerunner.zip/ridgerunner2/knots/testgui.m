% Script testgui just runs the GUI.

global numcomp;
global COUNTER;
global GLOB_HANDLES;
global GLOB_STOP;
global GLOB_FVDATA;

[saveas_file_name,movie_file_name]=GraphicalUserInterface_Knots;

set(GLOB_HANDLES.tubes, 'Value',1);    % Turn off tubes
set(GLOB_HANDLES.curves,'Value',1);    % Turn on curves
