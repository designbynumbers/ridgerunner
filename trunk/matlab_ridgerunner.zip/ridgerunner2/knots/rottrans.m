function [M,L]=rottrans(v1,v2,k);
% this function computes the rotational matrix M 
% and the translational matrix L
    M=zeros(3,3);
    L=zeros(3,k);
    e3=(v2-v1)/norm(v2-v1,2);
    if  e3==[1 0 0]
        M=[0 0 1;1 0 0;0 1 0]; 
    elseif e3==[0 1 0]
        M=[0 1 0;0 0 1;1 0 0]; 
    elseif e3==[0 0 1]
        M=[0 1 0;1 0 0;0 0 1]; 
    elseif e3==[0 0 -1]
        M=[0 1 0;1 0 0;0 0 -1]; 
    elseif e3==[0 -1 0]
        M=[0 1 0;0 0 -1;1 0 0]; 
    elseif e3==[-1 0 0]
        M=[0 0 -1;1 0 0;0 1 0]; 
    elseif ~e3(3)==0
        e2=[v1(1) v1(2) (-(v2(1)-v1(1))*v1(1)-(v2(2)-v1(2))*v1(2))/(v2(3)-v1(3))]';   
        if e2==[0 0 0]'
            e2=[v1(1) (-(v2(1)-v1(1))*v1(1)-(v2(3)-v1(3))*v1(3))/(v2(2)-v1(2)) v1(3)]'; 
        end;
        M(:,2)=e2/norm(e2,2);
        M(:,3)=e3'; 
        e1=cross(e2,e3);
        e1=e1/norm(e1,2);
        M(:,1)=e1';    
    elseif ~e3(2)==0
        e2=[v1(1) (-(v2(1)-v1(1))*v1(1)-(v2(3)-v1(3))*v1(3))/(v2(2)-v1(2)) v1(3)]'; 
        if e2==[0 0 0]'
            e2=[(-(v2(2)-v1(2))*v1(2)-(v2(3)-v1(3))*v1(3))/(v2(1)-v1(1)) v1(2) v1(3)]'; 
        end;
        M(:,2)=e2/norm(e2,2);
        M(:,3)=e3'; 
        e1=cross(e2,e3);
        e1=e1/norm(e1,2);
        M(:,1)=e1'; 
     else 
        e2=[(-(v2(2)-v1(2))*v1(2)-(v2(3)-v1(3))*v1(3))/(v2(1)-v1(1)) v1(2) v1(3)]'; 
        M(:,2)=e2/norm(e2,2);
        M(:,3)=e3'; 
        e1=cross(e2,e3);
        e1=e1/norm(e1,2);
        M(:,1)=e1';    
     end;
     L(1,:)=v1(1)*ones(1,k);
     L(2,:)=v1(2)*ones(1,k);
     L(3,:)=v1(3)*ones(1,k);