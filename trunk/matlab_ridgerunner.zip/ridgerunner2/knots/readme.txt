% to start the GUI type in the command line
>> [H,current_ode_solver,saveas_file_name,movie_file_name,numcomp]=GraphicalUserInterface_Knots;

Open or Import datafile. Choose the settings and click 'GO'.

1. The 'Tubes off' checkbox

If not checked before 'GO' is pressed, the plots appear with the cylindrical 
surfaces around the polygons.

2. The 'Vector Field' checkbox
displayes vector field
3. The 'Curves' checkbox
displayes the 'sceleton' - polygons
4. The 'Struts' checkbox
displayes struts

5. The 'Record' checkbox
 records the moviedata in a .mat file
when saved can be retrieved as  
>> load filename.mat
and played as 
>> movie(MOVIEMATRIX)

6. The 'File' menu
Before starting the simulation user must choose a data file, (open or import)
data files include initial values and configurations needed
to solve the problem. Once a file is selected, and selections
for 'Tubes off', 'Curves', 'Struts', 'Record' and 'Vector Field'...
are made proceed with the 'GO'.
7. 'GO' pushbutton starts the simulation and displayes the intermediate
pictures according to the choices made in the checkboxes. Simulation continues
until ('either 'STOP' is pressed or a' - this part is not fixed yet)the specified time interval has ended.
8. 'STOP' pushbutton stops the simulation when pressed.-not working yet
9. 'SHOW GRAPH' displayes the changing values of component lengths
over time.
10. 'CLEAR' is used to clear the picture.

11. Edit data properties allows to change some properties of components

12. ode solvers can be changed. There is an undentified problem with stiff methods: ode15s,and down.