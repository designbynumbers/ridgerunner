%recordcallback
if get(GLOB_HANDLES.record,'Value')==1
    set(GLOB_HANDLES.filename_text,'Visible','on');
    set(GLOB_HANDLES.filename_edit_text,'Visible','on');
end;

if get(GLOB_HANDLES.record,'Value')==0
    set(GLOB_HANDLES.filename_text,'Visible','off');
    set(GLOB_HANDLES.filename_edit_text,'Visible','off');
end;
