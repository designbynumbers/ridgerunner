function NL=computefulllength(V, link);
NL=0;

% This makes the code robust.  Now computelength can handle the vertex matrix in any form.
[rows,cols] = size(V);
if(cols == 1)
  V = reshape(V,3,rows/3)';
end;

[dummy,numcomp] = size(link.endpoints);

% just loop computelength over the components
for i=1:numcomp
  NL = NL + computelength(V,link,i);
end;
