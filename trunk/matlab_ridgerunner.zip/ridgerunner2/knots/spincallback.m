% spincallback
% activate current figure
global GLOB_HANDLES;
figure(GLOB_HANDLES.gui_figure);
% determine axis limits to set the radius of rotation of the camera
p=get(GLOB_HANDLES.picture_main,'Xlim');
u=get(GLOB_HANDLES.picture_main,'YLim');
x0=max(abs(p));y0=max(abs(u));
radius=sqrt(x0^2+y0^2);
% to make the spin shorter reduce the number of steps
numberofsteps=350;
% vertical increament
a=max(get(GLOB_HANDLES.picture_main,'ZLim'));b=min(get(GLOB_HANDLES.picture_main,'ZLim'));
deltaz=(a-b)/numberofsteps;
figure(GLOB_HANDLES.gui_figure);
% compute and set new camera position
% to go around the objest faster decrease 500, or decrease pause
% to look at the object from farther distance increse 1.5
for i=1:numberofsteps
    x=5*radius*cos(i*pi/500);
    y=5*radius*sin(i*pi/500);
    set(GLOB_HANDLES.picture_main,'CameraPosition',[x y b+deltaz]);
    pause(.01);
end;
