function  displaypoly(V,closed,coloring);
% this function drawes a polygon
% with the vertices (all distinct) in V 
% closed ('closed'=1 ) or open ('closed'=0 )

if strcmpi(closed,'closed')
    V=[V;V(1,:)];
end;

plot3(V(:,1),V(:,2),V(:,3),'Color',coloring);
hold on;