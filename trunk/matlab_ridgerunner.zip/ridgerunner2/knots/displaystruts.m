function displaystruts(strutStartPoints, strutEndPoints, compressions);

% FUNCTION displaystruts displays struts, colored by their current compressions.

% Input: strutStartPoints  an nx3 list of start points in 3 space
%        strutEndPoints    an nx3 list of end points in 3 space
%        compressions      an nx1 column vector of weights 

% Output: All goes to the current figure.

hold on;

numStruts = size(strutStartPoints,1);

% First, we rescale the compressions, and generate an array of colors using the HOT colormap.

compressions =  127*(compressions./max(compressions)) + 1;
hotmap       =  hot(128);

% Now we draw the lines

for i=1:numStruts
    
  line([strutStartPoints(i,1)';strutEndPoints(i,1)'],...
       [strutStartPoints(i,2)';strutEndPoints(i,2)'],...
       [strutStartPoints(i,3)';strutEndPoints(i,3)'],'Color',hotmap(round(compressions(i)),:));

end;