function export_vect_to_pipe(link,Verts);

% FUNCTION export_vect_to_pipe exports a picture of the current situation to 
% geomview via the named pipe /tmp/geomview/knotdata. We assume that geomview
% is running, and that it is listening to this pipe.

% This interface allows us to monitor the computation as it's running, using the
% much nicer Geomview 3d interface, rather than the somewhat clunky MATLAB one.

if (nargin ~= 2)
    error('export_vect_to_pipe: expect (link,Verts) as input');
end;

% First, we reshape V for convenience in working with it inside the
% function.  For convenience, if it happens to be a k by 3 matrix,
% we just leave it alone.
%
% We also set n to the number of vertices in V.

[n,k]=size(Verts);

if ( (mod(n,3) == 0) & (k == 1) )
  V=reshape(Verts,3,n/3)';  % This is important! The vector appears
                            % as (x1 y1 z1 x2 y2 z2 ... )'    
  n = n/3;
elseif (k ~= 3)
  error('Feeding a bad vertex set into exportallvect');
else
  V = Verts;
end;

% Next, we compute the weighted first variation of length for this link.

dl = dlen(V,link);
dl = reshape(dl',3*n,1);
  
% Now we call the Mex'ed strutFinder. 
% indices is almost an nx4 array of integers giving the endpoints of the edges involved in each strut 
%    as indices into V (now that V has been reshaped). The problem is that the entries in "indices" refer
%    to the ZERO-based index scheme in C++ used in strutFinder, but here we have ONE-based indexing in MATLAB.

% positions is an nx2 array of doubles between 0 and 1 giving the position along that strut 

[indices positions strutcount badstepflag] = experimentalStrutFinder(Verts,link,[]);
indices = indices + 1; % correct for Cpp's ZERO-based arrays

% Construct the rigidity matrix A. A maps from the strut space to the space of variations
% of vertices, and gives the force at each vertex resulting from a compressive force pushing _out_
% from each strut. 

% If the strut strikes in the middle of an edge, we apply its force to both endpoints of the 
% edge, divided according to the position of the end of the strut along the edge.

% Each row of A corresponds to a single component of a single _vertex_ of the overall picture.
% The entries in the row corresponding to each strut that pushes on the vertex are that component 
% of the unit vector pointing _out_ from that strut's endpoint at the edge incident to the
% given vertex.

if (strutcount > 0) 
    
  A = zeros(3*n,strutcount);
  
  % The first step is to construct a matrix of strut directions.
  
  strutStartPoints = (1 - repmat(positions(:,1),1,3))  .* V(indices(:,1),:) + repmat(positions(:,1),1,3) .* V(indices(:,2),:);
  strutEndPoints   = (1 - repmat(positions(:,2),1,3))  .* V(indices(:,3),:) + repmat(positions(:,2),1,3) .* V(indices(:,4),:);
  
  % We now make sure that these struts pass self-testing.
  %
  if (strut_test_suite(V,link,strutStartPoints,strutEndPoints,positions,indices,0.1) ~= 1)
    
    sprintf('strut test suite failure causes firstvariation to fail')
    sprintf('but we are in exportallvect, so it does not matter too much')
    dVdt = zeros(size(Verts));
    
    return;
    
    end;
  
  % And continue building the rigidity matrix A.
  
  strutDirections  = normalizenx3(strutStartPoints - strutEndPoints);
  strutLengths     = lengthnx3(strutStartPoints - strutEndPoints);
  
  % We now assign the strutDirections to the matrix A. 
  
  for i = 1:strutcount 
    
    % These are the rows of A corresponding to
    % vertex V(indices(i,1),:).
    
    % |||||||||||||||||||||||||||||||
    % vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
    
    A(3*indices(i,1)-2:3*indices(i,1),i) =                        (1-positions(i,1))*strutDirections(i,:)';
    
    %                                                              ^^^^^^^^^^^^^^^   ^^^^^^^^^^^^^^^^^^^^
    %                                                                      |                 |
    %                                                fraction assigned to this end    force vector from strut
    %                                                                                 this is a row vector, so we
    %                                                                                 transpose it to match the 
    %                                                                                 column vector we are filling
    %                                                                                 on the left hand side
    
    A(3*indices(i,2)-2:3*indices(i,2),i) =                         positions(i,1) *strutDirections(i,:)';
    
    
    %                               On the other end of the strut, the direction
    %                               of force is reversed. Hence the extra minus signs.
    %                                                             |
    %                                                             V
    
    A(3*indices(i,3)-2:3*indices(i,3),i) =                     -(1-positions(i,2))*strutDirections(i,:)';
    A(3*indices(i,4)-2:3*indices(i,4),i) =                        -positions(i,2) *strutDirections(i,:)';
    
    %                                                             ^
    %                                                             |
    
  end;    
  
  % We now try to cancel as much of the motion as possible with strut forces. 
  % This involves finding the best nonnegative partial solution to the system 
  %
  %                               AX = -dl. 
  %
  % Of course, we can't solve this equation in general (unless the knot is critical!)
  % so we settle for the closest partial solution in a least-squares sense. We use
  % the sparse matrix package SLS from http://www.mai.liu.se/~milun/sls/ by Pontus 
  % Matstoms to solve the linear algebra problem, since the matrix A is extremely sparse.
  
  spA = sparse(A);
  compressions = lsqnonneg(spA,-dl);
  
  % We then cancel this from dl to find the first variation of ropelength. However, here 
  % there is a subtlety. If all the struts are the correct lengths (2.0), then this is 
  % exactly what happens. However, if some of the struts are too long or too short, we 
  % impose a physics-based penalty function to allow long struts to shrink and encourage
  % short ones to expand: 
  
  % We scale the values of compressions by the corresponding pad function padf.
  
  % This function is somewhat less than one for struts that are extra long, and approaches
  % infinity for very short struts. We hope that this will prevent the tube overrun problem:
  % for overlarge stepsizes, we'll detect a short strut and produce a correspondingly large
  % restoring force. In a just world, this will cause ode45 to fail its numerical quality 
  % tests.
  
  % Note that padf is expected to be "vectorized"; it both expects and return a vector.
  
  dVdt = dl + A*(compressions);
  strutField = A*compressions;
  
else 
  
  dVdt = dl;
  
  strutStartPoints = [];
  strutEndPoints = [];
  compressions = [];
  strutField = [];
  
  badstepflag = 0;
  
end;

% Now we export the resulting geometry to Geomview in embedded '(geometry' format.

reshapeddl = reshape(dl,3,n)';
reshapeddVdt = reshape(dVdt,3,n)';

% Make sure the center of mass of V is at the origin.
center = mean(V);
V = V - repmat(center,n,1);

% Everything is set up, just need to write the files.

fid = fopen('/tmp/geomview/knotdata','w');
[dummy,numcomp] = size(link.endpoints);

% First, we set up a list to contain all the OOGL objects which follow.

fprintf(fid,'(geometry knotdata {LIST {');

% Now we output the actual knot. 

fprintf(fid,'%s\n','VECT');

p=[numcomp n numcomp];
fprintf(fid,'%d %d %d\n',p);

compstart=1;
compend=link.endpoints(1);
p=compend;
if strcmpi('closed',link.closed(1))
  p=-p;
end;
fprintf(fid,'%d',p);

compstart = compend + 1;

for i=2:numcomp
  compend=link.endpoints(i);
  p=compend-compstart+1;
  if strcmpi('closed',link.closed(i))
    p=-p;
  end;
  fprintf(fid,' %d',p);
  compstart=compend+1;
end;
fprintf(fid,'\n');

fprintf(fid,'%d',1);
for i=2:numcomp
  fprintf(fid,' %d',1);
end;
fprintf(fid,'\n');

for i=1:n
  fprintf(fid,'%f %f %f\n',V(i,:));
end;
for i=1:numcomp
  if strcmpi('Opaque',link.transparency(i))
    ct=1;
  elseif strcmpi('Transparent',link.transparency(i))
    ct=0.5;
  else
    ct=0;
  end;
  p=[link.colorvalues{i,:} ct];
  fprintf(fid,'%f %f %f %f\n',p);
end;

fprintf(fid,'}');

% Second, we save the struts in VECT format
% The file is empty if there aren't any struts

if(strutcount ~= 0)
    
  fprintf(fid,'{');
    
  fprintf(fid,'%s\n','VECT');
  fprintf(fid,'%d %d 1\n',strutcount,2*strutcount);

  fprintf(fid,'2');
  for i=2:strutcount
    fprintf(fid,' 2');
  end;
  fprintf(fid,'\n');
  
  fprintf(fid,'1');
  for i=2:strutcount
    fprintf(fid,' 0');
  end;
  fprintf(fid,'\n');
  
  for i=1:strutcount
    fprintf(fid,'%f %f %f\n',strutStartPoints(i,:)-center(1,:));
    fprintf(fid,'%f %f %f\n',strutEndPoints(i,:)-center(1,:));
  end;
  
  % Honeydew
  fprintf(fid,'0.9735,0.9961,0.9735,0\n');
  fprintf(fid,'}');
  
end; 

% Next up, elastaforce (ie dl)

fprintf(fid,'{ VECT\n');
fprintf(fid,'%d %d 1\n',n,2*n);

fprintf(fid,'2');
for i=2:n
  fprintf(fid,' 2');
end;
fprintf(fid,'\n');

fprintf(fid,'1');
for i=2:n
  fprintf(fid,' 0');
end;
fprintf(fid,'\n');

for i=1:n
  fprintf(fid,'%f %f %f\n',V(i,:));
  fprintf(fid,'%f %f %f\n',V(i,:)+reshapeddl(i,:));
end;

% Deep sky blue
fprintf(fid,'0,0.7461,0.9661,0\n');
fprintf(fid,'}');


% Next up, resolved dVdt, shown in burlywood

fprintf(fid,'{ VECT\n');
fprintf(fid,'%d %d 1\n',n,2*n);

fprintf(fid,'2');
for i=2:n
  fprintf(fid,' 2');
end;
fprintf(fid,'\n');

fprintf(fid,'1');
for i=2:n
  fprintf(fid,' 0');
end;
fprintf(fid,'\n');

for i=1:n
  fprintf(fid,'%f %f %f\n',V(i,:));
  fprintf(fid,'%f %f %f\n',V(i,:)+reshapeddVdt(i,:));
end;

% Burlywood
fprintf(fid,'0.9661,0.3867,0.2773,0\n');
fprintf(fid,'} } )');
fclose(fid);
