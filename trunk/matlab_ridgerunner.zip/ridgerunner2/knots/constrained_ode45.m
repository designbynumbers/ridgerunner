function varargout = constrained_ode45(ode,tspan,y0,options,varargin)

%   CONSTRAINED_ODE45  Solve non-stiff differential equations, medium order method.

%   This procedure uses a modification of the ODE45 method given in MATLAB to 
%   carefully and (hopefully) correctly handle a problem 
%
%                  y' = f(y)
%
%   where y is discontinuous in the space variables. To do so, we use a mix of 
%   traditional and new methods. Our method may probably be compared to that of
%   Stewart; we also use a version of Brent's search algorithm, but are satisfied
%   with fourth-order Runge-Kutta rather than requiring arbitrary order (as in the
%   Gear's method solver in his program). We also do not need the linear programming
%   information as we are signalled explicitly by ODEFUN when we change regimes.

%   The basic algorithm goes as follows:

%   1. Attempt a Runge-Kutta step with a provided strut set.

%   2. Compare the new strut set with the old one. If they differ, we mix methods
%      and do a Brent's method search for the "last" stepsize at which the old strut
%      set is active. However, during this search, we ALSO pay attention to the 
%      "ordinary" numerical quality of the result. We are sure to cache the closest
%      failing strut set as well.

%      (If they are the same, we pay attention only to numerical quality.)

%   3. Take the largest step which passes both the numerical quality test AND the 
%      consistent strut set test. 

%   4. If the final stepsize was chosen by the CSS test, we restart Runge-Kutta 
%      using the closest CACHED strut set (and NOT the strut set actually returned 
%      by strutfinder) to start our RK method. 


