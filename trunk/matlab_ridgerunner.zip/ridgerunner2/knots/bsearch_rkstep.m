function  [Vfinal,ss_did,ss_next]=bsearch_rkstep(link,verts,dVdt,ss_try,err_bound,indices)

% FUNCTION BSEARCH_RKSTEP takes a RK integration step, attempting to either take a 
% step of size ss_try, or to take the last PASSING step disovered in an 8 iteration 
% bsearch of the interval [0..ss_try].
%
% We return the stepsize that was actually accomplished (ss_did), the new position
% (verts), and our recommendation for the next stepsize (ss_next).

PGROW = -0.20;
PSHRINK = -0.25;
FCOR = 1/15.0;
SAFETY = 0.9;
ERRCON = 6.0e-4;

[Vfinal,err,badstep] = experimental_qcrkstep(link,verts,dVdt,ss_try,err_bound,indices);        
        
if (badstep == 0) % The biggest step passed...
    
    ss_did = ss_try;
    
    if (err > ERRCON) 
        
       ss_next = SAFETY*ss_try*exp(PGROW*log(err));
       
   else
       
       ss_next = 4*ss_try;
       
   end;
   
   return; 
   
end;

%% We now search for the last PASSING step, starting with a trial stepsize of ss_try/2.0.
%% Recall that badstep takes the return values:

%                0  -  if the step is good (not bad)
%                1  -  failed due to new struts
%                2  -  failed due to ODE numerical error
%                3  -  failed due to self-intersection 

pos = ss_try/2.0;
step = ss_try/4.0;

% Now initialize the "last passed" cache to pos = 0 (the initial calling position) in case 
% NONE of the bsearch steps pass and we are forced to fall back on the original position.

Vcache = verts;
poscache = 0;
badstepcache = badstep;

for i=1:8             % Notice that we can tune the "8" to get more or less accuracy.
     
    [Vfinal,err,badstep] = experimental_qcrkstep(link,verts,dVdt,pos,err_bound,indices);     

    if (badstep ~= 0) % We FAILED; try to shrink the position. 
        
        badstepcache = badstep;
        pos = pos - step;
        
    else % We PASSED; try to advance the position (looking for a fail)
        
        Vcache = Vfinal;
        poscache = pos;
        
        pos = pos + step;
        
    end;
    
    step = step/2.0;
    
end;

if (badstep ~= 0)        % Our last position was a fail; fall back to the last pass. 
    
    Vfinal = Vcache;
   
end;

ss_did = poscache;       % This is the position at the last pass regardless of when that pass happened. 

% If the last step died because of a discontinuity, we now make a "microstep" to carry us
% over the singularity. This will introduce O(h^2) error into the solution, but it's basically
% unavoidable.The fact that our step is less than 1/256 of the previous step size helps control
% the error.

if (badstepcache == 1 | badstepcache == 3) 

    [dVdt, badstep, newindices] = experimentalFirstvariation(link,Vfinal,indices);
    
    [newV, badstep]             = attempt_rkstep(link,Vfinal,4.0*step,indices,dVdt); % RK step
    Vfinal                      = Vfinal + 4.0*step*dVdt;  % Euler step.
    
    % For debugging purposes, we make sure that this fails.
    
    [dVdt, badstep, newindices] = experimentalFirstvariation(link,Vfinal,indices);
    
    if (badstep == 1)     
        
        sprintf('Passed microstep of size %g.',4.0*step)
        ss_did = ss_did + 4.0*step;
            
    elseif (badstep == 3) 
        
        % error('Failed due to self-intersection.');
        
    else
        
        % error('Microstep failed to pass singularity.');
        
    end;
            
end;

%% We now report our results. 
        
if (err > ERRCON) 
        
    ss_next = SAFETY*ss_try*exp(PGROW*log(err));
       
else
       
    ss_next = 4*ss_try; 
       
end;
   