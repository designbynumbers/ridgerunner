function pf = padf(lengths)

% padf: finds scale factors corresponding to the nx1 array of strut lengths in lengths
%
% Input:  lengths, an nx1 vector of strut lengths
%
% Output: pf, an nx1 vector of result scale factors

% Note that zero-length vectors aren't given any special treatment, and
% will show up as NaN's in the results. This is all kind of a hack, but it
% seems to correspond to reasonable struts between 1.99 and 2.01.

global GLOB_FVDATA;

pf = min(1000,(2*GLOB_FVDATA.link.thickness./lengths).^256);

if (max(pf) == 1000) 
    
    'I got to 1000'
    
end;

%pf = zeros(size(lengths));

%for i=1:size(lengths,1)

 %  if (lengths(i,1) < 0.9) 
       
  %     padf(i,1) = 1001;
       
  % else
       
  %     padf(i,1) = 1 + 10000*(1 - lengths(i,1));
       
  %end;
   
  %end;