% editconstraintscallback1
global GLOB_FVDATA;
global GLOB_HANDLES;
for i=1:numcomp 
u1=get(GLOB_HANDLES.edit_component_constraint_ept2(i),'Value');
if u1==1
    GLOB_FVDATA.link.constraintsend{i}='none';
elseif u1==2
    GLOB_FVDATA.link.constraintsend{i}='fixed';
elseif u1==3
    GLOB_FVDATA.link.constraintsend{i}='surface';
    open('UserDefinedConstraints2.m');
end;
end;
        
  