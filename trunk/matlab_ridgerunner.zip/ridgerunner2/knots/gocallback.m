%  gocallback

global MOVIEMATRIX;
global COMPONENTLENGTH;
global TIME;
global COUNTER;

MOVIEMATRIX=[];
COUNTER=0;
COMPONENTLENGTH=[];
TIME=[];

% activate gui figure

figure(GLOB_HANDLES.gui_figure);

% set the timespan to something reasonable to save user's time.

timespan=[0 15];
ax2=timespan;

% call odeset to set integration parameters.

options = odeset('OutputFcn',@updategraphics,'Stats','on','RelTol',1e-2,'Refine',1);

% start integration of dV/dt=firstvariation(t,V,'',...)

[T,Y] = ode45(@firstvariation,timespan,verts,options);

% The solution at various times T is now recorded in Y. We update verts accordingly.

verts = Y(size(Y,1),:)';

% We now take care of the movie recording stuff.

if get(GLOB_HANDLES.record,'Value')==1
    save(movie_file_name,'MOVIEMATRIX');
end;
if get(GLOB_HANDLES.showgraph,'Value')==1
    
    axes(GLOB_HANDLES.picture_length_time);
    for i=1:numcomp
        plot(TIME,COMPONENTLENGTH(:,i),'Color',link.colorvalues(i,:));
        hold on;
    end;
    set(GLOB_HANDLES.picture_length_time,'Xlim',ax2);
    
end;

helpdlg('Integration has stopped.','Results');

% Last, make sure that the stop toggle is reset.

set(GLOB_HANDLES.stop,'Value',0);  
    
        