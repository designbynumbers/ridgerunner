%editcolorcallback
for i=1:numcomp
  
    r=str2num(char(get(GLOB_HANDLES.edit_component_color_value_r(i),'String')));
    g=str2num(char(get(GLOB_HANDLES.edit_component_color_value_g(i),'String')));
    b=str2num(char(get(GLOB_HANDLES.edit_component_color_value_b(i),'String')));
    
    GLOB_FVDATA.link.colorvalues{i} = [r g b];
    set(GLOB_HANDLES.component_color(i),'BackgroundColor',[r g b]);
    
    % We need to reset the edge colorvalues as well.
    
    hsv = rgb2hsv([r g b]);
    hsv(3) = 1 - hsv(3);
    GLOB_FVDATA.link.edgecolorvalues{i} = hsv2rgb(hsv);
    
    % Now we make the changes visible.
    
    updategraphics('',verts,'');
    
end;
