function z=UserDefinedConstraints2(x,y);
% Use the standart Matlab syntax for vectors to define z as a function of x and y.
% Default
z=x+y;