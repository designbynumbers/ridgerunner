function  [verts,ss_did,ss_next]=experimental_rkstep(link,verts,dVdt,ss_try,err_bound,indices)

% FUNCTION EXPERIMENTAL_RKSTEP takes a RK integration step, where the stepsize is 
% bounded BOTH by the usual measure of numerical quality (err_bound), and by the 
% requirement that we not overstep a discontinuity in firstvariation by more than 
% ss_try/256.
%
% We return the stepsize that was actually accomplished (ss_did), the new position
% (verts), and our recommendation for the next stepsize (ss_next).

PGROW = -0.20;
PSHRINK = -0.25;
FCOR = 1/15.0;
SAFETY = 0.9;
ERRCON = 6.0e-4;

vertsSave = verts;
dVdtSave = dVdt;
h = ss_try;

% We now start looping to find an acceptable step.

for 
    
    badstep = zeros(3);
    
    [Vtemp,badstep(1)] = attempt_rkstep(link,vertsSave,h/2.0,indices,dVdtSave);   % We try a half-step.
    [dVdt, badstep(2),newindices] = experimentalFirstvariation(Vtemp,indices);    % Get another derivative 
    [verts,badstep(2)] = attempt_rkstep(link,Vtemp,h/2.0,indices,dVdt);           % And half-step again.
     
    [Vtemp,badstep(3)] = attempt_rkstep(link,vertsSave,h,indices,dVdtsave);       % Here is the FULL step.
    
    % We now compare the results of the full step with the results of the two half-steps.
    
    errvector = verts - Vtemp; 
    
    if (max(errvector) < err_bound)     %   Step succ 


