% showgraphcallback
if get(GLOB_HANDLES.showgraph,'Value')==1
    set(GLOB_HANDLES.picture_main,'Position',[0.04 0.35 .75 .63]);
    GLOB_HANDLES.picture_length_time=axes('Tag','PictureLengthTime','Units','normalized',...
    'Position',[0.04 0.05 .75 .25]);
else
    delete(GLOB_HANDLES.picture_length_time);
    set(GLOB_HANDLES.picture_main,'Position',[0.04 0.05 .75 .93]);
end;