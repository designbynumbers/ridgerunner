function drawcomponents(V, link, strutStartPoints,strutEndPoints,compressions,strutField,dVdt,linkaxis,handles); 

% FUNCTION drawcomponents draws a link (tubes and/or struts) according to the handles passed in.
%
% Input: an nx3 array Verts of locations in 3-space
%        a linkdata structure link, containing the fields
%
%           link.endpoints    a list of the endpoints of all the components
%           link.closed       a cell array of text strings 'open' or 'closed' for each component
%           link.colorvalues  an ix3 array of rgb color values for the components of the link
%           link.tranparency  a cell array of text strings 'Clear', 'Transparent', or 'Opaque'
%           link.tension      an ix1 array of the tension in each component
%           link.thickness    an nx1 array of the thickness of each tube
%           link.constraints  a cell array of text strings 'None', 'Fixed', or 'Surface'
%           link.surface      a cell array of text strings in the form 'z=f(x,y)' for each
%                             endpoint with a "surface" constraint.

%         strutStartPoints: the locations of the starts of the struts (in space)
%         strutEndPoints:   the locations of the ends of the struts (in space)
%         compressions:     the compressive force borner by each strut
%         strutField:       the forces coming from the ends of the struts
%         dVdt:             the total motion of the core curve (dlen - strutField)
%         linkaxis:         the axis for the 3d drawing of the link

% for every component: 

%         if 'handles.tubes'       (handles(1)) is marked draw tubes around curves.
%         if 'handles.curves'      (handles(2)) is marked draw core curves
%         if 'constraints' (handles(4)) is marked display constraint points or surfaces
%         if 'struts'      (handles(5)) is marked display struts and the strut field
%         if 'vectorfield' (handles(3)) is marked display vector field dVdt



