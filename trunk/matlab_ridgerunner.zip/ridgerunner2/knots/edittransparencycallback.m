%edittransparencycallback
for i=1:numcomp
    u=(get(GLOB_HANDLES.edit_component_transparency(i),'String'));
    GLOB_FVDATA.link.transparency(i)=str2double(u);
    
    updategraphics('',verts,'');
end;
