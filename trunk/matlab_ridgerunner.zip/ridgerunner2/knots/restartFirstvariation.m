function [dVdt,badstepflag,indices] = restartFirstvariation(Verts,oldIndices);

% FUNCTION  EXPERIMENTALFIRSTVARIATION computes the first variation of ropelength for a link
%                                  here, we compare the strut set to a cached one, and check
%                                  for short struts. If the strut set has changed, or a 
%                                  self-intersection has happened, we object, and will shorten
%                                  the attempted step/
%                                  

% Input: t             the time of integration (since this flow is not time-dependant, this parameter is ignored) 
%        V             3nx1 list of coordinates of vertices of components

% The function uses the global structure GLOB_FVDATA, which contains several fields

%        link          a linkdata structure, containing the fields
%
%                         link.endpoints    a list of the endpoints of all the components
%                         link.closed       a cell array of text strings 'open' or 'closed' for each component
%                         link.colorvalues  an ix3 array of rgb color values for the components of the link
%                         link.transparency a scalar between 0 and 1 giving the opacity of the tube
%                         link.tension      an ix1 array of the tension in each component
%                         link.thickness    an nx1 array of the thickness of each tube
%                         link.constraints  a cell array of text strings 'None', 'Fixed', or 'Surface'
%                         link.surface      a cell array of text strings in the form 'z=f(x,y)' for each
%                                           endpoint with a "surface" constraint.

%        dVdt           an nx3 variational vector field
%     strutStartPoints  start points of struts (in space) as a kx3 array
%     strutEndPoints    end points of struts (in space) as a kx3 array
%     compressions      compression values for struts (a kx1 array)
%     strutField        an nx3 force field from struts.
       

% Output: dVdt         3nx1 list of coordinates of the gradient vector field

% Algorithm: We use the Cantarella-Piatek-Rawdon picture. We assume that the link forms a tensegrity where
% the contacts between tubes act as struts. The first variation of length is an external force on this
% tensegrity, which usually cannot be completely resolved by compressions on the struts. We resolve the
% largest possible component of this force: the remainder is the gradient of ropelength. 
 
% Because this function is run constantly while we are tightening the knot, we occaisionally force it
% to issue a drawnow command. This keeps the picture fresh on the screen between updates.

global GLOB_FVCALLS

GLOB_FVCALLS = GLOB_FVCALLS + 1;

if (mod(GLOB_FVCALLS,20) == 0) 
    
     drawnow;    
    
end;

global GLOB_FVDATA;

% And we include some debugging code.

global GLOB_CONFIGS;

% We start by testing our input, and complaining if it doesn't look right.

if (nargin ~= 2)
    
    error('firstvariation: must input (t,Verts)');
    
end;

if (nargout ~= 1)
    
    error('firstvariation: expect to output one variable dVdt.');
    
end;

if ((mod(size(Verts,1),3) ~= 0) | (size(Verts,2) ~= 1))
    
    error('firstvariation: Expect Verts to be a 3nx1 column vector.');
    
end;

% First, we reshape V for convenience in working with it inside the function.
% We also set n to the number of vertices in V.

[n,k]=size(Verts);
V=reshape(Verts,3,n/3)';  % This is important! The vector appears as (x1 y1 z1 x2 y2 z2 ... )'
[n,k]=size(V);            % We must reshape it so that the correct elements end up together!

% Next, we compute the weighted first variation of length for this link.

dl = dlen(V,GLOB_FVDATA.link);
dl = reshape(dl',3*n,1);
  
% Now we call the Mex'ed strutFinder. 
% indices is almost an nx4 array of integers giving the endpoints of the edges involved in each strut 
%    as indices into V (now that V has been reshaped). The problem is that the entries in "indices" refer
%    to the ZERO-based index scheme in C++ used in strutFinder, but here we have ONE-based indexing in MATLAB.

% positions is an nx2 array of doubles between 0 and 1 giving the position along that strut 

[indices positions strutcount badstepflag] = strutFinder(Verts,GLOB_FVDATA.link,oldIndices);
indices = indices + 1; % correct for Cpp's ZERO-based arrays

% Construct the rigidity matrix A. A maps from the strut space to the space of variations
% of vertices, and gives the force at each vertex resulting from a compressive force pushing _out_
% from each strut. 

% If the strut strikes in the middle of an edge, we apply its force to both endpoints of the 
% edge, divided according to the position of the end of the strut along the edge.

% Each row of A corresponds to a single component of a single _vertex_ of the overall picture.
% The entries in the row corresponding to each strut that pushes on the vertex are that component 
% of the unit vector pointing _out_ from that strut's endpoint at the edge incident to the
% given vertex.


if (strutcount > 0) 
    
	A = zeros(3*n,strutcount);
	
	% The first step is to construct a matrix of strut directions.
	
	GLOB_FVDATA.strutStartPoints = (1 - repmat(positions(:,1),1,3))  .* V(indices(:,1),:) ...
                                 + repmat(positions(:,1),1,3) .* V(indices(:,2),:);
	GLOB_FVDATA.strutEndPoints   = (1 - repmat(positions(:,2),1,3))  .* V(indices(:,3),:) ...
                                 + repmat(positions(:,2),1,3) .* V(indices(:,4),:);
	
    % We now make sure that these struts pass self-testing.
   
    if (strut_test_suite(V,GLOB_FVDATA.link,GLOB_FVDATA.strutStartPoints,GLOB_FVDATA.strutEndPoints,positions,indices,0.1) ~= 1)
        
        'strut test suite failure causes firstvariation to fail'
        dVdt = zeros(size(Verts));
        return;
        
    end;
    
    % And continue building the rigidity matrix A.
                        
	strutDirections  = normalizenx3(GLOB_FVDATA.strutStartPoints - GLOB_FVDATA.strutEndPoints);
    strutLengths     = lengthnx3(GLOB_FVDATA.strutStartPoints - GLOB_FVDATA.strutEndPoints);
	
	% We now assign the strutDirections to the matrix A. 
	
	for i = 1:strutcount 
      
        % These are the rows of A corresponding to
        % vertex V(indices(i,1),:).
	
        % |||||||||||||||||||||||||||||||
        % vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        
        A(3*indices(i,1)-2:3*indices(i,1),i) =                        (1-positions(i,1))*strutDirections(i,:)';
        
        %                                                              ^^^^^^^^^^^^^^^   ^^^^^^^^^^^^^^^^^^^^
        %                                                                      |                 |
        %                                                fraction assigned to this end    force vector from strut
        %                                                                                 this is a row vector, so we
        %                                                                                 transpose it to match the 
        %                                                                                 column vector we are filling
        %                                                                                 on the left hand side
        
        A(3*indices(i,2)-2:3*indices(i,2),i) =                         positions(i,1) *strutDirections(i,:)';
        
        
        %                               On the other end of the strut, the direction
        %                               of force is reversed. Hence the extra minus signs.
        %                                                             |
        %                                                             V
        
        A(3*indices(i,3)-2:3*indices(i,3),i) =                     -(1-positions(i,2))*strutDirections(i,:)';
        A(3*indices(i,4)-2:3*indices(i,4),i) =                        -positions(i,2) *strutDirections(i,:)';
        
        %                                                             ^
        %                                                             |
        
	end;    
           
	% We now try to cancel as much of the motion as possible with strut forces. 
	% This involves finding the best nonnegative partial solution to the system 
	%
	%                               AX = -dl. 
	%
	% Of course, we can't solve this equation in general (unless the knot is critical!)
	% so we settle for the closest partial solution in a least-squares sense. We use
	% the sparse matrix package SLS from http://www.mai.liu.se/~milun/sls/ by Pontus 
	% Matstoms to solve the linear algebra problem, since the matrix A is extremely sparse.
	
	%spA = sparse(A);
	GLOB_FVDATA.compressions = lsqnonneg(A,-dl);
	
	% We then cancel this from dl to find the first variation of ropelength. However, here 
    % there is a subtlety. If all the struts are the correct lengths (2.0), then this is 
    % exactly what happens. However, if some of the struts are too long or too short, we 
    % impose a physics-based penalty function to allow long struts to shrink and encourage
    % short ones to expand: 
    
    % We scale the values of GLOB_FVDATA.compressions by the corresponding pad function padf.
    
    % This function is somewhat less than one for struts that are extra long, and approaches
    % infinity for very short struts. We hope that this will prevent the tube overrun problem:
    % for overlarge stepsizes, we'll detect a short strut and produce a correspondingly large
    % restoring force. In a just world, this will cause ode45 to fail its numerical quality 
    % tests.
    
    % Note that padf is expected to be "vectorized"; it both expects and return a vector.
	
	dVdt = dl + A*(GLOB_FVDATA.compressions .* padf(strutLengths));
	
    GLOB_FVDATA.dVdt = dVdt;
    GLOB_FVDATA.strutField = A*GLOB_FVDATA.compressions;
    
else 
    
    dVdt = dl;
    
    GLOB_FVDATA.strutStartPoints = [];
    GLOB_FVDATA.strutEndPoints = [];
    GLOB_FVDATA.compressions = [];
    GLOB_FVDATA.strutField = [];
    
    badstepflag = 0;
    
end;

% We now need to enforce the constraints on the system.

% Last, we compare the distance from this guy to the last accepted configuration.

% sprintf('distance from %d to last accepted: %g',GLOB_FVCALLS,linfty(GLOB_CONFIGS{size(GLOB_CONFIGS,2)},V))


     
