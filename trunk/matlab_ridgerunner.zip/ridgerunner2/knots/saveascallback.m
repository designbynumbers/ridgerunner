% saveascallback
% saves the workspace variables into saveas_file_name
%update_structure;
[saveas_file_name,saveas_path_name]=uiputfile('Data1.mat','SAVE FILE',100,100);
if saveas_file_name~=0
save(saveas_file_name,'components');
end;
