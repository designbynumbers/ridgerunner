function f=surfacedialogbox(CC,ff,command_str);

if nargin<3
    command_str='initialize';
end;
if ~strcmpi(command_str,'initialize')
    handles=get(gcf,'userdata');
    dialog_answer1=handles(1);
end;
if strcmpi(command_str,'initialize')
    dialog=figure('Units','characters','Position',[90 30 35 6],'IntegerHandle','off',...
                  'MenuBar','none','Name','Surface','Tag','Surface','Color',...
                  [0.8 0.8 0.8],'NumberTitle','off');
    dialog_question=uicontrol(dialog,'Style','text','Units','normalized','Position',...
                              [0.01 .7 .99 .2],'String','Edit surface of constraint',...
                              'BackgroundColor',[.8 .8 .8]);
    dialog_answer1=uicontrol(dialog,'Style','edit','Units','normalized','Position',...
                             [0.2 .2 .6 .3],'String',ff,'BackgroundColor',CC,'Callback','surfacedialogbox(CC,ff,''Answer1'')');
                         
    handles=[dialog_answer1];
    set(dialog,'userdata',handles);
    while length(get(dialog_answer1,'userdata'))<1
        drawnow;
    end;
    f=[(get(dialog_answer1,'String'))];
    close(gcf);
elseif strcmpi(command_str,'Answer1')
    set(dialog_answer1,'userdata',1);
end;

