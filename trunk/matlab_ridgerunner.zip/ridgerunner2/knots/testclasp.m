% Script testevolution loads up a knot and evolves it.

global numcomp;
global COUNTER;
global GLOB_HANDLES;
global GLOB_STOP;
global GLOB_FVDATA;

[saveas_file_name,movie_file_name]=GraphicalUserInterface_Knots;

load claspdata.mat link verts;
numcomp = 2;

set(GLOB_HANDLES.tubes,'Value',1);      % Turn on tubes
set(GLOB_HANDLES.curves,'Value',1);     % Turn on curves
set(GLOB_HANDLES.struts,'Value',0);     % Turn on struts
set(GLOB_HANDLES.vector_field,'Value',1);     % Turn on vector field.

figure(GLOB_HANDLES.gui_figure);

GLOB_FVDATA.link.endpoints       = link.endpoints;
GLOB_FVDATA.link.thickness       = [1 1];
GLOB_FVDATA.link.closed          = link.closed;
GLOB_FVDATA.link.colorvalues     = link.colorvalues;
GLOB_FVDATA.link.edgecolorvalues = link.edgecolorvalues;
GLOB_FVDATA.link.tension         = link.tension;
GLOB_FVDATA.link.constraints     = link.constraints;
GLOB_FVDATA.link.surface         = link.surface;
GLOB_FVDATA.link.transparency    = [0.9 0.9];                     % make the tubes very ghostly
      
GLOB_FVDATA.dVdt = [];
GLOB_FVDATA.strutStartPoints = [];
GLOB_FVDATA.strutEndPoints = [];
GLOB_FVDATA.compressions = [];
GLOB_FVDATA.strutField = [];

updategraphics('',verts,'init');

axis vis3d;
rotate3d;
