%editthicknesscallback
for i=1:numcomp
    u=str2num(char(get(GLOB_HANDLES.edit_component_thickness(i),'String')));
    GLOB_FVDATA.link.thickness(i)=u;
    
    updategraphics('',verts,'');
end;
