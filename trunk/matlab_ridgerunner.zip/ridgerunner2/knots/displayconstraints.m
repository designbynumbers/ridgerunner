function displayconstraints(link,a);
[s,t]=size(link);
for i=1:t
    value=getfield(link,{i},'constraints');
    if strcmpi(value,'surface')
        F=getfield(link,{i},'surface');
        x=linspace(a(1)+1.5,a(2)-1.5,40);
        y=linspace(a(3)+1.5,a(4)-1.5,40);
        [x,y]=meshgrid(x,y);
        fid = fopen('surfaces.m','w');
        fprintf(fid,'%s\n',F);
        fclose(fid);
        surfaces;
        surf(x,y,z,'FaceColor',[.5 0 0],...
               'EdgeColor',[.5 0 0],'FaceAlpha',.5,...
               'EdgeAlpha',0,'FaceLighting','gouraud');
    end;
end;

    