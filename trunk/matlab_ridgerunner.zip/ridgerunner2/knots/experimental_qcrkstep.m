function [Vfinal,err,badstep] = experimental_qcrkstep(link,verts,dVdt,ss_try,err_bound,indices)

% FUNCTION experimental_qcrkstep takes a step of size ss_try, and returns badstep == 1 if it 
% fails either the discontinuity or the numerical error control requirments (as given by err_bound).

vertsSave = verts;
dVdtSave = dVdt;
h = ss_try;

badstep = zeros(3);
[Vtemp,badstep(1)] = attempt_rkstep(link,vertsSave,h/2.0,indices,dVdtSave);     % We try a half-step.
% if(badstep(1) == 1)
%     sprintf('first half step trouble in qrck')
% end;

[dVdt, badstep(2),newindices] = experimentalFirstvariation(link,Vtemp,indices); % Get another derivative 
[verts,badstep(2)] = attempt_rkstep(link,Vtemp,h/2.0,indices,dVdt);             % And half-step again.
% if(badstep(2) == 1)
%     sprintf('second half step trouble in qrck')
% end;

[Vfinal,badstep(3)] = attempt_rkstep(link,vertsSave,h,indices,dVdtSave);        % Here is the FULL step.
% if(badstep(3) == 1)
%     sprintf('full step trouble in qrck')
% end;
    
% We now compare the results of the full step with the results of the two half-steps.
    
err = max(abs(Vfinal - verts)); 
    
if (err > err_bound) 
    
    badstep = 2;
    
elseif (badstep(3) == 1) % The step fails.
    
    badstep = 1;
    
else
    
    badstep = 0;
    
end;
