function NL=drawlength(t,V,link);

% FUNCTION drawlength computes the length of the link given by V, link and plots it.

% Input:  t   the time at which the length is being measured.
%         V   an nx3 array of vertices for the link
%        a linkdata structure link, containing the fields
%
%           link.endpoints    a list of the endpoints of all the components
%           link.closed       a cell array of text strings 'open' or 'closed' for each component
%           link.colorvalues  an ix3 array of rgb color values for the components of the link
%           link.tranparency  a cell array of text strings 'Clear', 'Transparent', or 'Opaque'
%           link.tension      an ix1 array of the tension in each component
%           link.thickness    an nx1 array of the thickness of each tube
%           link.constraints  a cell array of text strings 'None', 'Fixed', or 'Surface'
%           link.surface      a cell array of text strings in the form 'z=f(x,y)' for each
%                             endpoint with a "surface" constraint.
%
% Output: display at (time,length) a star of the corresponding coloring

NL=zeros(1,n);
    startpoint=1;
    for i=1:n
        endpoint=link.endpoints(i);
        if strcmpi(link.closed{i},'closed') 
            v=[V0(startpoint:endpoint,:);V0(startpoint,:)];
        else
            v=V0(startpoint:endpoint,:);
        end;
        NL(i)=computelength(v);
        startpoint=endpoint+1;  
        plot(t,NL(i),'Marker','*','Color',CC(i,:));
        hold on;
    end;
   