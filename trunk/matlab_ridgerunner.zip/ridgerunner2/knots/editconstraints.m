%editconstraints
global GLOB_HANDLES;
global GLOB_FVDATA;
if numcomp==0
    msgbox('Open data file first','Error');
else
    edit_constraints_figure=figure('Units','characters','Position',[46 33 80  12*numcomp],'IntegerHandle','off',...
    'MenuBar','none','Name','Edit Constraints','Tag','EditConstraintsFigure','Color',[0.8 0.8 0.8],'NumberTitle','off');
    GLOB_HANDLES.component_text_color=uicontrol(edit_constraints_figure,'Style','text','Units','normalized','Position',[0.050 .9-1/(5*numcomp) .24 1/(5*numcomp)],'String','Component','BackgroundColor',[.8 .8 .8]);
    GLOB_HANDLES.component_text_endpoint1=uicontrol(edit_constraints_figure,'Style','text','Units','normalized','Position',[0.300 .9-1/(5*numcomp) .24 1/(5*numcomp)],'String','Starting point','BackgroundColor',[.8 .8 .8]);
    GLOB_HANDLES.component_text_endpoint2=uicontrol(edit_constraints_figure,'Style','text','Units','normalized','Position',[0.650 .9-1/(5*numcomp) .24 1/(5*numcomp)],'String','Endpoint','BackgroundColor',[.8 .8 .8]);
    
      
for i=1:numcomp
    
    GLOB_HANDLES.component_color_constraints(i)=uicontrol(edit_constraints_figure,'Style','text','Units','normalized','Position',[0.10 0.9-i/(3*numcomp) .13 1/(5*numcomp)],'BackgroundColor',GLOB_FVDATA.link.colorvalues{i});
    GLOB_HANDLES.edit_component_constraint_ept1(i)=uicontrol(edit_constraints_figure,'Style','popupmenu','Units','normalized','Position',[.350 .9-i/(3*numcomp) .17 1/(5*numcomp)],'String','none|fixed|surface','BackgroundColor','w','Callback','editconstraintscallback1'); 
    GLOB_HANDLES.edit_component_constraint_ept2(i)=uicontrol(edit_constraints_figure,'Style','popupmenu','Units','normalized','Position',[.700 .9-i/(3*numcomp) .17 1/(5*numcomp)],'String','none|fixed|surface','BackgroundColor','w','Callback','editconstraintscallback2');        
   
end;    
end;
