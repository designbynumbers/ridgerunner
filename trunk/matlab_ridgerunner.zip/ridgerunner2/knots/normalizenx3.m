function nv = normalizenx3(v)

% NORMALIZENX3 normalizes an nx3 list of vectors in 3-space
%
% Input:  v, an nx3 list of vectors in R^3
%
% Output: nv, the same vectors, each divided by their norms
%
% Note that zero-length vectors aren't given any special treatment, and
% will show up as NaN's in the results.

vnorms=repmat(sqrt((v(:,1)).^2+(v(:,2)).^2+(v(:,3)).^2),1,3);
nv = v ./ vnorms;
    