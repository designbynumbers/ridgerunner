function [link,verts,numcomp] = importmingfile(import_path_and_file_name)

% importmingfile
% This script reads Ming type knot files into our program.
% The typical Ming file starts out
% {n}    where n is the number of vertices in the knot
% x1 y1 z1
% x2 y2 z2
% ...
% xn yn zn
% sometimes there are commas, tabs or other white space in 
% between the x, y, and z coordinates

% We first set up a linkdata structure to receive our data.

% We are now ready to load this data into a linkdata structure.

link=struct('endpoints',[],...
            'closed',{[]},...
            'colorvalues',{[]},...
            'transparency',[],...
            'tension',[],...
            'thickness',[],...
            'constraints',{[]},...
            'surface',{[]},...
            'edgecolorvalues',{[]});

% First, we get the file, and read the lines into an array of strings.

A=textread(import_path_and_file_name,'%s','delimiter','\n');

% We test the first line an opening "{".
% Send error if the file ain't right.
if size(findstr(A{1},'{'),1) == 0
  error('Import file: The file does not appear to be a Ming file.');
end;


% We load the number of vertices.  This could most likely be done a
% little smoother than is the case here.

B = strrep(A{1},'{','');
B = strrep(B,'}','');

number_of_vertices=str2num(B);

% Our next task is to load the vertices into the one component

% Here we prepare link.endpoints and Closed for input.
link.endpoints(1)=number_of_vertices;
link.closed{1}='closed';

% We now read all the vertices into the V array.

verts=zeros(number_of_vertices,3);
for i=2:number_of_vertices+1
  verts(i-1,:)=str2num(char(A(i)));
end;

verts = reshape(verts',3*size(verts,1),1);

% set all of these as defaults
link.transparency(1) = 1;
link.tension(1) = 1;
link.thickness(1) = 1;
link.constraints{1} = 'none';

link.colorvalues{1} = [0.9961 0.0742 0.9375];
link.edgecolorvalues{1} = [0.6055 0.0742 0.9375];


% We also set up the helpful global numcomp, which contains the number of components.
numcomp = 1;

