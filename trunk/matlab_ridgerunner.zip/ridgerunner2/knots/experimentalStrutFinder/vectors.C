#include <stdlib.h>
#include "mex.h"
//#include <assert.h>
#include"vectors.h"


// assuming big endian means OS X compilation
#if BYTE_ORDER == BIG_ENDIAN
double drand48(void)
{
    double d;
    d = rand();
    d = d / RAND_MAX;
    return d;
}
#endif

vectors::vectors()                               // default constructor 0 elts
     // postcondition: vectors of zero items constructed
{
  myLength = 0; myList = 0;
  mOwnsData = true;
}
    
vectors::vectors(int size)                       // specify size of vectors
     // postcondition: vectors of size items constructed   
{
    mOwnsData = true;
  myLength = size;
 // myList = new double[size];
 myList = (double*)mxCalloc(size, sizeof(double));
  //assert(myList != 0);
}
    
vectors::vectors(int size, double fillValue)     // specify size and fill value
     // postcondition: vectors of size items, each initialized to fillValue
     //                constructed    
{
    mOwnsData = true;
  myLength = size;
 // myList = new double [size];
  myList = (double*)mxCalloc(size, sizeof(double));
  //assert(myList != 0);
  for(int k = 0; k < size; k++){
    myList[k] = fillValue;
  }       
}

vectors::vectors(const vectors & vec)             // copy constructor
     // precondition: double supports assignment
     // postcondition: return copy of vec        
{
  // allocate storage
  
  mOwnsData = true;
  myLength = vec.myLength;
  //myList = new double [myLength = vec.myLength];
  myList = (double*)mxCalloc(myLength, sizeof(double));
  
  //assert(myList != 0);
  
  // copy elements
  for(int k = 0; k < vec.myLength; k++)
    {
      myList[k] = vec.myList[k];
    }       
}

const void*
vectors::getData()
{
    return myList;
}

void
vectors::setOwnsData( bool inOwnsData )
{
    mOwnsData = inOwnsData;
}
/*    
vectors::~vectors ()                            // free new'd storage
     // postcondition: dynamically allocated storage freed
{
    if( mOwnsData )
    {
     //   delete [] myList;
        mxFree(myList);
    }
  myList = 0;
  myLength = 0;               // leave in "empty" state
}
*/

vectors & vectors::operator = (const vectors & vec) // overload assignment
     // precondition: Item supports assignment     
     // postcondition: self is assigned vec
{
  if (this != &vec)      // don't assign to self!
    {       
      //delete [] myList;            // out with old list, in with new
    /*  if( myList != NULL )
        mxFree(myList);
      */
      myLength = vec.myLength;
      //myList = new double [myLength = vec.myLength]; 
      myList = (double*)mxCalloc(myLength, sizeof(double));
      
      //assert(myList != 0);
      
      // copy vec
      myLength = vec.myLength;
      for(int k=0; k < myLength; k++)
	{
	  myList[k] = vec.myList[k];
	}
    }
        
  return *this;           
}
    
int vectors::Length() const                    // capacity of vectors
{
  return myLength;
}

int vectors::length() const
{
  return Length();
}

void vectors::Fill(double fillValue)
     // postcondition: all entries == fillvalue
{
  int k;
  for(k=0; k < myLength; k++)
    {
      myList[k] = fillValue;
    }
}

void vectors::SetSize(int newSize)             // change size dynamically
     // precondition: vectors has room for myLength entries     
     // postcondition: vectors has room for newSize entries
     //                the first myLength of which are copies of original
     //                unless newSize < myLength, then truncated copy occurs       
{
/*  int numToCopy = newSize < myLength ? newSize : myLength;
  
  // allocate new storage
//  double * newList = new double[newSize];
*/
  double* newList = (double*)mxCalloc(newSize, sizeof(double));
  /*
  //assert(newList != 0);   // be sure storage allocated
  
  int k;
  for(k=0; k < numToCopy;k++)
    {
      newList[k] = myList[k];
    }
  */
//  delete [] myList;         // de-allocate old storage
  if( myList != NULL )
    mxFree(myList);
  
  myLength = newSize;
  myList = newList;
}

void vectors::resize(int newSize)
{
  SetSize(newSize);
}

