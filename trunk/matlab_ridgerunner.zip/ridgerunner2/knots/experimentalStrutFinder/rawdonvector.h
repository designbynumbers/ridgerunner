#include"point.h"

#ifndef VECTOR_H
#define VECTOR_H

class rawdonvector{
public:
  rawdonvector();
  rawdonvector(int numElts);
  rawdonvector(const rawdonvector & source);
 // ~rawdonvector();

    inline point & rawdonvector::operator [] (int index)
    {
        return data[index];
    }
    
    inline const point & rawdonvector::operator [] (int index) const
    {
        return data[index];
    }
    
    point & index(int inIndex);

  rawdonvector & operator =(const rawdonvector & source);

  int length () const;

  int setSize(int numberOfElements);

//protected:
  point * data;
  int size;
};

rawdonvector operator *(const double & scalar, const rawdonvector & source);

#endif
