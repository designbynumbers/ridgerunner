#include"point.h"
#include<math.h>
/*
point::point()
{
}
/*
point::point(double a, double b, double c)
{
  coord[0] = a;
  coord[1] = b;
  coord[2] = c;
}
*
point::point(const point & source)
{
  coord[0] = source.coord[0];
  coord[1] = source.coord[1];  coord[2] = source.coord[2];
}
/*
point & point::operator =(const point & source)
{
  if (this != &source)
    {
      coord[0] = source.coord[0];
      coord[1] = source.coord[1];
      coord[2] = source.coord[2];
    }

  return *this;
} 
*/
double & point::operator [] (int index)
{
//  assert(index < 3);
  return coord[index];
}

const double & point::operator [] (int index) const
{
//  assert(index < 3);
  return coord[index];
}

point operator +(point a, point b)
{
  point temp;
  for(int i=0; i<3; i++)
    temp.coord[i] = a.coord[i] + b.coord[i];
  return temp;
}

point operator -(point a, point b)
{
  point temp;
  for(int i=0; i<3; i++)
    temp.coord[i] = a.coord[i] - b.coord[i];
  return temp;
}

point operator -(point a)
{
  point temp;
  for(int i=0; i<3; i++)
    temp.coord[i] = -a.coord[i];
  return temp;
}

point operator *(double x, point b)
{
  point temp;
  for(int i=0; i<3; i++)
    temp.coord[i] = x*b.coord[i];
  return temp;
}

int operator !=(point a, point b)
{
  return !(a == b); 
}

int operator ==(point a, point b)
{
  const double TOLERANCE = .000000000000001;

  return ( fabs(a.coord[0] - b.coord[0]) < TOLERANCE &&
	   fabs(a.coord[1] - b.coord[1]) < TOLERANCE && 
	   fabs(a.coord[2] - b.coord[2]) < TOLERANCE);
}
/*
double operator *(point a, point b)
{
  return ( a.coord[0] * b.coord[0] + a.coord[1] * b.coord[1]
	   + a.coord[2] * b.coord[2] );
}*/
/*
point operator &(point a, point b)
{
  point cross;
  /*
  for (int i=0; i<3; i++)
    {
      int j=( (i+1) % 3), k = ( (i+2) % 3);
      cross.coord[i] = a.coord[j]*b.coord[k] - a.coord[k]*b.coord[j];
    }
    *
    
    // we can expand this for loop because it's constant length and eliminate the modulo calculations
    cross.coord[0] = a.coord[1]*b.coord[2] - a.coord[2]*b.coord[1];
    cross.coord[1] = a.coord[2]*b.coord[0] - a.coord[0]*b.coord[2];
    cross.coord[2] = a.coord[0]*b.coord[1] - a.coord[1]*b.coord[0];
  
  return cross;
}*/
/*
double fsqrt(double r);
/*
double point::norm()
{
//  return sqrt( (*this) * (*this) );
}*

double fsqrt(double r) {
double x,y;
float tempf;
unsigned long *tfptr = (unsigned long *)&tempf;

    tempf = r;
    *tfptr=(0xbe6f0000-*tfptr)>>1;
    x=tempf;
    y=r*0.5; 
    x*=1.5-x*x*y; 
    x*=1.5-x*x*y;
    x*=1.5-x*x*y; 
    x*=1.5-x*x*y; 
    return x*r;
}*/

