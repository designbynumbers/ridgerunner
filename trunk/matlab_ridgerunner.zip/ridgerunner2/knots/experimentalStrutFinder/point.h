//#include<assert.h>
#include<math.h>
#include <string.h>

#ifndef POINT_H
#define POINT_H

class point
{
public:
    inline point() {};
    
    inline point(double a, double b, double c)
    {
        coord[0] = a;
        coord[1] = b;
        coord[2] = c;
    };
  inline point(const point & source)
    {
        memcpy( &(coord[0]), &(source.coord[0]), sizeof(double[3]) );
        /*
        coord[0] = source.coord[0];
        coord[1] = source.coord[1];
        coord[2] = source.coord[2];
        */
    };
    
    static void createCrossPoint( const point & a, const point & b, point & outCrossedPoint )
    {
        // here we create an updated crossProduct calculation function.
        // reasoning: operator &(point a, point b) employs the constructors of point to generate a and b
        // as they are not passed by reference, this eliminates those instructions. Also, the generic operator
        // call returns a newly generated point object which is usually assigned to a generic point object that 
        // was just created. This calls a point constructor for no reason, and an operator=() function needlessly.
        // We eliminate this here by simply including outCrossedPoint in the function call.
    
        // we can expand the former for loop because it's constant length thereby eliminating the modulo calculations
        outCrossedPoint.coord[0] = a.coord[1]*b.coord[2] - a.coord[2]*b.coord[1];
        outCrossedPoint.coord[1] = a.coord[2]*b.coord[0] - a.coord[0]*b.coord[2];
        outCrossedPoint.coord[2] = a.coord[0]*b.coord[1] - a.coord[1]*b.coord[0];
    }

  double & operator [] (int index);
  const double & operator [] (int index) const;

  inline point & operator = (const point & source)
  {
    if (this != &source)
    {
        memcpy( &(coord[0]), &(source.coord[0]), sizeof(double[3]) );
        /*
        coord[0] = source.coord[0];
        coord[1] = source.coord[1];
        coord[2] = source.coord[2];*/
    }
    
    return *this;
  };

    inline double norm()
    {
     //   double r = (*this) * (*this);
    
        double r = (coord[0] * coord[0] + coord[1] * coord[1]
	   + coord[2] * coord[2]);
    
        double x,y;
        float tempf;
        unsigned long *tfptr = (unsigned long *)&tempf;
        
        tempf = r;
        *tfptr=(0xbe6f0000-*tfptr)>>1;
        x=tempf;
        y=r*0.5; 
        x*=1.5-x*x*y; 
        x*=1.5-x*x*y;
        x*=1.5-x*x*y; //	these two lines can be uncommented for increased precision
    //    x*=1.5-x*x*y; 
        return x*r;
    };

  double coord[3];
};

point operator +(point a, point b);
point operator -(point a, point b);
point operator -(point a);
point operator *(double x, point b);
int operator !=(point a, point b);
int operator ==(point a, point b);
inline double operator *(point a, point b)
{
  return ( a.coord[0] * b.coord[0] + a.coord[1] * b.coord[1]
	   + a.coord[2] * b.coord[2] );
};
inline point operator &(point a, point b)
{
  point cross;
    
    // we can expand this for loop because it's constant length and eliminate the modulo calculations
    cross.coord[0] = a.coord[1]*b.coord[2] - a.coord[2]*b.coord[1];
    cross.coord[1] = a.coord[2]*b.coord[0] - a.coord[0]*b.coord[2];
    cross.coord[2] = a.coord[0]*b.coord[1] - a.coord[1]*b.coord[0];
  
  return cross;
};

#endif
