#include"rawdonvector.h"
#include"point.h"
//#include<assert.h>
#include "mex.h"

//#include <Carbon/Carbon.h>

rawdonvector::rawdonvector()
{
  data = NULL;
  size = 0;
}

rawdonvector::rawdonvector( int numElts):size(numElts)
{
    data = (point*)mxCalloc(size, sizeof(point));

//  data = new point[size];
//  assert(data!=0);
}

rawdonvector::rawdonvector(const rawdonvector & source)
{
  size = source.size;
//  data=new point[size];
 
    data = (point*)mxCalloc(size, sizeof(point));
    
   //assert(data!=0);

  for(int i=0; i<size; i++)
    (*data)[i] = (*source.data)[i];
}

rawdonvector & rawdonvector::operator =(const rawdonvector & source)
{
  if (this != &source)
    {
     // delete [] data;
      if( data != NULL )
        mxFree(data);
      
      size = source.size;
//      data = new point[size];
        data = (point*)mxCalloc(size, sizeof(point));

      //assert(data != 0);
      
      for(int i=0; i<size; i++)
	(*data)[i] = (*source.data)[i];
    }

  return *this;
}  
/*
rawdonvector::~rawdonvector()
{
//  delete [] data;
    mxFree(data);
   data = 0;
  size = 0;
}
*/
point & rawdonvector::index(int inIndex)
{
    return data[inIndex];
}

/*
point & rawdonvector::operator [] (int index)
{
  return data[index];
}

const point & rawdonvector::operator [] (int index) const
{
  return data[index];
}
*/
int rawdonvector::length() const
{
  return size;
}

int rawdonvector::setSize(int numberOfElements)
{
   /* if( numberOfElements == size )
        return size;
     */   
   // point * newData = new point[numberOfElements];
        
        point* newData = (point*)mxMalloc(numberOfElements*sizeof(point));
    
    //assert(newData != 0);
    
 //   delete [] data;
    if( data != NULL )
        mxFree(data);
     size = numberOfElements;
    data = newData;
    
    return size;
}


rawdonvector operator *(const double & scalar, const rawdonvector & source)
{
  int i, j;
  int size = source.length();
  rawdonvector multiple(size);
  
  for(i=0; i<size; i++)
    for(j=0; j<3; j++)
      multiple[i].coord[j] = scalar * source[i].coord[j];

  return multiple;
}
