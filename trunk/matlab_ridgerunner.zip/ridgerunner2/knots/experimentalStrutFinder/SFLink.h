#ifndef _H_SFLink
#define _H_SFLink

#include "rawdonvector.h"
#include "vectors.h"

extern bool gSelfIntersection;

enum 
{
    kItoJdir,
    kJtoIdir
};

//a temporary linkdata structure that contains the necessary parts for running the following functions
typedef struct linkdata 
{
  double compNum;	//the munber of components in the linkdata
  int* cstart;		//the location where each component start counting vertex not the "xyz" coordinate
  int* closed;		//conresponding to cstart indicating if the last index of each component is connected back to the first component
  double* thickness;	//coresponding to cstart indicating the radius of each tube
} linkdata;

typedef struct SFStrut
{
    double	v1, v2, v3, v4;
    double	positionEdge1, positionEdge2;
    
    struct SFStrut* next;
} SFStrut;

struct KComponent
{
        vectors* lenvtr;
        rawdonvector* side;
        vectors* angle;
        
        double R[4];
        double minRad_factor;
        double injRadius;
        double epsilon;
        double polyLength;
        
        rawdonvector* vertex;
        int numSides;
        
        double	definedThickness;
};

int fetchRandom( int min, int max );

class SFLink
{
    public:
                        SFLink( double* inVertices, int inSize, linkdata & inLinkData );
        
        void		print();
        void		stats();
        
        void		saveAll();
        
        void		jiggleAll();
        void		jiggle( int inComponent );
        void		jigglePoint();
        void		randomShift();
        
        void		scaleComponent( int inComponent, double factor );
        void		scaleAll( double factor );
        void		randomScale();
        
        void		rotatexy(int inComponent, const double & theta);
        void		rotateyz(int inComponent, const double & angle);
        void		rotatezx(int inComponent, const double & phi);
        void		rotateyz(int inComponent, const double & rho, const int & i, const int & j);
        
        void		crankInPlace(int inComponent, const double & rho, const int & i, const int & j, int inDirection);
        
        void		Crank(const int inComponent, const double & angle, const int & i, const int & j);
        
        void		Compute();
        
        int		find_rate(int iComponent, int jComponent, const int & i, const int & j, 
                            double & a, double & b, double & d);
        int		IsDC(int iComponent, int jComponent, const int & i, const int & j, const double & a);
        
        double		RopeLength();
        double		Epsilon();
        double		injrad();
        
        int		numComponents() { return mNumberOfComponents; };
        
        SFStrut*	getStrutList() { return mStruts; };
        int		getStrutCount() { return mStrutCount; };
        
  //  protected:
        void		ThicknessData();
        double		ComputeMaxAngle(const int inComponent, const int & i, const int & j, int inDirection);
        void		Normalize(int inComponent, const int & i, const int & j);
        
        void		addStrut( int comp1, int comp2, int v1, int v2, double pos1, double pos2 );
        
        KComponent**	mComponents;
        int		mNumberOfComponents;
        bool		jigglingEveryone;
        
        double		mEpsilon;
        
        SFStrut*	mStruts;
        SFStrut*	mLastStrut;
        int		mStrutCount;
};

#endif // _H_SFLink