function t=timedialogbox(command_str);

if nargin<1
    command_str='initialize';
end;
if ~strcmpi(command_str,'initialize')
    handles=get(gcf,'userdata');
    dialog_answer1=handles(1);
    dialog_answer2=handles(2);
end;
if strcmpi(command_str,'initialize')
    dialog=figure('Units','characters','Position',[90 30 35 6],'IntegerHandle','off',...
                  'MenuBar','none','Name','Time Interval','Tag','TimeInterval','Color',...
                  [0.8 0.8 0.8],'NumberTitle','off');
    dialog_question=uicontrol(dialog,'Style','text','Units','normalized','Position',...
                              [0.01 .7 .99 .2],'String','Specify an interval of integration',...
                              'BackgroundColor',[.8 .8 .8]);
    dialog_answer1=uicontrol(dialog,'Style','edit','Units','normalized','Position',...
                             [0.2 .2 .2 .3],'BackgroundColor',[1 1 1],'Callback','timedialogbox(''Answer1'')','Value',0);
                         
    dialog_answer2=uicontrol(dialog,'Style','edit','Units','normalized','Position',...
                             [0.6 .2 .2 .3],'BackgroundColor',[1 1 1],'Callback','timedialogbox(''Answer2'')','Value',10);
          
    handles=[dialog_answer1 dialog_answer2];
    set(dialog,'userdata',handles);
    while length(get(dialog_answer1,'userdata'))+length(get(dialog_answer2,'userdata'))<2
        drawnow;
    end;
    t=[str2num(get(dialog_answer1,'String')) str2num(get(dialog_answer2,'String'))];
    close(gcf);
elseif strcmpi(command_str,'Answer1')
    set(dialog_answer1,'userdata',1);
elseif strcmpi(command_str,'Answer2')
    set(dialog_answer2,'userdata',1);
end;

