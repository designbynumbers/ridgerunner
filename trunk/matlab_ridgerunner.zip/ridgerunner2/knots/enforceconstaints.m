function [dVdt,V]=enforceconstaints(dVdt,V);
% this function depending on the constraints on the endpoints of a component 
% modifies the coordinates of endpoints in V and the directional vectors at the
% endpoints in dVdt
global GLOB_FVDATA;
delta=.01;                                                               % accuracy for normals
NumComponents = size(GLOB_FVDATA.link.closed,1);                         % number of components
startpoint=[1 GLOB_FVDATA.link.endpoints(1:NumComponents-1)+1];          % store the indeces to
endpoint=GLOB_FVDATA.link.endpoints(1:NumComponents);                    % start and end points of components
for i=1:NumComponents                                                    % for each component
   if strcmpi(GLOB_FVDATA.link.closed{i},'open')                         % if it is not closed
      if strcmpi(GLOB_FVDATA.link.constraintsstart{i},'fixed')           % check the constraints
          dVdt(3*(startpoint(i)-1)+(1:3))=zeros(3,1);                    % if the startpoint is fixed delete the directional vector
      elseif strcmpi(GLOB_FVDATA.link.constraintsstart{i},'surface')     % if 'surface' 1. adjust the position of startpoint to the
          V=adjust(startpoint(i),V,'UserDefinedConstraints1');           % surface of constrained, 2. find the normal to it at the startpoint
          [Nstart]=normal_to_surface('UserDefinedConstraints1',V(startpoint,:),delta);
          pstart=cross(dVdt(3*(startpoint-1)+(1:3)),Nstart);             % replace the directional vector by its projection to the tangent plane
          dVdt(3*(startpoint-1)+(1:3))=cross(Nstart,pstart);
      end;                                                                % repeat the process for the endpoint
      if strcmpi(GLOB_FVDATA.link.constraintsend{i},'fixed')
          dVdt(3*(endpoint(i)-1)+(1:3))=zeros(3,1);
      elseif strcmpi(GLOB_FVDATA.link.constraintsend{i},'surface')
          V=adjust(endpoint(i),V,'UserDefinedConstraints2');
          [Nend]=normal_to_surface('UserDefinedConstraints2',V(endpoint,:),delta);
          pend=cross(dVdt(3*(endpoint-1)+(1:3)),Nend);
          dVdt(3*(endpoint-1)+(1:3))=cross(Nend,pend);
      end;
  end;
end;

          