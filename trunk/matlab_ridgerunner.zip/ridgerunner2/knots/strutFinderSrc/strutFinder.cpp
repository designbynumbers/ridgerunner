
// stuff to remember:

// - the output of strutfinder must be consistent in the sense that when the strut set
// 	is the same, the output ordering of struts and positions must be the same between
//	any two iterations

#include <stdio.h>

#include "mex.h"
#include <math.h>
#include <ctype.h>
#include "SFLink.h"

#define		kEndpointsName	"endpoints"
#define		kClosedName	"closed"
#define		kThicknessName	"thickness"

#define ABS(a)	   (((a) < 0) ? -(a) : (a))

#define SMALL_NUM  0.00000001 // anything that avoids division overflow
// dot product (3D) which allows vector operations in arguments
#define dot(u,v)   ((u).x * (v).x + (u).y * (v).y + (u).z * (v).z)
#define norm(v)    sqrt(dot(v,v))  // norm = length of vector

enum
{
    kSelfIntersection = -666
};

// some globals
double	gErrorAllowance = 0;

SFStrut* discoverStruts( double* verts, int size, linkdata & inLinkData, int & outUniqueStrutCount );
short toleranceCmp( double a, double b, double inTolerance );
bool isDuplicate( SFStrut* inList, SFStrut* inElement );
SFStrut* pruneDuplicates( SFStrut* inList, int & outUniqueStrutCount );


/*  the gateway routine.  */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
	double* verts;
	int size, row, nfields1, ifield,strutSize;
	double strutRealSize = 0;
	mxArray *tmp,*ld;

	/* Check for proper number of arguments*/
	if(nrhs < 2)
	    mexErrMsgTxt("Two inputs required.");
	if(nlhs != 4)
	    mexErrMsgTxt("Four outputs required.");

	/* Check proper input datatype */
	if( !mxIsStruct(prhs[1]))
	    mexErrMsgTxt("The second input must be a linkdata structure.");

	/* get error tolerance */
	if( nrhs >= 3 )
	{
		gErrorAllowance = *mxGetPr(prhs[2]);
	}

	/* Get fields info from the linkdata and strute structure*/
	nfields1 = mxGetNumberOfFields(prhs[1]);
	if(nfields1 < 3){
	    mexErrMsgTxt("Improperly sized link data structure! (Should be at least 8)\n");
	}
	
	#ifdef __VERBOSE__
		mexPrintf( "Init summary:\n\tnfields1: %d\n\tsize: unknown\n\trow: unknown\n", 
			nfields1 );
	#endif // __VERBOSE__
	
	verts = mxGetPr(prhs[0]); // direct copy of the pointer, we'll interp these later
	size = mxGetN(prhs[0]);
	row = mxGetM(prhs[0]);
		
	linkdata constructedLinkData;

	/* Check empty field, proper data type*/
	for(ifield = 0; ifield < nfields1; ifield++) {
	    tmp = mxGetFieldByNumber(prhs[1],0,ifield);
	    const char*	fieldName = mxGetFieldNameByNumber(prhs[1], ifield );
	    if(tmp == NULL){
        	mexPrintf("%s%d\n", "FIELD: ", ifield + 1);
        	mexErrMsgTxt("Above field is empty");
	    }
	    else
	    {
	    	// endpoints
		// closed
		// thickness
		double* foo = mxGetPr(tmp);
		
		if( strcmp( fieldName, kEndpointsName ) == 0 )
		{
			// build start vertices of components
			// and component number
			constructedLinkData.compNum = 0;

			// get endings here
			constructedLinkData.cstart = (int*)mxMalloc( sizeof(int)*(mxGetN(tmp)+10) );
			int* ends = (int*)mxMalloc( sizeof(int)*(mxGetN(tmp)+10) );
			for( int p=0; p<mxGetN(tmp); p++ )
			{
				constructedLinkData.compNum++;
				ends[p] = (int)foo[p] * 3; // multiply it by 3 because it will be with respect to the 
								// vertices themselves and not their coordinates
			}

			// munger to start positions
			constructedLinkData.cstart[0] = 0;
			for( int p=0; p<mxGetN(tmp)-1; p++ )
			{
				constructedLinkData.cstart[p+1] = (int)ends[p];	
			}
		}
		else if( strcmp( fieldName, kClosedName ) == 0 )
		{
			constructedLinkData.closed = (int*)mxCalloc( mxGetNumberOfElements(tmp)+10, sizeof(int) );

			for( int p=0; p<mxGetNumberOfElements(tmp); p++ )
			{
				mxArray* tmpField = mxGetFieldByNumber(tmp,0,p);
				if( tmpField == NULL )
				{
					mexPrintf( "Field %d of the closed component link data array is mistyped or nonexistant.", p );
					mexErrMsgTxt("\n");
				}
			/*	char* firstChar = (char*)mxGetData(tmpField);
				switch( tolower(firstChar[0]) )
				{
					case 'o': 
						constructedLinkData.closed[p] = 0;
						break;
					case 'c': */
						constructedLinkData.closed[p] = 1;
						break;
			/*		default:
						mexErrMsgTxt( "Unknown tag in link data closed field\n" );
						break;
				}*/
			}
		}
		else if( strcmp( fieldName, kThicknessName ) == 0 )
		{
			constructedLinkData.thickness = (double*)mxCalloc( mxGetN(tmp) +10, sizeof(double) );
			for( int p=0; p<mxGetN(tmp); p++ )
				constructedLinkData.thickness[p] = foo[p];
		}
	    }		
	}
        
        int uniqueStrutCount;
        
        SFStrut* list = discoverStruts(verts, row, constructedLinkData, uniqueStrutCount);
        
        // this is the self intersection indicator: 0 means no selfint, but
        // since we're doing pads now, we don't really have to worry about this
        plhs[3] = mxCreateScalarDouble( 0.0 );
		
	// create matlab arrays now that we actually have the dims
	// create some arrays for output
	int dims[2];
	dims[0] = (int)uniqueStrutCount;
	dims[1] = 4;
	plhs[0] = mxCreateNumericArray( 2, dims, mxDOUBLE_CLASS, mxREAL );
	dims[1] = 2;
	plhs[1] = mxCreateNumericArray( 2, dims, mxDOUBLE_CLASS, mxREAL );

        mexPrintf( "unique strut count: %d\n", uniqueStrutCount );

	double* indexPtr = mxGetPr( plhs[0] );
	double* positionPtr = mxGetPr( plhs[1] );
	
	// copy unique list to matlab output
        list = list->next;
	for( int i=0; i<uniqueStrutCount; i++ )
	{
            positionPtr[i+(int)(0*uniqueStrutCount)] = list->positionEdge1;
            positionPtr[i+(int)(1*uniqueStrutCount)] = list->positionEdge2;

            indexPtr[i+(int)(0*uniqueStrutCount)] = list->v1;
            indexPtr[i+(int)(1*uniqueStrutCount)] = list->v2;
            indexPtr[i+(int)(2*uniqueStrutCount)] = list->v3;
            indexPtr[i+(int)(3*uniqueStrutCount)] = list->v4;
            
            list = list->next;
	}
	
	// set the number of struts
	plhs[2] = mxCreateScalarDouble( (double)uniqueStrutCount );
	
	// sack the locally allocated struts
/*	for(int i = 0; i < allocatedSize; i++){
	     mxFree(indices[i]);
	     mxFree(locations[i]);
	}
	
//	mexPrintf( "-- allocated size: %d\n", allocatedSize );
	
  	mxFree(indices);
	mxFree(locations); 	
	
	// sack the link data
	mxFree( constructedLinkData.cstart );
	mxFree( constructedLinkData.closed );
	mxFree( constructedLinkData.thickness );
*/	
}

SFStrut*
discoverStruts( double* verts, int size, linkdata & inLinkData, int & outUniqueStrutCount )
{
    SFLink foo(verts, size, inLinkData);
    return pruneDuplicates(foo.getStrutList(), outUniqueStrutCount);
}

SFStrut*
pruneDuplicates( SFStrut* inList, int & outUniqueStrutCount )
{
    SFStrut* newList = (SFStrut*)mxMalloc(sizeof(struct SFStrut));
    newList->next = NULL;
    SFStrut* last = newList;
    
    outUniqueStrutCount = 0;
    
    // construct parallel list of nondups
    for( SFStrut* itr = inList->next; itr != NULL; itr = itr->next )
    {
        if( isDuplicate(newList, itr) == false )
        {
            outUniqueStrutCount++;
        
            SFStrut* newEl = (SFStrut*)mxMalloc(sizeof(struct SFStrut));
            newEl->v1 = itr->v1;
            newEl->v2 = itr->v2;
            newEl->v3 = itr->v3;
            newEl->v4 = itr->v4;
            
            newEl->positionEdge1 = itr->positionEdge1;
            newEl->positionEdge2 = itr->positionEdge2;
            
            newEl->next = NULL;
            
            last->next = newEl;
            last = newEl;
        }
    }
    
    return newList;
}

bool
isDuplicate( SFStrut* inList, SFStrut* inElement )
{
    // search all previous unique values until inUniqueIndex 
    // to see if this is a duplicate
    for( SFStrut* itr = inList->next; itr != NULL; itr = itr->next )
    {
        // duplicate cases for (A B C D) (s t)
                        
        // A B C D s	t
        if( (itr->v1 == (double)inElement->v1) && 
                (itr->v2 == (double)inElement->v2) && 
                (itr->v3 == (double)inElement->v3) && 
                (itr->v4 == (double)inElement->v4) && 
                (toleranceCmp(itr->positionEdge1, inElement->positionEdge1, .000000000001)==0) && 
                (toleranceCmp(itr->positionEdge2, inElement->positionEdge2, .000000000001)==0) )
        {
                return true;
        }
        // B A C D 1-s 	t
        if( (itr->v1 == (double)inElement->v2) && 
                (itr->v2 == (double)inElement->v1) && 
                (itr->v3 == (double)inElement->v3) && 
                (itr->v4 == (double)inElement->v4) && 
                (toleranceCmp(itr->positionEdge1, (1 - inElement->positionEdge1), .000000000001)==0) && 
                (toleranceCmp(itr->positionEdge2, inElement->positionEdge2, .000000000001)==0) )
        {
                return true;
        }
        // A B D C s 	1-t
        if( (itr->v1 == (double)inElement->v1) && 
                (itr->v2 == (double)inElement->v2) && 
                (itr->v3 == (double)inElement->v4) && 
                (itr->v4 == (double)inElement->v3) &&  
                (toleranceCmp(itr->positionEdge1, inElement->positionEdge1, .000000000001)==0) && 
                (toleranceCmp(itr->positionEdge2, (1 - inElement->positionEdge2), .000000000001)==0) )
        {
                return true;
        }
        // B A D C 1-s 	1-t
        if( (itr->v1 == (double)inElement->v2) && 
                (itr->v2 == (double)inElement->v1) && 
                (itr->v3 == (double)inElement->v4) && 
                (itr->v4 == (double)inElement->v3) &&  
                (toleranceCmp(itr->positionEdge1, (1 - inElement->positionEdge1), .000000000001)==0) && 
                (toleranceCmp(itr->positionEdge2, (1 - inElement->positionEdge2), .000000000001)==0) )
        {
                return true;
        }
        
        // transpose cases

        // C D A B t 	s
        int conds[6];
        conds[0] = (itr->v1 == (double)inElement->v3);
        conds[1] = (itr->v2 == (double)inElement->v4);
        conds[2] = (itr->v3 == (double)inElement->v1);
        conds[3] = (itr->v4 == (double)inElement->v2);
        conds[4] = (toleranceCmp(itr->positionEdge1, inElement->positionEdge2, .000000000001) == 0);
        conds[5] = (toleranceCmp(itr->positionEdge2, inElement->positionEdge1, .000000000001) == 0);
        
        if( conds[0] && conds[1] && conds[2] && conds[3] && conds[4] && conds[5] )
        {
            return true;
        }
        // C D B A t 	1-s
        if( (itr->v1 == (double)inElement->v3) && 
            (itr->v2 == (double)inElement->v4) && 
            (itr->v3 == (double)inElement->v2) && 
            (itr->v4 == (double)inElement->v1) && 
            (toleranceCmp(itr->positionEdge1, inElement->positionEdge2, .000000000001)==0) && 
            (toleranceCmp(itr->positionEdge2, (1 - inElement->positionEdge1), .000000000001)==0) )
        {
            return true;
        }
        // D C A B 1-t	s
        if( (itr->v1 == (double)inElement->v4) && 
            (itr->v2 == (double)inElement->v3) && 
            (itr->v3 == (double)inElement->v1) && 
            (itr->v4 == (double)inElement->v2) && 
            (toleranceCmp(itr->positionEdge1, (1 - inElement->positionEdge2), .000000000001)==0) && 
            (toleranceCmp(itr->positionEdge2, inElement->positionEdge1, .000000000001)==0) )
        {
            return true;
        }
        // D C B A 1-t	1-s
        if( (itr->v1 == (double)inElement->v4) && 
            (itr->v2 == (double)inElement->v3) && 
            (itr->v3 == (double)inElement->v2) && 
            (itr->v4 == (double)inElement->v1) && 
            (toleranceCmp(itr->positionEdge1, (1 - inElement->positionEdge2), .000000000001)==0) && 
            (toleranceCmp(itr->positionEdge2, (1 - inElement->positionEdge1), .000000000001)==0) )
        {
            return true;
        }	
    }

    return false;
}

// returns -1 if a effectively < b, +1 if b > a, and 0 if a==b
inline short toleranceCmp( double a, double b, double inTolerance )
{
        // sanity checking
        if( inTolerance < 0 )
            mexErrMsgTxt( "inTolerance < 0!\n" );

	double diff = a-b;
	if( ABS(diff) <= inTolerance )
		return 0;
	else if( diff < 0 )
		return -1;
	else
		return 1;	
}