clear COMPONENTLENGTH;
clear MOVIEMATRIX;
clear TIME;
clear COUNTER;
cla;
