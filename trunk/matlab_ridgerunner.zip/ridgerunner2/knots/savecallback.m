% savecallback
% saves the workspace variables into saveas_file_name 
% if previously specified by 'Save as'
% else switches to 'Save as' procedure
if ~isempty(saveas_file_name)
    save(saveas_file_name,'components');
else
    saveascallback;
end;
