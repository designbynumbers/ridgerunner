#include <stdio.h>

#include "mex.h"
#include <math.h>
#include <vector>
#include <ctype.h>

//#define __VERBOSE__
//#define __SUPER_VERBOSE__
//#define __TIMING__

#define ABS(a)	   (((a) < 0) ? -(a) : (a))


//3-D vertex structure of a polygon
typedef struct vertex {
  double x;
  double y;
  double z;
  
  int	globalIndex; // the index of this vertex in the global array initially
  		// passed from matlab, we need this for output formatting
}vertex;
 
//a temporary linkdata structure that contains the necessary parts for running the following functions
typedef struct linkdata {
  double compNum;//the munber of components in the linkdata
  int* cstart;//the location where each component start counting vertex not the "xyz" coordinate
  int* closed;//conresponding to cstart indicating if the last index of each component is connected back to the first component
  double* thickness;//coresponding to cstart indicating the radius of each tube
}linkdata;

typedef struct cacheCell
{
	// the positions on the edges
	double edgeOnePos, edgeTwoPos;
	// min points
	vertex	minPt[2];
} cacheCell;


void StrutMaker(double  *verts, int size,linkdata*,int ***,double ***,double *,int* );
void strutsInPair(vertex A, vertex B, vertex C, vertex D, vertex E, vertex F, int Ai, int Bi, int Ci, int Di, int Ei, int Fi, double t1, double t2, int **,double **,int *);
void minDistance( vertex A, vertex B, vertex C, vertex D,vertex *, double *, double *);
void printVertex(vertex V);
double disSquare(vertex V1,vertex V2);
void printstrut(int **, double **, int);
double calcSaneError( const int & cNum, const int* compSize, vertex** inVertices );

void createKnotCache( vertex** inVertices, int inVertexCount, int inComponentCount, 
	int* inComponentSizes, int* inComponentTypes );
void cachedMinDistance( vertex & A, vertex & B, vertex & C, vertex & D,
	vertex* outMinPtr, double* outEdgeOnePos, double* outEdgeTwoPos );

double	gErrorAllowance = -1;
cacheCell**	gCalcCache;

#ifdef __TIMING__
// variables to manage the amount of time spent in each function
// --poor man's profiling when gprof won't analyze matlab plugins
clock_t		gTableGeneration = 0;
clock_t		gStrutDiscovery = 0;
clock_t		gErrorCalc = 0;
clock_t		gDistanceSquareCalc = 0;
clock_t		gTableLookup = 0;
#endif // __TIMING__

inline bool vCompare(vertex A, vertex B )
{
	if( ABS(A.x - B.x) <= gErrorAllowance &&
		ABS(A.y - B.y) <= gErrorAllowance &&
		ABS(A.z - A.z) <= gErrorAllowance )
	{
		return true;
	}
	else
		return false;
}

// returns -1 if a effectively < b, +1 if b > a, and 0 if a==b
inline short toleranceCmp( double a, double b )
{
	double diff = a-b;
	if( ABS(diff) <= gErrorAllowance )
		return 0;
	else if( diff < 0 )
		return -1;
	else
		return 1;	
}


/*  the gateway routine.  */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
	#ifdef __TIMING__
		time_t	offset = time(NULL);
	#endif // __TIMING__
	
	srand(time(NULL));

	mexPrintf( "Strutfinder build: %s %s\n", __TIME__, __DATE__ );

	//variable declaration
	double* verts;
	int size, row, nfields1, ifield,strutSize;
	double strutRealSize = 0;
	mxArray *tmp,*ld;

	/* Check for proper number of arguments*/
	if(nrhs < 2)
	    mexErrMsgTxt("Two inputs required.");
	if(nlhs != 3)
	    mexErrMsgTxt("Three outputs required.");

	/* Check proper input datatype */
	if( !mxIsStruct(prhs[1]))
	    mexErrMsgTxt("The second input must be a linkdata structure.");

	/* get error tolerance */
	if( nrhs >= 3 )
		gErrorAllowance = *mxGetPr(prhs[2]);

	/* Get fields info from the linkdata and strute structure*/
	nfields1 = mxGetNumberOfFields(prhs[1]);
	if(nfields1 != 8){
	    mexErrMsgTxt("Improperly sized link data structure! (Should be 8)\n");
	}
	
	#ifdef __VERBOSE__
		mexPrintf( "Init summary:\n\tnfields1: %d\n\tsize: unknown\n\trow: unknown\n", 
			nfields1 );
	#endif // __VERBOSE__
	
	verts = mxGetPr(prhs[0]); // direct copy of the pointer, we'll interp these later
	size = mxGetN(prhs[0]);
	row = mxGetM(prhs[0]);
		
	linkdata constructedLinkData;

	/* Check empty field, proper data type*/
	for(ifield = 0; ifield < nfields1; ifield++) {
	    tmp = mxGetFieldByNumber(prhs[1],0,ifield);
	    if(tmp == NULL){
        	mexPrintf("%s%d\n", "FIELD: ", ifield + 1);
        	mexErrMsgTxt("Above field is empty");
	    }
	    else
	    {
	    	// 0 vertices
		// 1 component endings
		// 2 closed component?
		// 3 colors
		// 4 transparency
		// 5 tension
		// 6 thickness
		// 7 constraints
		// 8 surface
		double* foo = mxGetPr(tmp);
		switch( ifield )
		{
			case 0:
			{
				// build start vertices of components
				// and component number
				constructedLinkData.compNum = 0;
				
				// get endings here
				constructedLinkData.cstart = (int*)mxMalloc( sizeof(int)*mxGetN(tmp) );
				int* ends = (int*)mxMalloc( sizeof(int)*mxGetN(tmp) );
				for( int p=0; p<mxGetN(tmp); p++ )
				{
					constructedLinkData.compNum++;
					ends[p] = (int)foo[p] * 3; // multiply it by 3 because it will be with respect to the 
									// vertices themselves and not their coordinates
				}
				
				// munger to start positions
				constructedLinkData.cstart[0] = 0;
				for( int p=0; p<mxGetN(tmp); p++ )
					constructedLinkData.cstart[p+1] = (int)foo[p];	
			}
				break;
			case 1: // is component closed?
			{
				constructedLinkData.closed = (int*)mxMalloc( mxGetNumberOfElements(tmp) );
				
				for( int p=0; p<mxGetNumberOfElements(tmp); p++ )
				{
					mxArray* tmpField = mxGetFieldByNumber(tmp,0,p);
					if( tmpField == NULL )
					{
						mexPrintf( "Field %d of the closed component link data array is mistyped or nonexistant.", p );
						mexErrMsgTxt("\n");
					}
					char* firstChar = (char*)mxGetData(tmpField);
					switch( tolower(firstChar[0]) )
					{
						case 'o': 
							constructedLinkData.closed[p] = 0;
							break;
						case 'c': 
							constructedLinkData.closed[p] = 1;
							break;
						default:
							mexErrMsgTxt( "Unknown tag in link data closed field\n" );
							break;
					}
				}
			}
				break;
			
			// ignored data
			case 2: break;
			case 3: break;
			case 4: break;
			
			case 6: break;
			case 7: break;
			
			case 5: // thickness
				constructedLinkData.thickness = (double*)mxMalloc( mxGetN(tmp) );
				for( int p=0; p<mxGetN(tmp); p++ )
					constructedLinkData.thickness[p] = foo[p];
				break;
		}
	    }		
	}
	
	#ifdef __VERBOSE__	
		mexPrintf( "Created output structures\n" );
	#endif // __VERBOSE__
	
	#ifdef __TIMING__
		mexPrintf( "__core loop, offset: %d\n", time(NULL)-offset );
		offset = time(NULL);
	#endif // __TIMING__

	/*Call the C subroutine*/
	int** indices;
	double** locations;
	int allocatedSize;
	StrutMaker(verts,size, &constructedLinkData,&indices, &locations, &strutRealSize,&allocatedSize);
	
	#ifdef __TIMING__
		mexPrintf( "__core calcs finished, offset: %d\n", time(NULL)-offset );
		offset = time(NULL);
	#endif // __TIMING__
	
	/* create cellArray for output*/
	plhs[0] = mxCreateCellMatrix((int)strutRealSize,4);
	plhs[1] = mxCreateCellMatrix((int)strutRealSize,2);
	
	// here we copy the "percentage on the edge" date for strut positioning
	for( int i=0; i<strutRealSize; i++ )
	{
		int subs[2];
		subs[0] = i;
		
		for( int j=0; j<2; j++ )
		{
			subs[1] = j;
			mxSetCell( plhs[1], mxCalcSingleSubscript(plhs[1],2,subs), mxCreateScalarDouble((double)locations[i][j]) );
		}
	}
	
	// here copy the indices that compose the struts
	for( int i=0; i<strutRealSize; i++ )
	{
		// bump indices value because output should be 1 based for matlab purposes
		mxSetCell( plhs[0], i+(int)(0*strutRealSize), mxCreateScalarDouble( (double)(indices[i][0]+1) ) );
		mxSetCell( plhs[0], i+(int)(1*strutRealSize), mxCreateScalarDouble( (double)(indices[i][1]+1) ) );
		mxSetCell( plhs[0], i+(int)(2*strutRealSize), mxCreateScalarDouble( (double)(indices[i][2]+1) ) );
		mxSetCell( plhs[0], i+(int)(3*strutRealSize), mxCreateScalarDouble( (double)(indices[i][3]+1) ) );
	}
	
	// set the number of struts
	plhs[2] = mxCreateScalarDouble( strutRealSize );
	
	// n^2 direct dup check
/*	int dups = 0;
	bool	*dupArr = (bool*)mxCalloc( (int)strutRealSize, sizeof(bool) );
	for( int i=0; i<strutRealSize; i++ )
		dupArr[i] = false;
	for( int i=0; i<strutRealSize; i++ )
	{
		for( int j=i+1; j<strutRealSize; j++ )
		{
			if( dupArr[j] == true )
				continue;
		
			if( indices[i][0] != indices[j][0] )
				continue;
			if( indices[i][1] != indices[j][1] )
				continue;
			if( indices[i][2] != indices[j][2] )
				continue;
			if( indices[i][3] != indices[j][3] )
				continue;
			
			if( locations[i][0] != locations[j][0] )
				continue;
			if( locations[i][1] != locations[j][1] )
				continue;
			
			dupArr[j] = true;
		}
	}

	for( int i=0; i<strutRealSize; i++ )
		if( dupArr[i] == true )
			dups++;
		
	mexPrintf( "direct dups: %d\n", dups );
	// ***************************************************************************************************
	dups = 0;
	// n^2 transpose dup check
	for( int i=0; i<strutRealSize; i++ )
		dupArr[i] = false;
	for( int i=0; i<strutRealSize; i++ )
	{
		for( int j=i+1; j<strutRealSize; j++ )
		{
			if( dupArr[j] == true )
				continue;
		
			if(	( indices[i][0] == indices[j][2] ) &&
				( indices[i][1] == indices[j][3] ) &&
				( indices[i][2] == indices[j][0] ) &&
				( indices[i][3] == indices[j][1] ) &&
				( toleranceCmp(locations[i][0], locations[j][1]) == 0 ) &&
				( toleranceCmp(locations[i][1], locations[j][0]) == 0 ) )
			{
				dupArr[j] = true;
			}
		}
	}

	for( int i=0; i<strutRealSize; i++ )
		if( dupArr[i] == true )
			dups++;
			
	mexPrintf( "transpose dups: %d\n", dups );
	// ***************************************************************************************************
	*/
	
	// sack the locally allocated struts
/*	for(int i = 0; i < allocatedSize; i++){
	     mxFree(indices[i]);
	     mxFree(locations[i]);
	}
	
	mexPrintf( "-- allocated size: %d\n", allocatedSize );
	
  	mxFree(indices);
	mxFree(locations); 	
	
	// sack the link data
	mxFree( constructedLinkData.cstart );
	mxFree( constructedLinkData.closed );
	mxFree( constructedLinkData.thickness );*/
	
	#ifdef __TIMING__
		mexPrintf( "__dumped to matlab and term, offset: %d\n", time(NULL)-offset );
	#endif // __TIMING__
}



/*StrutMaker takes in the vertices of a polygon in froms of [x1,y1,z1,x2,y2,z2...,xn,yn,zn] array, the array size, and a linkdata structure.
  It returns all the possible struts inside the polygon in array form.*/
void StrutMaker(double *verts, int size, linkdata* ld, int ***Index,double ***Location,double *strutNum, int* allocatedSize){
	
  //variable declaration
  const int csize = size/3;
  const int cNum = (int)ld->compNum;
  int strutCount = 0;
  int **sIndex ;
  double **sLocation;
  vertex **p; //p is a point to vertex* which is used for putting each component into a array of its vertices, kind like a 2-D array
  vertex *vArray; //vArray contains the vertices of the polygon
  int i,k,m = 0,l,n,j;
  int realN; //this is the size of each component without adding the first and second elements into the component array p
  int iA,iB,iC,iD,iE,iF; //the index in the vArray 
  int *compSize; //coresponding to cstart indicating the size of each component
  int *realSize;//coresponding to cstart indicating the size of each component without adding the extra elements if a component is closed
  
  #ifdef __VERBOSE__
	mexPrintf( "StrutMaker calling summary:\n" );
	mexPrintf( "\tcsize (a.k.a. vertex count): %d\n", csize );
	mexPrintf( "\tcNum (a.k.a. linkData compNum): %d\n--\n", cNum );
  #endif // __VERBOSE__

  vArray = (vertex*)mxCalloc(csize+1,sizeof(vertex));
  compSize = (int*)mxCalloc(cNum,sizeof(int));
  realSize = (int*)mxCalloc(cNum,sizeof(int));
 
  //get a block mem ory for the 2-D array p 
  p = (vertex **)mxCalloc(cNum,sizeof(vertex *));
	 
  //sort the verts into vertex form and put them to vArray, so the size of vArray will be 1/3 of the size of verts
  for(i = 0; i < (size/3); i++){
    //vArray has real values stars index 1 so that its easier to find out start component according to cstart
    vArray[i+1].globalIndex = i;
    
    vArray[i+1].x = *(verts+i*3);
    vArray[i+1].y = *(verts+i*3+1);
    vArray[i+1].z = *(verts+i*3+2);
    
    #ifdef __VERBOSE__
    	printVertex(vArray[i+1]);
    #endif // __VERBOSE__
   }
   
  //putting the vertices from vArray into the 2-D array p
  for(i = 0; i < cNum; i++){
    m = ld->cstart[i];
    
    if(i+1==cNum){
      n = (size/3) - ld->cstart[i] + 1 + (ld->closed[i] ? 1 : 0);
      if(ld->closed[i]==1)
	realN = n -1;
      else
	realN = n;
    }
    else{
      n = ld->cstart[i + 1] - ld->cstart[i] + (ld->closed[i] ? 1 : 0);
       if(ld->closed[i]==1)
	realN = n -1;
      else
	realN = n;
    }

	// make this one based for easier processing below
    compSize[i] = n;
    realSize[i] = realN;
    
	#ifdef __VERBOSE__
     		mexPrintf( "Component %d p[i] alloc n: %d\n", i, n );
	#endif // __VERBOSE__
    
    /* Assuming that n is the component size */
    p[i] = (vertex *)(mxCalloc(n-1,sizeof(vertex)));
    l = 0;
    if(ld->closed[i] == 0){
      while(l < n){
	p[i][l].x = vArray[m+1].x; 
	p[i][l].y = vArray[m+1].y;
	p[i][l].z = vArray[m+1].z;
	p[i][l].globalIndex = vArray[m+1].globalIndex;
	l++;
	m++;
      }
    }
    
   else{
      while(l < n-2){
	p[i][l].x = vArray[m+1].x; 
	p[i][l].y = vArray[m+1].y;
	p[i][l].z = vArray[m+1].z;
	p[i][l].globalIndex = vArray[m+1].globalIndex;
	l++;
	m++;
      }
      p[i][n-2].x = p[i][0].x;
      p[i][n-2].y = p[i][0].y;
      p[i][n-2].z = p[i][0].z;
      p[i][n-2].globalIndex = p[i][0].globalIndex;
     //if closed put the start element as the last element
   }       
   
   	// build up the cache table
	createKnotCache( p, csize, (int)ld->compNum, compSize, ld->closed );
   
   	double saneError = calcSaneError( cNum, compSize, p );
   	if( gErrorAllowance == -1 ) // implies it has not been set by the user
		gErrorAllowance = (.1 * saneError);
   	else if( saneError < gErrorAllowance )
	{
		mexPrintf( "The acceptable error value you have provided (%f)\n", gErrorAllowance );
		mexPrintf( "is probably too high to discriminate struts on the\n" );
		mexPrintf( "average side length of the provided knot.\n" );
		mexPrintf( "\t* Maximum useful value: %f\n", saneError );
		mexPrintf( "\t* Recommended value: %f\n", saneError * .1 );
	}
	
   	
	#ifdef __VERBOSE__
	
   		// summary statement			
		mexPrintf( "Vertex processing summary for %d\n", i );
		for( int j=0; j<n-1; j++ )
			mexPrintf( "\t%f, %f, %f\n", p[i][j] );
		mexPrintf( "--\n" );
		
		for( int j=0; j<cNum; j++ )
			mexPrintf( "Component size %d: %d (but actually %d)\n", j, compSize[j], compSize[j]-1 );
		mexPrintf( "--\n" );
	 
	#endif // __VERBOSE__
     		
  }
  
  	// initial sizing of strut output data
	int strutStorage = (int)(csize*2.2); // slightly more than twice the vertex count is probably reasonable
		
	sIndex  = (int  **)mxCalloc(strutStorage,sizeof(int *));
	for(i = 0; i < strutStorage; i++)
		sIndex[i] = (int  *)mxCalloc(4,sizeof(int ));
	sLocation = (double **)mxCalloc(strutStorage,sizeof(double *));
	for(i = 0; i < strutStorage; i++)
		sLocation[i] = (double *)mxCalloc(4,sizeof(double));
  
  	#ifdef __VERBOSE__
		mexPrintf( "sIndex and sLocation allocated\n--\n" );
	#endif // __VERBOSE__
  
  // *** ALGORITHM: for all components (which we just built vertex arrays for), 
  // 		for each point in a component, iterate over all other points
  //		(in its and each other component), and generate 2 triples of
  //		points to check for strut conditions using strutsInPair()
  	strutCount = 0;
	
	// NOTE: 0 based indexing because p array is indexed as such
  
  	vertex tripleOne[3], tripleTwo[3];
	for( int compIndex=0; compIndex<ld->compNum; compIndex++ )
	{
		// we always decrement compSize[compIndex] and other compSize data because
		// it is from the 1 based vertex array, and p[][] is 0 based and it includes
		// the extra "edge" from the closing of the figure <---- need to update that before 
		// dealing with open figures, probably by subsituting realSize for compSize
		for( int vertIndex=0; vertIndex<compSize[compIndex]-2; vertIndex++ )
		{
			// kludge alert: this presumes that the knots are closed
			// because of the mod. Is there a way to chop up non-closed figures that
			// will handle the case where vertices%3!=0?
			if( (vertIndex + 2) >= (compSize[compIndex] - 1) &&
			    (ld->closed[compIndex] == 0) )
				continue;
			
			#ifdef __SUPER_VERBOSE__
				mexPrintf( "OUTER INDICES: %d %d %d\n", vertIndex,
					(vertIndex + 1) % (compSize[compIndex]-2),
					(vertIndex + 2) % (compSize[compIndex]-2) );
			#endif // __SUPER_VERBOSE__
			
			tripleOne[0] = p[compIndex][vertIndex];
			tripleOne[1] = p[compIndex][(vertIndex + 1) % (compSize[compIndex]-2)];
			tripleOne[2] = p[compIndex][(vertIndex + 2) % (compSize[compIndex]-2)];
			
			// we have the first triple, now, match it with all others
			for( int compareComp=0; compareComp<ld->compNum; compareComp++ )
			{
				for( int compareVert=0; compareVert<compSize[compareComp]-2; compareVert++ )
				{
					// don't compare to self
					if( compareComp == compIndex && vertIndex == compareVert )
						continue;
					
					if( (compareVert + 2) >= (compSize[compareComp] - 1) &&
					    (ld->closed[compareComp] == 0) )
						continue;
				
					#ifdef __SUPER_VERBOSE__
						mexPrintf( "\tINNER INDICES: %d %d %d\n", compareVert,
							(compareVert + 1) % (compSize[compareComp]-2),
							(compareVert + 2) % (compSize[compareComp]-2) );
					#endif // __SUPER_VERBOSE__
				
					tripleTwo[0] = p[compareComp][compareVert];
					tripleTwo[1] = p[compareComp][(compareVert + 1) % (compSize[compareComp]-2)];
					tripleTwo[2] = p[compareComp][(compareVert + 2) % (compSize[compareComp]-2)];
					
					// grab the struts between these two points by calling
					// strutsInPair(), which will append any struts
					// between these vertex sets to the strut indices
					strutsInPair( tripleOne[0], tripleOne[1], tripleOne[2],
						tripleTwo[0], tripleTwo[1], tripleTwo[2],
						// now the global indices
						tripleOne[0].globalIndex, tripleOne[1].globalIndex, tripleOne[2].globalIndex,
						tripleTwo[0].globalIndex, tripleTwo[1].globalIndex, tripleTwo[2].globalIndex,
						// thickness of the first component and its comparison component
						ld->thickness[compIndex], ld->thickness[compareComp],
						// storage for the struts
						sIndex, sLocation,
						// will be incremented by the number of struts discovered
						&strutCount );
					
					// check to make sure strutCount isn't within 10 of the max and double / copy 
					// if it is
					if( strutCount + 10 >= strutStorage )
					{
						#ifdef __VERBOSE__
							mexPrintf( "*** Strut storage double to size: %d\n", strutStorage*2 );
						#endif // __VERBOSE__
						
						int** newIndices = (int**)mxCalloc(strutStorage*2,sizeof(int*));
						double** newLocations = (double**)mxCalloc(strutStorage*2,sizeof(double*));
						
						// we actually don't have to copy the internal data since it will be unchanged
						// and its already a pointer type, so just copy the pointers. The memcpy below
						// will effectively perform a faster version of the following:
						// 
						//	for( int i=0; i<strutStorage; i++ )
						//	{
						//		newIndices[i] = sIndex[i];
						//		newLocations[i] = sLocation[i];
						//	}
						//
						// because most architectures can move > 4 bytes at once in an optimized memcpy()
						memcpy( newIndices, sIndex, sizeof(int*)*strutStorage );
						memcpy( newLocations, sLocation, sizeof(double*)*strutStorage);
						// now allocate the extra strutStorage space we created for in newIndices and locations
						for( int i=0; i<strutStorage; i++ )
						{
							newIndices[i+strutStorage] = (int*)mxCalloc(4,sizeof(int));
							newLocations[i+strutStorage] = (double*)mxCalloc(4,sizeof(double));
						}
						// update the storage to current
						strutStorage *= 2;
						// sack the old index and location pointers, but not their associated contents
						// because we retain them in the new structures
						mxFree( sIndex );
						mxFree( sLocation );
						// and finally update
						sIndex = newIndices;
						sLocation = newLocations;
					}
				}
			}
		}
	}
   
  (*Index) = sIndex;
  (*Location) = sLocation;
  (*allocatedSize) = strutStorage;
  
  *strutNum = strutCount;
 
  //deallocate memory
   for(i = 0; i < cNum; i++)
     mxFree(p[i]);
   mxFree(p);   
   mxFree(vArray);
   mxFree(compSize);
   mxFree(realSize);
}       

void
createKnotCache( vertex** inVertices, int inVertexCount, int inComponentCount, int* inComponentSizes, int* inComponentTypes )
{
	#ifdef __TIMING__
		clock_t startTime = clock();
	#endif // __TIMING__

	// create a VxV array to cache minDistance results between all edge pairs
	// vertex 0 starts edge 0, vertex 1 bounds edge 1, vertex 2 bounds edge 2, and so on
	
	gCalcCache = (cacheCell**)mxCalloc( inVertexCount+1, sizeof(cacheCell*) );
	for( int i=0; i<inVertexCount; i++ )
		gCalcCache[i] = (cacheCell*)mxCalloc( inVertexCount+1, sizeof(cacheCell) );
	
	vertex *a, *b, *c, *d;
	
	//mexPrintf( "knot cache of size %dx%d\n", inVertexCount, inVertexCount );
	
	// same looping structure as the principle StrutMaker code
	for( int compIndex=0; compIndex<inComponentCount; compIndex++ )
	{
		for( int vertIndex=0; vertIndex<inComponentSizes[compIndex]-2; vertIndex++ )
		{
			// get first edge pair
			a = &(inVertices[compIndex][vertIndex]);
			if( (vertIndex+1) == (inComponentSizes[compIndex]-1) )
			{
				// if this is an open figure, we shouldn't do this calculation
				if( inComponentTypes[compIndex] == 0 )
					continue;
			}
			b = &(inVertices[compIndex][(vertIndex + 1) % (inComponentSizes[compIndex]-1)]);
						
			for( int compareComp=0; compareComp<inComponentCount; compareComp++ )
			{
				for( int compareVert=0; compareVert<inComponentSizes[compareComp]-2; compareVert++ )
				{
					// avoid self comparison
					if( compareComp == compIndex && vertIndex == compareVert )
						continue;
								
					// get second edge pair
					c = &(inVertices[compareComp][compareVert]);
					if( (compareVert+1) == (inComponentSizes[compareComp]-1) )
					{
						// if this is an open figure, we shouldn't do this calculation
						if( inComponentTypes[compareComp] == 0 )
							continue;
					}
					d = &(inVertices[compareComp][(compareVert + 1) % (inComponentSizes[compareComp]-1)]);
										
					minDistance( *a, *b, *c, *d, gCalcCache[a->globalIndex][c->globalIndex].minPt, 
						&(gCalcCache[a->globalIndex][c->globalIndex].edgeOnePos),
						&(gCalcCache[a->globalIndex][c->globalIndex].edgeTwoPos) );
				}
			}
		}
	}
	
	#ifdef __TIMING__
		gTableGeneration = clock() - startTime;
	#endif // __TIMING__
}


double
calcSaneError( const int & cNum, const int* compSize, vertex** inVertices )
{
	#ifdef __TIMING__
		clock_t	startTime = clock();
	#endif // __TIMING__

	/* here we take the average of a sampling of random successive vertex pairs 
	   to determine the average side length. The maximum sane error side is 
	   defined to be (1/3)*(avg side length) (and should probably be smaller still)
	 */
	 
	double avgSideLen = 0;
	for( int i=0; i<10; i++ )
	{
		// choose a random index to sample
		int component = (rand() % cNum);
		int a = (rand() % compSize[component]);
		int b = (a+1 == compSize[component]) ? 0 : a + 1;

		// get difference
		vertex diff;
		diff.x = inVertices[component][b].x - inVertices[component][a].x;
		diff.y = inVertices[component][b].y - inVertices[component][a].y;
		diff.z = inVertices[component][b].z - inVertices[component][a].z;

		// normalize
		double r = (diff.x * diff.x + diff.y * diff.y + diff.z * diff.z);
		avgSideLen += sqrt(r);
	}
	// average
	avgSideLen /= 10;
	
	#ifdef __TIMING__
		gErrorCalc = clock() - startTime;
	#endif // __TIMING__
	
	return (.33333333333 * avgSideLen );
}

void strutsInPair(vertex A, vertex B, vertex C, vertex D, vertex E, vertex F,int Ai, int Bi, int Ci, int Di, int Ei, int Fi, double abcThickness, double defThickness, int **sIndex,double **sLocation,int *count){
  int scount;
  
  double sa,sb,sc,sd,strutLength, s1, t1, s2, t2, s3, t3, s4, t4;
  
  vertex minpt1[2];
  vertex minpt2[2];
  vertex minpt3[2];
  vertex minpt4[2];
	
  scount = *count;
  
  // these are the old on the fly calculations...
/*  minDistance(A,B,D,E,minpt1,&s1, &t1);
  minDistance(B,C,E,F,minpt2, &s2, &t2);
  minDistance(B,C,D,E,minpt3, &s3, &t3);
  minDistance(A,B,E,F,minpt4, &s4, &t4);
*/

	// ... replaced with a significantly faster table lookup
	cachedMinDistance(A,B,D,E,minpt1,&s1, &t1);
	cachedMinDistance(B,C,E,F,minpt2, &s2, &t2);
	cachedMinDistance(B,C,D,E,minpt3, &s3, &t3);
	cachedMinDistance(A,B,E,F,minpt4, &s4, &t4);	

	#ifdef __TIMING__
		clock_t startTime = clock();
	#endif // __TIMING__
	sa = disSquare(minpt1[0],minpt1[1]);
	sb = disSquare(minpt2[0],minpt2[1]);
	sc = disSquare(minpt3[0],minpt3[1]);
	sd = disSquare(minpt4[0],minpt4[1]);  
	#ifdef __TIMING__
		gDistanceSquareCalc += (clock() - startTime);
	#endif // __TIMING__

  // calculate the expected strut length here as dist^2 (that's how we'll do all distances so
  // there's no need to take roots)
  strutLength = (abcThickness+defThickness)*(abcThickness+defThickness);
  
  if(toleranceCmp(sa, strutLength)==0){
  	// VERTEX -> EDGE, E->A-B
    if(toleranceCmp(sa, sd)==0 && (vCompare(minpt1[1],E) == true) && (vCompare(minpt1[0],A) == false) && (vCompare(minpt1[0],B) == false)){
      sIndex[scount][0] = Ai;
      sIndex[scount][1] = Bi;
      sIndex[scount][2] = Di;
      sIndex[scount][3] = Ei;
      sLocation[scount][0] = s1;
      sLocation[scount][1] = t1;
      scount++;
    }
    	// VERTEX -> EDGE, B->D-E
      if((toleranceCmp(sa, sc)==0) && (vCompare(minpt1[0],B) == true)&& (vCompare(minpt1[1],D) == false) && (vCompare(minpt1[1],E) == false)){
	sIndex[scount][0] = Ai;
      sIndex[scount][1] = Bi;
      sIndex[scount][2] = Di;
      sIndex[scount][3] = Ei;
      sLocation[scount][0] = s1;
      sLocation[scount][1] = t1;
	scount++;
      }
      
      	// VERTEX -> VERTEX, B->E
      if((toleranceCmp(sa, sb)==0) && (toleranceCmp(sa, sc)==0) && (toleranceCmp(sa, sd)==0) ){
	sIndex[scount][0] = Ai;
      sIndex[scount][1] = Bi;
      sIndex[scount][2] = Di;
      sIndex[scount][3] = Ei;
      sLocation[scount][0] = s1;
      sLocation[scount][1] = t1;

	scount++;
      }
      
      	// EDGE -> EDGE, A-B->D-E
      if((vCompare(minpt1[0],A) == false) && (vCompare(minpt1[0],B) == false) && (vCompare(minpt1[1],D) == false) && (vCompare(minpt1[1],E) == false)){
      sIndex[scount][0] = Ai;
      sIndex[scount][1] = Bi;
      sIndex[scount][2] = Di;
      sIndex[scount][3] = Ei;
      sLocation[scount][0] = s1;
      sLocation[scount][1] = t1;
	scount++;
      }
  }
  if(toleranceCmp(sb, strutLength)==0){
  	// EDGE -> VERTEX, B-C->E
    if((toleranceCmp(sb, sc)==0) && (vCompare(minpt2[1],E) == true) && (vCompare(minpt2[0],B) == false) && (vCompare(minpt2[0],C) == false)){
      	sIndex[scount][0] = Bi;
      sIndex[scount][1] = Ci;
      sIndex[scount][2] = Di;
      sIndex[scount][3] = Ei;
      sLocation[scount][0] = s3;
      sLocation[scount][1] = t3;
     
      scount++;
    }
    
    	// VERTEX -> EDGE, B->B-C
    if((toleranceCmp(sb, sd)==0) && (vCompare(minpt2[0],B) == true)&& (vCompare(minpt2[1],E) == false) && (vCompare(minpt2[1],F) == false)){
      	sIndex[scount][0] = Ai;
      sIndex[scount][1] = Bi;
      sIndex[scount][2] = Ei;
      sIndex[scount][3] = Fi;
      sLocation[scount][0] = s4;
      sLocation[scount][1] = t4;
    
      scount++;
    }
    
    	// EDGE -> EDGE, B-C->E-F
    if((vCompare(minpt2[0],B) == 0) && (vCompare(minpt2[0],C) == false) && (vCompare(minpt2[1],E) == false) && (vCompare(minpt2[1],F) == false)){
      	sIndex[scount][0] = Bi;
      sIndex[scount][1] = Ci;
      sIndex[scount][2] = Ei;
      sIndex[scount][3] = Fi;
      sLocation[scount][0] = s2;
      sLocation[scount][1] = t2;
     
      scount++;
    }
  }
  if((toleranceCmp(sc, strutLength)==0)){
   	// EDGE -> EDGE, B-C->D-E
    if((vCompare(minpt3[0],B) == false) && (vCompare(minpt3[0],C) == false) && (vCompare(minpt3[1],D) == false) && (vCompare(minpt3[1],E) == false)){
      	sIndex[scount][0] = Bi;
      sIndex[scount][1] = Ci;
      sIndex[scount][2] = Di;
      sIndex[scount][3] = Ei;
      sLocation[scount][0] = s3;
      sLocation[scount][1] = t3;
    
      scount++;
    }
  }
  if(toleranceCmp(sd, strutLength)==0){
  	// EDGE -> EDGE, A-B->E-F
    if((vCompare(minpt4[0],A) == false) && (vCompare(minpt4[0],B) == false) && (vCompare(minpt4[1],E) == false) && (vCompare(minpt4[1],F) == false)){
      	sIndex[scount][0] = Ai;
      sIndex[scount][1] = Bi;
      sIndex[scount][2] = Ei;
      sIndex[scount][3] = Fi;
      sLocation[scount][0] = s4;
      sLocation[scount][1] = t4;
       
      scount++;
    }
    }
  *count = scount;
}

/* 
 *	input is edges bounded by vertices A-B and C-D.
 *	output is:
 *		minPtr, the vertices bounding the potential strut
 *		ps, the location of strut on A-B in terms of percentage of its length
 *		pt, the location of strut on C-D in terms of percentage of its length
 */
void minDistance (vertex A, vertex B, vertex C, vertex D, vertex *minPtr, double *ps, double *pt ){
  vertex u1;
  vertex u2;
  vertex u3;
  vertex p1,p2;
        
  double c1,c2,c3,c4,c5;
  double s,t;
	
  //calculate u1=B-D
  u1.x = B.x - D.x;
  u1.y = B.y - D.y;
  u1.z = B.z - D.z;
	

  //calculate u2=D-C
  u2.x = D.x - C.x;
  u2.y = D.y - C.y;
  u2.z = D.z - C.z;
       
	
  //calculate u3=A-B
  u3.x = A.x - B.x;
  u3.y = A.y - B.y;
  u3.z = A.z - B.z;
        


  //calculte the inner product of B-D and D-C
  c1 = u1.x * u2.x + u1.y * u2.y + u1.z * u2.z;
 
  //calculate the inner product of A-B and D-C
  c2 = u3.x * u2.x + u3.y * u2.y + u3.z * u2.z;
 
  //calculate the square of the norm for D-C
  c3 = u2.x * u2.x + u2.y * u2.y + u2.z * u2.z;

  //calculate the inner product of B-D and A-B
  c4 = u1.x * u3.x + u1.y * u3.y + u1.z * u3.z;
 

  //calculate the square of the norm for A-B
  c5 = u3.x * u3.x + u3.y * u3.y + u3.z * u3.z;

  //test if the two lines are parallel
       
  if(fabs(c2*c2 - c3*c5) <= 0.000001){
    c1 = disSquare(A,C);
    c2 = disSquare(A,D);
    c3 = disSquare(B,C);
    c4 =  disSquare(B,D);
    if((c1<= c2) && (c1 <= c3) && (c1 <=c4)){
      minPtr[0] = A;
      s = 0;
      minPtr[1] = C;
      t = 0;
    }
    if((c2 <= c1) && (c2 <= c3) && (c2 <= c4)){
      minPtr[0] = A;
      s = 0;
      minPtr[1] = D;
      t = 1;
    }
    if((c3 <= c1) && (c3 <= c2) && (c3 <= c4)){
      minPtr[0] = B;
      s = 1;
      minPtr[1] = C;
      t = 0;
    }
    if((c4 <= c1) && (c4 <= c2) && (c4 <= c3)){
      minPtr[0] = B;
      s = 1;
      minPtr[1] = D;
      t = 1;
    }
  }
  else{  
    //calculate s and t
       
    s = ( (c1 * c5 - c4 * c2)) / ( c2 * c2 - c3 * c5);
    t = (c1*c2 - c3*c4)/(c3*c5 -c2*c2) ;
   
    //adjusting semi-Interior condition
    if((s < 0) ||( s > 1) ||( t < 0)||(t > 1)){
      if((s < 0)||(s > 1)){
	if((-c1/c3 > 0) && (-c1/c3 < 1)){
	  t = 0;
	  s = -c1/c3;
	}
	if(((-c1-c2)/c3 > 0)&&((-c1-c2)/c3 <1)){
	  t = 1;
	  s = (-c1-c2)/c3;
	}
      }
      if((t < 0)||(t > 1)){
	if((-c4/c5 > 0) && (-c4/c5 < 1)){
	  s = 0;
	  t = -c4/c5;
	}
	if(((-c2-c4)/c5 > 0)&&((-c2-c4)/c5 <1)){
	  s = 1;
	  t = (-c2-c4)/c5;
	}
      } 
    } 

    //adjusting  corner conditions
    if(s < 0)
      s = 0;
    if(s > 1)
      s = 1;
    if(t < 0)
      t = 0;
    if(t > 1)
      t = 1;
   
    //find the points on the line segments
    p1.x = B.x + t * u3.x;
    p1.y = B.y + t * u3.y;
    p1.z = B.z + t * u3.z;
    minPtr[0] = p1;
    p2.x = D.x + s * (-1)*u2.x;
    p2.y = D.y + s * (-1)*u2.y;
    p2.z = D.z + s * (-1)*u2.z;
    minPtr[1] = p2;
  } 
  *ps = s;
  *pt = t;
}

void
cachedMinDistance( vertex & A, vertex & B, vertex & C, vertex & D,
	vertex* outMinPtr, double* outEdgeOnePos, double* outEdgeTwoPos )
{
	// same i/o interface as minDistance(), except here we look up the results
	// in the edge<->edge cache table instead of calculating it
	
	// note: A<->B is one edge, C<->D is another. A and C's global indices 
	// also index the cache table.
	// cache[A's gid][C's gid] is the minValue results from 
	// minValue(A,B,C,D)
	
	cacheCell* result = &(gCalcCache[A.globalIndex][C.globalIndex]);
	
	outMinPtr[0].x = result->minPt[0].x;
	outMinPtr[0].y = result->minPt[0].y;
	outMinPtr[0].z = result->minPt[0].z;
	
	outMinPtr[1].x = result->minPt[1].x;
	outMinPtr[1].y = result->minPt[1].y;
	outMinPtr[1].z = result->minPt[1].z;
	
	*outEdgeOnePos = result->edgeOnePos;
	*outEdgeTwoPos = result->edgeTwoPos;
}

void printstrut(int **pIndex, double **pLocation, int num){
  int i,j,k;
  for(i = 0;i < num;i++){
    for(j = 0; j < 4;j++)
      printf("index[%d][%d]:%d ",i,j,pIndex[i][j]);
    for(k = 0; k < 2; k++)
      printf("location[%d][%d]:%f ",i,k,pLocation[i][k]);
     printf("\n");
  }
}

void printVertex(vertex V){
  printf("\t%f %f %f (gid: %d)\n",V.x, V.y,V.z, V.globalIndex);
}

double disSquare(vertex V1, vertex V2){
  double d;
  d = (V2.x - V1.x)*(V2.x - V1.x) + (V2.y - V1.y)*(V2.y - V1.y) 
    +(V2.z - V1.z)*(V2.z - V1.z);
  return d;
} 
