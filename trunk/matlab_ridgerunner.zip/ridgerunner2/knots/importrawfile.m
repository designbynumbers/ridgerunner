function [link,verts] = importrawfile(import_path_and_file_name)

% importmingfile
% This script reads raw type link files into our program.
%
% Each component is a list of 3d coords, separated by a space or tab or
% something.  Different components are separated by an empty line.
%
% The typical raw file starts out
% x1 y1 z1
% x2 y2 z2
% ...
% xn yn zn
% sometimes there are commas, tabs or other white space in 
% between the x, y, and z coordinates

% We first set up a linkdata structure to receive our data.

% We are now ready to load this data into a linkdata structure.

link=struct('endpoints',[],...
            'closed',{[]},...
            'colorvalues',{[]},...
            'transparency',[],...
            'tension',[],...
            'thickness',[],...
            'constraints',{[]},...
            'surface',{[]},...
            'edgecolorvalues',{[]});

% First, we get the file, and read the lines into an array of strings.

A=textread(import_path_and_file_name,'%s','delimiter','\n');

[numberoflines,dummy] = size(A);

% We are going to figure out how many components we have an how many edges are
% in each component. Then we will load the vertices.  

component = 1;
i = 1;
shouldwekeepgoing = 1;


while(shouldwekeepgoing == 1)
  if( strcmp(A(i),'') == 1 )
    link.endpoints(component) = i - component;
    component = component + 1;
    i = i + 1;
  else
    if( i == numberoflines )
      link.endpoints(component) = i - component + 1;
      shouldwekeepgoing = 0;
      break;
    else
      i = i + 1;
    end;
  end;  
end;

  
% We have a total of number_of_vertices vertices in components
% number of components

number_of_vertices = numberoflines - component + 1;


% Our next task is to load the vertices
% Here we prepare link.endpoints and Closed for input.
if(component == 1)
  link.endpoints(1)=number_of_vertices;
  link.closed{1}='closed';
else
  for k=1:component
    link.closed{k} = 'closed';
  end;
end;

% We now read all the vertices into the V array.

verts=zeros(number_of_vertices,3);
whichcomponent = 1;

for i=1:numberoflines
  if( i == (link.endpoints(whichcomponent) + whichcomponent) )
    whichcomponent = whichcomponent + 1;
    i = i + 1;
  end;

  vertexnumber = i - whichcomponent + 1;
  verts(vertexnumber,:)=str2num(char(A(i)));
  
end;

verts = reshape(verts',3*size(verts,1),1);

% set all of these as defaults
if(component == 1)
  link.transparency(1) = 1;
  link.tension(1) = 1;
  link.thickness(1) = 1;
  link.constraints{1} = 'none';
  link.colorvalues{1} = [0.9961 0.0742 0.9375];
  link.edgecolorvalues{1} = [0.6055 0.0742 0.9375];
else
  for k=1:component
    link.transparency(k) = 1;
    link.tension(k) = 1;
    link.thickness(k) = 1;
    link.constraints{k} = 'none';
    link.colorvalues{k} = [0.9961 0.0742 0.9375];
    link.edgecolorvalues{k} = [0.6055 0.0742 0.9375];
  end;
end;

