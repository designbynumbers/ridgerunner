function [link,verts,numcomp] = importvectfile(import_path_and_file_name)

% importvectfile
% This script reads Geomview VECT files into our program.

% We first set up a linkdata structure to receive our data.

% We are now ready to load this data into a linkdata structure.

link=struct('endpoints',[],...
            'closed',{[]},...
            'colorvalues',{[]},...
            'transparency',[],...
            'tension',[],...
            'thickness',[],...
            'constraints',{[]},...
            'surface',{[]},...
            'edgecolorvalues',{[]});

% First, we get the file, and read the lines into an array of strings.

A=textread(import_path_and_file_name,'%s','delimiter','\n');

% We test the first line for the keyword "VECT"

if (size(findstr(A{1},'VECT'),1) == 0)
    
    error('Import file: The file does not appear to be a VECT file.');
    
end;

% Next, we load the first three numbers: the number of components, vertices, and colors.

NNN=str2num(char(A(2)));
number_of_components=NNN(1);
number_of_vertices=NNN(2);
number_of_colors=NNN(3);

% Our next task is to load the number of vertices in each component (NVC)
% We will use this to compute the link.endpoints array giving the end vertex of each component

NVC=str2num(char(A(3)));

link.endpoints=zeros(number_of_components,1); % Here we prepare link.endpoints and Closed for input.
link.closed=cell(number_of_components,1);

sum=0;

for i=1:number_of_components           % And fill them with appropriate values.
    sum=sum+abs(NVC(i));
    link.endpoints(i)=sum;
    if NVC(i)>0
        link.closed{i}='open';
    else
        link.closed{i}='closed';
    end;
end;

% We now read all the vertices into the V array.

verts=zeros(number_of_vertices,3);
for i=5:number_of_vertices+4
    verts(i-4,:)=str2num(char(A(i)));
end;
verts = reshape(verts',3*size(verts,1),1);

% And last, deal with the color information provided in the file.
% These end up in "link.colorvalues" (the component colors) and 
% "link.transparency", the alpha value of each tube. But first, 
% we load them into intermediate arrays for further processing.

ColorList=zeros(number_of_colors,3);
AlphaList=cell(number_of_colors,1);

for i=1:number_of_colors
   
   a=str2num(char(A(number_of_vertices+4+i)));
   ColorList(i,:)=a(1:3);
   AlphaList{i} = a(4);
      
end;

% We now split up the ColorList and AlphaList data into the various components.
              
NCC=str2num(char(A(4))); % This array is the number of colors per component.
count=1;

% We use the "Coombs Colors" (thx to Tammy Coombs!) as defaults.
           
defaultfacecolors = [255,51,204;102,153,255;255,153,0;102,204,51] ./ 255;
defaultedgecolors = [255,19,240;109,224,255;255,224,179;209,240,194] ./ 255;                   

for i=1:number_of_components
    
    if NCC(i)==0
        
        % There are no colors set for this component. If it is the first component,
        % set it to a default color. Otherwise, let it inheirit the previous component's
        % color, as per the VECT documentation.
        
        if (i > 1) 
        
            cc=link.colorvalues(i-1,:);
            ce=link.edgecolorvalues(i-1,:);
            co=link.transparency(i-1);
        
        else 
            
            cc=defaultfacecolors(mod(i,4) + 1,:);
            ce=defaultedgecolors(mod(i,4) + 1,:);
            co=1.0;
            
        end;
        
    else
    
        % There is at least one color for this component. We'll take the first vertex color.
        
        cc=ColorList(count,:);
        ce=rgb2hsv(cc); ce=hsv2rgb([ce(1) ce(2) 1-ce(3)]); % Default grid selection.
        co=AlphaList{count};
        count=count+NCC(i); % and skip ahead to the next component
        
    end;
    
    link.colorvalues{i}     = cc;
    link.edgecolorvalues{i} = ce;
    link.transparency(i)    = co;
    link.tension(i)         = 1;
    link.thickness(i)       = 1;
    link.constraints{i}     = 'none';
    
end;

% We also set up the helpful globals numcomp and GLOB_FVDATA, which contains the number of components.

numcomp = size(link.tension,1);

