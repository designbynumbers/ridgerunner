function displaytube(Verts,link);

% FUNCTION displaytube draws a variable-radius tube around a link component. 

% Input: an nx3 array Verts of locations in 3-space
%        a linkdata structure link, containing the fields
%
%           link.endpoints       a list of the endpoints of all the components
%           link.closed          a cell array of text strings 'open' or 'closed' for each component
%           link.colorvalues     a cell array of rgb color values for the components of the link
%           link.tranparency     a cell array of text strings 'Clear', 'Transparent', or 'Opaque'
%           link.tension         an ix1 array of the tension in each component
%           link.thickness       an nx1 array of the thickness of each tube
%           link.constraints     a cell array of text strings 'None', 'Fixed', or 'Surface'
%           link.surface         a cell array of text strings in the form 'z=f(x,y)' for each
%                                endpoint with a "surface" constraint.
%           link.edgecolorvalues a cell array of rgb color values for the component's grid.

% Output: Draws the tubes around the various components of link to the current axis.

% Algorithm: We set up a parametrized surface around each component using Bishop's frame.
% This is then passed to the "mesh" rendering function in MATLAB.

numcomp = size(link.tension,2);

% We begin by making an array of startpoints.The first component starts at 1- the others just
% after the endpoint of the previous component. 

Startpoint=[1 link.endpoints(1:numcomp-1)+1];

% We are now ready to iterate through the components and draw each tube.

for i=1:numcomp
    
    % We now compute the framing on the tube. First, we'll need the tangent vectors
    % of our component. This code can be lifted from dLen.
    
    v=Verts(Startpoint(i):link.endpoints(i),:);
    last = size(v,1);
    
    if (strcmpi(link.closed{i},'closed'))   % If the component is closed, the vertices should wrap around
        v=[v;v(1,:)];
    elseif (strcmpi(link.closed{i},'open')) % If the component is open, they shouldn't
        v=[v;2*v(last,:) - v(last-1,:)];  
    else
        error('link.closed contains illegal string (neither closed nor open)');
    end;
        
    tangent   = normalizenx3(v(2:last+1,:) - v(1:last,:));
     
    % We are now ready to start the framing.
    
    bframe = zeros(size(tangent));  % allocate space for framing.
    cframe = zeros(size(tangent));
    
    bframe(1,:) = rand(size(tangent(1,:)));                                   %choose a random vector 
    bframe(1,:) = bframe(1,:) - (bframe(1,:) * tangent(1,:)') * tangent(1,:); %project to normal to tangent.
    bframe(1,:) = bframe(1,:)./norm(bframe(1,:));                             %normalize     
   
    cframe(1,:) = cross(bframe(1,:),tangent(1,:)); % Add the third frame component.
    
    for j=2:size(bframe,1) % now compute the rest of the vectors in the Bishop frame.
        
        bframe(j,:) = bframe(j-1,:) - (bframe(j-1,:) * tangent(j,:)') * tangent(j,:); 
        bframe(j,:) = bframe(j,:)./norm(bframe(j,:));
        
        cframe(j,:) = cross(bframe(j,:),tangent(j,:));
    end;
    
    % We now need to compute the number of sides to use for the tube. 
    % This is chosen so that the grid sections are approximately square.
    
    edges = v(2:last+1,:) - v(1:last,:);
    edgelengths = sqrt(edges(:,1).^2 + edges(:,2).^2 + edges(:,3).^2);
    avgedge = mean(edgelengths);
    
    numSides = max([round(2*pi*link.thickness(i)/avgedge),10]);
    
    % We now compute the holonomy in the frame, and correct it so the edges line up.
    
    theta = acos(bframe(1,:)*bframe(size(bframe,1),:)');
    ofs   = round(numSides*theta/(2*pi));
    thetacor = ofs*2*pi/numSides;
    
    % We are now ready to compute the mesh surface.
    
    X = zeros(size(tangent,1),numSides);
    Y = zeros(size(tangent,1),numSides);
    Z = zeros(size(tangent,1),numSides);
    
    X =   repmat(link.thickness(i)*bframe(:,1),1,numSides) .* repmat(cos(linspace(0,2*pi,numSides)),last,1) ...
        + repmat(link.thickness(i)*cframe(:,1),1,numSides) .* repmat(sin(linspace(0,2*pi,numSides)),last,1) ...
        + repmat(v(1:last,1),1,numSides);
    
    Y =   repmat(link.thickness(i)*bframe(:,2),1,numSides) .* repmat(cos(linspace(0,2*pi,numSides)),last,1) ...
        + repmat(link.thickness(i)*cframe(:,2),1,numSides) .* repmat(sin(linspace(0,2*pi,numSides)),last,1) ...
        + repmat(v(1:last,2),1,numSides);
    
    Z =   repmat(link.thickness(i)*bframe(:,3),1,numSides) .* repmat(cos(linspace(0,2*pi,numSides)),last,1) ...
        + repmat(link.thickness(i)*cframe(:,3),1,numSides) .* repmat(sin(linspace(0,2*pi,numSides)),last,1) ...
        + repmat(v(1:last,3),1,numSides);
    
    
    % If the tube is closed, we want to connect the last circle of vertices to the first.
    % Doing this carefully, without creating a visible seam, will require a little bit of hackery.
    % The idea of the code below is to connect the last ring on the tube with the first, but to
    % rotate the first so that each vertex on the last tube is connected to the vertex on the first
    % which is as close as possible to it.
    
    if (strcmpi(link.closed{i},'Closed')) 
        
        normsqr = (X(last,1) - X(1,:)).^2 + (Y(last,1) - Y(1,:)).^2 + (Z(last,1) - Z(1,:)).^2;
        [mn,mni] = min(normsqr);
        
        if (mni == 1) % Unfortunately, this is a special case.
            
            X = [X;X(1,:)];
            Y = [Y;Y(1,:)];
            Z = [Z;Z(1,:)];
            
        else
            
            X = [X;X(1,[mni:numSides 2:mni])];
            Y = [Y;Y(1,[mni:numSides 2:mni])];
            Z = [Z;Z(1,[mni:numSides 2:mni])];
            
        end;
        
    end;
        
    % And, finally, display it. 
    
    mesh(X,Y,Z,'FaceColor',link.colorvalues{i},...
               'FaceAlpha',link.transparency(i),...
               'FaceLighting','phong','EdgeColor',link.edgecolorvalues{i});           
    hold on;
   
end;
