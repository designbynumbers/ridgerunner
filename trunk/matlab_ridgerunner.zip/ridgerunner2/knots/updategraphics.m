function status = updategraphics(t,V,flag)

% FUNCTION updategraphics is registered with the ODE solver suite as the output function for
% our call to odefun. It makes use of a number of graphics handles which are declared GLOBAL
% by the odesolvercall function.

% the 'flag' tells us some information about how many times updategraphics has been called.
% if flag = 'init', we know it's the first call, and we act accordingly.

% We use two global structures: one describes the graphics parameters of the current window,
% while the other gives the current state of the firstvariation computation.

%        GLOB_HANDLES       a structure containing all the handles for the graphics objects in the GUI
%                           the field names are

%                           gui_figure;
%                           tubes;
%                           vector_field;
%                           curves;
%                           struts;
%                           constraints;
%                           showgraph;
%                           record;
%                           go;
%                           stop;
%                           clear;
%                           filename_text;
%                           filename_edit_text;
%                           picture_main;
%                           menu_file_open;
%                           menu_file_save;
%                           menu_file_save_as;
%                           menu_file_import;
%                           menu_file_export;
%                           menu_edit_properties;
%                           menu_edit_ode_solver;
%                           menu_edit_ode_solver_item1;
%                           menu_edit_ode_solver_item2;
%                           menu_edit_ode_solver_item3;
%                           menu_edit_ode_solver_item4;
%                           menu_edit_ode_solver_item5;
%                           menu_edit_ode_solver_item6;
%                           menu_edit_ode_solver_item7;
%                           picture_length_time;
%                           spin;

%  We also pick off a global structure which describe the state of the firstvariation code.

%        GLOB_FVDATA has fields

%                           .dVdt            : the current value of the variational vector field
%                           .link            : the link data structure
%                           .strutStartPoints: start points of struts (in space)
%                           .strutEndPoints  : end points of struts (in space)
%                           .compressions    : compression values for struts
%                           .strutField      : force field from struts.

global GLOB_HANDLES;
global GLOB_FVDATA;
global MOVIE;                % Stores the handle of the current movie matrix if we are saving frames.

global TIME;                 % Vectors of data for the length/time graph.
global LENGTH;
global numcomp;

% And some debugging stuff.

global GLOB_CONFIGS;
global GLOB_UGCALLS;

GLOB_UGCALLS = GLOB_UGCALLS + 1;

% Zeroth, we check that we've been called correctly.

if (nargin ~= 3) 
    warning('updategraphics: Expects to be called with (t,V,flag). Perhaps you haven''t loaded a knot?');
    return;
end;

if (size(V,1) == 0)
    return;
end;

if ((mod(size(V,1),3) ~= 0) | (size(V,2) ~= 1))
    
    error('updategraphics: Expect V to be a 3nx1 column vector.');
    
end;

% Now we display the length of V.

% sprintf('Length: %g',computelength(V))

% First, we make sure that the current axis is set correctly.

axes(GLOB_HANDLES.picture_main);

% We need to store the limits of the axes before we clear the existing picture.

linklimits(1,:) = get(GLOB_HANDLES.picture_main,'XLim');
linklimits(2,:) = get(GLOB_HANDLES.picture_main,'YLim');
linklimits(3,:) = get(GLOB_HANDLES.picture_main,'ZLim');

cla;

% Now we go ahead and draw the picture of the link. We'll need to reshape V, I think.
   
[n,k]=size(V);
V=reshape(V,3,n/3)';      % This is important! The vector appears as (x1 y1 z1 x2 y2 z2 ... )'
[n,k]=size(V);            % We must reshape it so that the correct elements end up together!

numcomp = size(GLOB_FVDATA.link.tension,2); % We set the number of components in our link.
NumFaces=30;  % This sets the number of faces in our polygonal tubes.

if get(GLOB_HANDLES.tubes,'Value')==1 
    
    displaytube(V,GLOB_FVDATA.link);
    
end;


if (get(GLOB_HANDLES.vector_field,'Value')==1 & size(GLOB_FVDATA.dVdt,1) ~= 0) 
    
    [m,n]=size(V);
    GLOB_FVDATA.dVdt        =reshape(GLOB_FVDATA.dVdt,n,m)';
    
end;

if (get(GLOB_HANDLES.struts,'Value')==1 & size(GLOB_FVDATA.strutField,1) ~= 0)
    
    [m,n]=size(V);
    GLOB_FVDATA.strutField  =reshape(GLOB_FVDATA.strutField,n,m)';

end;
    
startpoint=1;
for i=1:numcomp
    
    endpoint=GLOB_FVDATA.link.endpoints(i);
    
    if get(GLOB_HANDLES.curves,'Value')==1
    
        displaypoly(V(startpoint:endpoint,:),GLOB_FVDATA.link.closed(i),GLOB_FVDATA.link.colorvalues{i});
        
    end;
    
    if ((get(GLOB_HANDLES.vector_field,'Value')==1) & (size(GLOB_FVDATA.dVdt,1) == size(V,1))) % If there is no vf data yet, there is nothing to do.
    
        vf_handle = quiver3(V(:,1),V(:,2),V(:,3),GLOB_FVDATA.dVdt(:,1),GLOB_FVDATA.dVdt(:,2),GLOB_FVDATA.dVdt(:,3));
        set(vf_handle,'LineWidth',1,'Color',[1 1 0.1]);
        
    end;
    
    if get(GLOB_HANDLES.constraints,'Value')==1
        
        displayconstraints(GLOB_FVDATA.link);
        
    end;
    
    if (get(GLOB_HANDLES.struts,'Value')==1 & size(GLOB_FVDATA.strutField,1) ~= 0) % If there is no strut data yet, don't display it.
      
        displaystruts(GLOB_FVDATA.strutStartPoints,GLOB_FVDATA.strutEndPoints,GLOB_FVDATA.compressions);
        quiver3(V(:,1),V(:,2),V(:,3),GLOB_FVDATA.strutField(:,1),GLOB_FVDATA.strutField(:,2),GLOB_FVDATA.strutField(:,3),'w');

    end;
    
    startpoint=endpoint+1;
end;

% if we are saving a movie file, we go ahead and get this frame.

if get(GLOB_HANDLES.record,'Value')==1
   
   frame=getframe(GLOB_HANDLES.gui_figure);
   MOVIEMATRIX=[MOVIEMATRIX;frame];
   
end;
    
% if 'showgraph' checkbox is marked display length over time graph and store length values
    
if get(GLOB_HANDLES.showgraph,'Value') == 1
    
   axes(GLOB_HANDLES.picture_length_time);   % refresh picture frames every 5th time step
   cl=drawlength(t,V,GLOB_FVDATA.link);
   
   COMPONENTLENGTH=[COMPONENTLENGTH ;cl];
   TIME=[TIME;t];
   
   set(GLOB_HANDLES.picture_length_time,'Xlim',GLOB_GRAPHICSDATA.lengraph_axis);
   
end;
    
% We last make sure that the axis limits are set correctly.

if (strcmp(flag,'init')) % This is the first call.
   
    axis tight;
    
else
    
    set(GLOB_HANDLES.picture_main,'XLim',linklimits(1,:));
    set(GLOB_HANDLES.picture_main,'YLim',linklimits(2,:));
    set(GLOB_HANDLES.picture_main,'ZLim',linklimits(3,:));

end;

% Now that we've drawn everything, we make sure the axes are set correctly.

set(GLOB_HANDLES.picture_main,'DataAspectRatio',[1 1 1]);
camproj('perspective');
whitebg('k');
light;
rotate3d;
axis vis3d;
drawnow;

% Last, we check the value of GLOB_STOP to see if we should halt the integration here.

if (get(GLOB_HANDLES.stop,'Value') == 1) 
    
    status = 1;                         % Stop the ODE solution.
   
else 
    
    status = 0;                         % Keep the ODE solver running.
    
end;
   
% We also update the value of GLOB_CONFIGS, and compute distances.
% THIS IS DEBUGGING CODE!

%GLOB_CONFIGS{GLOB_UGCALLS} = V;
%sprintf('Accepted configuration %d. Distances from %d to previous:',GLOB_UGCALLS,GLOB_UGCALLS)

%for i=1:GLOB_UGCALLS
    
%    linfty(GLOB_CONFIGS{i},GLOB_CONFIGS{GLOB_UGCALLS})
    
%end;