function posok = admissiblepos(t,Verts);

% FUNCTION admissiblepos decides whether a position of the link has Th >= 1.

% Input: t             the time of integration (since this flow is not time-dependant, this parameter is ignored) 
%        V             3nx1 list of coordinates of vertices of components

% The function uses the global structure GLOB_FVDATA, which contains several fields

%        link          a linkdata structure, containing the fields
%
%                         link.endpoints    a list of the endpoints of all the components
%                         link.closed       a cell array of text strings 'open' or 'closed' for each component
%                         link.colorvalues  an ix3 array of rgb color values for the components of the link
%                         link.transparency a scalar between 0 and 1 giving the opacity of the tube
%                         link.tension      an ix1 array of the tension in each component
%                         link.thickness    an nx1 array of the thickness of each tube
%                         link.constraints  a cell array of text strings 'None', 'Fixed', or 'Surface'
%                         link.surface      a cell array of text strings in the form 'z=f(x,y)' for each
%                                           endpoint with a "surface" constraint.

%        dVdt           an nx3 variational vector field
%     strutStartPoints  start points of struts (in space) as a kx3 array
%     strutEndPoints    end points of struts (in space) as a kx3 array
%     compressions      compression values for struts (a kx1 array)
%     strutField        an nx3 force field from struts.
       

% Output: posok         either 1 (true) or zero (false), deciding whether the position is admissible


% Algorithm: We use the Cantarella-Fu-Rawdon picture. We assume that the link forms a tensegrity where
% the contacts between tubes act as struts. The first variation of length is an external force on this
% tensegrity, which usually cannot be completely resolved by compressions on the struts. We resolve the
% largest possible component of this force: the remainder is the gradient of ropelength. 
 

global GLOB_FVCALLS

GLOB_FVCALLS = GLOB_FVCALLS + 1;

if (mod(GLOB_FVCALLS,20) == 0) 
    
     drawnow;    
    
end;

global GLOB_FVDATA;

% And we include some debugging code.

global GLOB_CONFIGS;

% We start by testing our input, and complaining if it doesn't look right.

if (nargin ~= 2)
    
    error('admissiblepos: must input (t,Verts)');
    
end;

if (nargout ~= 1)
    
    error('admissiblepos: expect to output one variable dVdt.');
    
end;

if ((mod(size(Verts,1),3) ~= 0) | (size(Verts,2) ~= 1))
    
    error('admissiblepos: Expect Verts to be a 3nx1 column vector.');
    
end;

% First, we reshape V for convenience in working with it inside the function.
% We also set n to the number of vertices in V.

[n,k]=size(Verts);
V=reshape(Verts,3,n/3)';  % This is important! The vector appears as (x1 y1 z1 x2 y2 z2 ... )'
[n,k]=size(V);            % We must reshape it so that the correct elements end up together!

% Now we call the Mex'ed strutFinder. We are only interested in the final outvariable, intersect,
% which tells us whether the tube intersects itself.

[dummy dummy2 dummy3 intersect] = strutFinder(Verts',GLOB_FVDATA.link);

posok = 1 - intersect;

return;