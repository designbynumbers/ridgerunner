function [newV,badstep] = attempt_rkstep(link,verts,stepsize,initindices,initDvdt)

% FUNCTION ATTEMPT_RKSTEP tries to take a Runge-Kutta step, but will fail (and return 1 in 
% badstep) if we encounter a discontinuity before reaching the target stepsize. We are using
% the fourth-order RK integration described in Numerical Recipes.

badstep = 0;
V = zeros(size(verts,1),3);
dVdt = zeros(size(verts,1),3);

% First step. This is a little tricky, since we want to use the initpositions and
% init vertices, which may NOT be those returned by strutFinder for our position if we are 
% pivoting around a singularity. Hence, we have to use the initial Dvdt, as well.

V(:,1) = verts + (stepsize/2.0)*initDvdt;

% Second step. We now use fmpV to generate a new dVdt. 

[dVdt(:,1), badstep, indices] = experimentalFirstvariation(link,V(:,1),initindices);

if (badstep == 1) 
    
    newV = verts;  % Don't move.
    return;        % Return to sender.
    
end;

V(:,2) = verts + (stepsize/2.0)*dVdt(:,1);

% Third step. We use ssV to generate another dVdt. Here, we are comparing
% again to the initial indices. All of the indices must stay the same across
% the entire step, or we'll be forced to abort and try a smaller stepsize.

[dVdt(:,2), badstep, indices] = experimentalFirstvariation(link,V(:,2),initindices);

if (badstep == 1)
    
    newV = verts;
    return;
    
end;

V(:,3) = verts + stepsize*dVdt(:,2);

% Fourth step. We now compute the derivative at tsV to generate a last dVdt.

[dVdt(:,3), badstep, indices] = experimentalFirstvariation(link,V(:,3),initindices);

if (badstep == 1)
    
    newV = verts;
    return;
    
end;

%% We now combine all of these dVdt guys to get the final step, and the associated strut set.

newV = verts + (stepsize/6.0)*(initDvdt + 2*dVdt(:,1) + 2*dVdt(:,2) + dVdt(:,3));
[dVdt(:,3), badstep, indices] = experimentalFirstvariation(link,newV,initindices);




