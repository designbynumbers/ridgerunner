7
% importcallback
% This script reads the file and determines which type of link file
% it is.  Currently, it supports
% VECT link files
% ming knot files
% If it is a VECT file, it calls the function importvectfile.
% If it is a ming file, it calls function importmingfile.

% We first set up a linkdata structure to receive our data.

% We are now ready to load this data into a linkdata structure.

GLOB_FVDATA.link=struct('endpoints',[],...
            'closed',{[]},...
            'colorvalues',{[]},...
            'transparency',[],...
            'tension',[],...
            'thickness',[],...
            'constraints',{[]},...
            'surface',{[]},...
            'edgecolorvalues',{[]});

% First, we get the file, and read the lines into an array of strings.

[import_file_name,import_path_name]=uigetfile('*','IMPORT FILE',100,100);
import_path_and_file_name = strcat(import_path_name,import_file_name);
A=textread(import_path_and_file_name,'%s','delimiter','\n');

% We test the first line an opening "{" for a ming file
% We test the first line for the word VECT for a vect file
% Call the correct function to import the file.

if size(findstr(A{1},'{'), 1) ~= 0
  [GLOB_FVDATA.link,verts,numcomp] = importmingfile(import_path_and_file_name);
elseif size(findstr(A{1},'VECT'), 1) ~= 0
  [GLOB_FVDATA.link,verts,numcomp] = importvectfile(import_path_and_file_name);
else
  error('Import file: The file does not appear to be a supported file.');
end;

% Last, we update the graphics frame.

updategraphics('',verts,'init');
