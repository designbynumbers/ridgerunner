%edittensioncallback
for i=1:numcomp
    u=str2num(char(get(GLOB_HANDLES.edit_component_tension(i),'String')));
    GLOB_FVDATA.link.tension(i)=u;
end;
