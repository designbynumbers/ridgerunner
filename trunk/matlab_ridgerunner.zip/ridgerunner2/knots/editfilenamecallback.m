%edittextcallback

movie_file_name=get(GLOB_HANDLES.filename_edit_text,'String');
set(GLOB_HANDLES.filename_text,'Visible','off');
set(GLOB_HANDLES.filename_edit_text,'Visible','off');
