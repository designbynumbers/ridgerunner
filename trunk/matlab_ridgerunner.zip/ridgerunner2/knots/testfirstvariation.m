% Script testfirstvariation imports a vect file, and runs firstvariation on it.

global numcomp;
global COUNTER;
global GLOB_HANDLES;

[current_ode_solver,saveas_file_name,movie_file_name]=GraphicalUserInterface_Knots;

load p3_1_160 p3_1_160;
load ld.mat link;

verts = p3_1_160';
link.endpoints(1) = 160;

%load ./data/vertvert1.mat link verts;
%verts = verts';

set(GLOB_HANDLES.tubes, 'Value',0); % Turn off tubes
set(GLOB_HANDLES.curves,'Value',1);    % Turn on curves
set(GLOB_HANDLES.struts,'Value',1);   % Turn on struts
set(GLOB_HANDLES.vector_field,'Value',1);    % Turn on vector field.

figure(GLOB_HANDLES.gui_figure);

% determine axis limits

[n,k]=size(verts);
v=reshape(verts,3,n/3)';

ax1=[min(v(:,1))-1 max(v(:,1))+1 min(v(:,2))-1 max(v(:,2))+1 min(v(:,3))-1 max(v(:,3))+1];
ax2 = [];

COUNTER = 0;
dVdt = firstvariation([],verts,[],link);
  
           
