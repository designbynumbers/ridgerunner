%edittextcallback
movie_file_name=get(H(13),'String');
set(H(12),'Visible','off');
set(H(13),'Visible','off');
