function [newV] = onecompfixlength(Verts,link);

% FUNCTION FIXLENGTHS fixes the lengths, so they are about the same, which is good enough for Jason
% right now, that may change

% Input: V             3nx1 list of coordinates of vertices of components
%        link          a linkdata structure, containing the fields
%
%                         link.endpoints    a list of the endpoints of all the components
%                         link.closed       a cell array of text strings 'open' or 'closed' for each component
%                         link.constraints  a cell array of text strings 'None', 'Fixed', or 'Surface'
%                         link.surface      a cell array of text strings in the form 'z=f(x,y)' for each
%                                           endpoint with a "surface" constraint.
%

% Output: nuttin honey
%
% Algorithm: We redistribute the vertices so that they are equally distributed with respect to arc length
% on the old link.  It does not make things exactly equilateral, but it is quick and works pretty well.

% We start by testing our input, and complaining if it doesn't look right.

if (nargin ~= 2)
    error('fixlengths: must input (Verts,link)');
end;

if (nargout ~= 1)
    error('fixlengths: sorry, no output.');
end;

if ((mod(size(Verts,1),3) ~= 0) | (size(Verts,2) ~= 1))
    error('fixlengths: Expect Verts to be a 3nx1 column vector.');
end;

% First, we reshape V for convenience in working with it inside the function.
% We also set n to the number of vertices in V.

[n,k]=size(Verts)
V=reshape(Verts,3,n/3)';  % This is important! The vector appears as (x1 y1 z1 x2 y2 z2 ... )'

% just debugging check
vlength = 0;
newvlength = 0;

% Loop over components
[dummy,numberOfComponents] = size(link.endpoints);
component = 1;

startOfLoop = 1;
endOfLoop = link.endpoints(1);

flag = 1;

while(component==1)
  component;
  length = computelength(V,link,component);

  sprintf('Norms:')
  for i=startOfLoop:endOfLoop-1
    norm(V(i+1,:)-V(i,:),2)
  end;
  norm(V(endOfLoop,:)-V(startOfLoop,:),2)
  
  if(strcmp(link.closed(component),'closed') == 1)
    sprintf('This component is closed!\n')
    isThisComponentClosed = 1;
    goal = length/(endOfLoop-startOfLoop+1)
  else
    isThisComponentClosed = 0;
    goal = length/(endOfLoop-startOfLoop);
  end;
  
  % left = norm(V(startOfLoop+1,:)- V(startOfLoop,:),2);
  tmpgoal = goal;
  used = 0;
  
  newVerts(startOfLoop,:) = V(startOfLoop,:);
  sprintf('just set newVerts %d\n',startOfLoop)

  j = startOfLoop + 1;
  
  for i=startOfLoop:endOfLoop
    if(i<endOfLoop)
      head = i + 1;
      tail = i;
    elseif(isThisComponentClosed == 1)
      head = startOfLoop;
      tail = endOfLoop;
    end;

    head
    tail
    
    left = norm(V(head,:) - V(tail,:),2);
    left
    sprintf('is the length of edge between %d and %d\n',head,tail)
    used = 0;
    
    while( (left > tmpgoal) & (j <= endOfLoop) )
      if( j == endOfLoop )
	if(isThisComponentClosed == 0)
          sprintf('component is open\n')
	  newVerts(j,:) = V(j,:);
	else
          sprintf('component closed on last vertex %d with tmpgoal %f used %f left % f head %d tail %d\n',j,tmpgoal,used,left,head,tail)
          sprintf('using %f + %f of %f that is left\n',tmpgoal,used,left)
	  newVerts(j,:) = ((tmpgoal+used)/norm(V(head,:)-V(tail,:),2)) * (V(head,:)-V(tail,:)) + V(tail,:);
          sprintf('just set newVerts %d\n',j)
          sprintf('length of edge tween %d and %d is\n',endOfLoop-1,endOfLoop)
          norm(newVerts(endOfLoop-1,:)-newVerts(endOfLoop,:),2)
          sprintf('length of edge tween %d and %d is\n',endOfLoop,startOfLoop)
          norm(newVerts(endOfLoop,:) - newVerts(startOfLoop,:),2)
	end;
	
	sprintf('At end of loop to close a component, i should be %d and it is %d\n', endOfLoop, i)
	break;
      else
        sprintf('using %f + %f of %f that is left\n',tmpgoal,used,left)
        newVerts(j,:) = ((tmpgoal+used)/norm(V(head,:)-V(tail,:),2)) * (V(head,:)-V(tail,:)) + V(tail,:)
        sprintf('just set newVerts %d\n',j)
        left = left - tmpgoal;
        left
        sprintf('is what remains after subtracting tmpgoal = %f\n',tmpgoal)
        used = used + tmpgoal;
        tmpgoal = goal;
        tmpgoal
      end;
      
      
      
      j;
      norm(V(j,:) - V(j-1,:),2);
      sprintf('length of edge tween %d and %d is\n',j,j-1)
      norm(newVerts(j,:) - newVerts(j-1,:),2)
      % vlength = vlength + norm(V(j,:) - V(j-1,:),2);
      % newvlength = newvlength + norm(newVerts(j,:) - newVerts(j-1,:),2);
      
      j = j + 1;
    end;

    tmpgoal = tmpgoal - left;
    
  end;
  
  if(isThisComponentClosed == 0)
    newVerts(endOfLoop,:) = V(endOfLoop,:);
  end;
  
  component = component + 1;
  
  if(component > numberOfComponents)
    flag = 0;
    break;
  end;
  
  startOfLoop = endOfLoop+1;
  endOfLoop = link.endpoints(component);
end;


size(V);
size(newVerts);
newVerts;

for i=1:numberOfComponents
  sprintf('component, componentlength, and norm of last edge\n');
  i
  compylength = computelength(V,link,i);
  compylength
  if(i==1)
    norm(newVerts(link.endpoints(1),:)-newVerts(1,:),2)
  else
    norm(newVerts(link.endpoints(i),:)-newVerts(link.endpoints(i-1)+1,:),2)
  end;   
end;

n
3*n

for i=2:n/3
  i
  norm(newVerts(i,:)-newVerts(i-1,:),2)
end;


newV = reshape(newVerts',n,1);
