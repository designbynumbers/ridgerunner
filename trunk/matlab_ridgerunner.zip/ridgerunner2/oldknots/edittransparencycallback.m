%edittransparencycallback
for i=1:numcomp
    u=(get(h_edit_component_transparency(i),'String'));
    link.transparency(i)=cellstr(u);
end;
