function ok=strut_test_suite(V,link,strutStartPoints,strutEndPoints,positions,indices,error)

% FUNCTION strut_test_suite automatically checks the struts produced by strutFinder
% to make sure that they obey the defining conditions of struts: that they be length 2,
% and normal to the tangent vectors on both their ends.

struts = strutStartPoints - strutEndPoints;
strutnorms = struts(:,1).^2 + struts(:,2).^2 + struts(:,3).^2;
struts = normalizenx3(struts);

lengtherror = max(abs(strutnorms - 4));

if (lengtherror > error) 
        
    ok = 0;   % This is NOT ok!
    'struts failed the strut test suite on a length error'
    return;
    
end;

% We are now going to check double-criticality.
% We'll need a list of all the tangent vectors coming into and out of vertices.

NumComponents = size(link.closed,1);
Startpoint=[1 link.endpoints(1:NumComponents-1)+1];

TanIn = zeros(size(V));
TanOut = zeros(size(V));

for i=1:NumComponents
    
    % First, we isolate and preprocess the vectors in this component.
    
    compv=V(Startpoint(i):link.endpoints(i),:);
    last = size(compv,1);
    
    if (strcmpi(link.closed{i},'closed'))   % If the component is closed, the vertices should wrap around
        compv=[compv(last,:);compv;compv(1,:)];
    elseif (strcmpi(link.closed{i},'open')) % If the component is open, they shouldn't
        compv=[compv(1,:);compv;compv(last,:)];  
    else
        error('link.closed contains illegal string (neither closed nor open)');
    end;
        
    % Now we compute the (unit) tangent vectors into and out of each vertex.    
        
    TanIn(Startpoint(i):link.endpoints(i),:)  = normalizenx3(compv(2:last+1,:) - compv(1:last,:));
    TanOut(Startpoint(i):link.endpoints(i),:) = normalizenx3(compv(3:last+2,:) - compv(2:last+1,:));
    
end;

strutcount = size(strutStartPoints,1);
strutdots = ones(strutcount,2);  % Initialize to something obvious!

for i=1:strutcount

    if (positions(i,1) > 0 & positions(i,1) < 1.0)  % We have an edge strut.
        
        tangent1 = V(indices(i,2),:) - V(indices(i,1),:);
        tangent1 = tangent1 ./ norm(tangent1);
    
        strutdots(i,1) = dot(struts(i,:),tangent1);
        
    else % A vertex is involved. In this case, we take the dot with both tangent vectors.
        
        if (positions(i,1) == 0)           % We're at index 1
        
            strutdots(i,1) = dot(TanIn(indices(i,1),:),struts(i,:)) * ...
                             dot(TanOut(indices(i,1),:),struts(i,:));
                         
        elseif (positions(i,1) == 1.0)     % We're at index 2   
            
            strutdots(i,1) = dot(TanIn(indices(i,2),:),struts(i,:)) * ...
                             dot(TanOut(indices(i,2),:),struts(i,:));
             
        end; 
        
    end;
    
    if (positions(i,2) > 0 & positions(i,2) < 1.0)  % We have an edge strut.
        
        tangent2 = V(indices(i,3),:) - V(indices(i,4),:);
        tangent2 = tangent2 ./ norm(tangent2);
    
        strutdots(i,2) = dot(struts(i,:),tangent2);
        
    else % A vertex is involved. In this case, we take the dot with both tangent vectors.
        
        if (positions(i,2) == 0)           % We're at index 3
        
            strutdots(i,2) = dot(TanIn(indices(i,3),:),struts(i,:)) * ...
                             dot(TanOut(indices(i,3),:),struts(i,:));
                         
        elseif (positions(i,2) == 1.0)     % We're at index 4   
            
            strutdots(i,2) = dot(TanIn(indices(i,4),:),struts(i,:)) * ...
                             dot(TanOut(indices(i,4),:),struts(i,:));
             
        end; 
        
    end;
    
end;

strutdots = reshape(strutdots,1,numel(strutdots));
doterror = max(abs(strutdots));

if (doterror > error) 
    
     ok = 0;
     'struts failed strut test suite on a dot product error.';
     return;
     
 end;
 
 ok = 1;
 

% END OF DEBUGGING CODE