% datapropertiescallback
if numcomp==0
    h=msgbox('Open data file first','Error');
else
    edit_data_properties_figure=figure('Units','characters','Position',[46 33 140  3+3*numcomp],'IntegerHandle','off',...
    'MenuBar','none','Name','Edit Data Properties','Tag','EditDataPropertiesFigure','Color',[0.8 0.8 0.8],'NumberTitle','off');
    h_component_text0=uicontrol(edit_data_properties_figure,'Style','text','Units','normalized','Position',[0.205 .9-1/(1.8*numcomp) .13 1/(2*numcomp)],'String','Color','BackgroundColor',[.8 .8 .8]);
    h_component_text1=uicontrol(edit_data_properties_figure,'Style','text','Units','normalized','Position',[0.355 .9-1/(1.8*numcomp) .13 1/(2*numcomp)],'String','Thickness','BackgroundColor',[.8 .8 .8]);
    h_component_text2=uicontrol(edit_data_properties_figure,'Style','text','Units','normalized','Position',[0.505 .9-1/(1.8*numcomp) .13 1/(2*numcomp)],'String','Tension','BackgroundColor',[.8 .8 .8]);
    h_component_text3=uicontrol(edit_data_properties_figure,'Style','text','Units','normalized','Position',[0.655 .9-1/(1.8*numcomp) .13 1/(2*numcomp)],'String','Transparency','BackgroundColor',[.8 .8 .8]);
    h_component_text4=uicontrol(edit_data_properties_figure,'Style','text','Units','normalized','Position',[0.805 .9-1/(1.8*numcomp) .13 1/(2*numcomp)],'String','Constraints','BackgroundColor',[.8 .8 .8]);
      
for i=1:numcomp
    h_component_color(i)=uicontrol(edit_data_properties_figure,'Style','text','Units','normalized','Position',[0.055 -i/(1.2*numcomp)+0.9 .13 1/(2*numcomp)],'BackgroundColor',link.colorvalues(i,:));
    h_edit_component_color_value_r(i)=uicontrol(edit_data_properties_figure,'Style','edit','Units','normalized','Position',[.205 .9-i/(1.2*numcomp) .04 1/(2*numcomp)],'String',num2str(link.colorvalues(i,1)),'BackgroundColor','w','Callback','editcolorcallback'); 
    h_edit_component_color_value_g(i)=uicontrol(edit_data_properties_figure,'Style','edit','Units','normalized','Position',[.255 .9-i/(1.2*numcomp) .04 1/(2*numcomp)],'String',num2str(link.colorvalues(i,2)),'BackgroundColor','w','Callback','editcolorcallback');        
    h_edit_component_color_value_b(i)=uicontrol(edit_data_properties_figure,'Style','edit','Units','normalized','Position',[.305 .9-i/(1.2*numcomp) .04 1/(2*numcomp)],'String',num2str(link.colorvalues(i,3)),'BackgroundColor','w','Callback','editcolorcallback');        
    h_edit_component_thickness(i)=uicontrol(edit_data_properties_figure,'Style','edit','Units','normalized','Position',[.355 .9-i/(1.2*numcomp) .13 1/(2*numcomp)],'String',link.thickness(i),'BackgroundColor','w','Callback','editthicknesscallback');
    h_edit_component_tension(i)=uicontrol(edit_data_properties_figure,'Style','edit','Units','normalized','Position',[.505 .9-i/(1.2*numcomp) .13 1/(2*numcomp)],'String',link.tension(i),'BackgroundColor','w','Callback','edittensioncallback');
    h_edit_component_transparency(i)=uicontrol(edit_data_properties_figure,'Style','edit','Units','normalized','Position',[.655 .9-i/(1.2*numcomp) .13 1/(2*numcomp)],'String',link.transparency(i),'BackgroundColor','w','Callback','edittransparencycallback');
    h_edit_component_constraints(i)=uicontrol(edit_data_properties_figure,'Style','edit','Units','normalized','Position',[.805 .9-i/(1.2*numcomp) .13 1/(2*numcomp)],'String',link.constraints(i),'BackgroundColor','w','Callback','editconstraintscallback');
end;    
end;


