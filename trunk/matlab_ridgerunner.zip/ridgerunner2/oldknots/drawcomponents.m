function drawcomponents(V, link, strutStartPoints,strutEndPoints,compressions, dVdt,a,h1,h2,h3,h4,h5); 

% FUNCTION drawcomponents draws a link (tubes and/or struts) according to the handles passed in.
%
% Input: an nx3 array Verts of locations in 3-space
%        a linkdata structure link, containing the fields
%
%           link.endpoints    a list of the endpoints of all the components
%           link.closed       a cell array of text strings 'open' or 'closed' for each component
%           link.colorvalues  an ix3 array of rgb color values for the components of the link
%           link.tranparency  a cell array of text strings 'Clear', 'Transparent', or 'Opaque'
%           link.tension      an ix1 array of the tension in each component
%           link.thickness    an nx1 array of the thickness of each tube
%           link.constraints  a cell array of text strings 'None', 'Fixed', or 'Surface'
%           link.surface      a cell array of text strings in the form 'z=f(x,y)' for each
%                             endpoint with a "surface" constraint.

% for every component: if 'tubes_off'-h1 is not marked draw cylinders and spheres joined
% together, draw interior lines if 'curves'-h2 is marked
% display constraints, if 'constraints'-h4 is marked
% display struts, if 'struts'-h5 is marked
% display vector field, if 'vectorfield'-h3 is marked


numcomp = size(link.tension,1); % We set the number of components in our link.
NumFaces=30;  % This sets the number of faces in our polygonal tubes.

[s,t]=size(V);
dVdt=reshape(dVdt,t,s)';
startpoint=1;

if get(h1,'Value')==0 
    
    displaytube(V,link,a);
    
end;

for i=1:numcomp
    
    endpoint=link.endpoints(i);
    
    if get(h2,'Value')==1
        displaypoly(V(startpoint:endpoint,:),link.closed(i),link.colorvalues{i},a);
    end;
    
    if get(h3,'Value')==1
        quiver3(V(:,1),V(:,2),V(:,3),dVdt(:,1),dVdt(:,2),dVdt(:,3),'r');
    end;
    
    if get(h4,'Value')==1
        displayconstraints(link,a);
    end;
    
    if get(h5,'Value')==1
        displaystruts(strutStartPoints,strutEndPoints,compressions);
    end;
    
    startpoint=endpoint+1;
end;

% Now that we've drawn everything, we make sure the axes are set correctly.

set(gca,'DataAspectRatio',[1 1 1]);
axis vis3d;
light;
