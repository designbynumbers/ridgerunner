%editthicknesscallback
for i=1:numcomp
    u=str2num(char(get(h_edit_component_thickness(i),'String')));
    link.thickness(i)=u;
end;
