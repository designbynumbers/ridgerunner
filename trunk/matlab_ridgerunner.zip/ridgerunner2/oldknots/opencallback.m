% opencallback
% open file, load variables into workspace,
[open_file_name,open_path_name]=uigetfile('*.mat','OPEN FILE',100,100);
if open_file_name~=0
    load(open_file_name);
end;
