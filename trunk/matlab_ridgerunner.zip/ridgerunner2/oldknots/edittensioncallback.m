%edittensioncallback
for i=1:numcomp
    u=str2num(char(get(h_edit_component_tension(i),'String')));
    link.tension(i)=u;
end;
