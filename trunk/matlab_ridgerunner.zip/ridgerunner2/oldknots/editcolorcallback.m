%editcolorcallback
for i=1:numcomp
  
    r=str2num(char(get(h_edit_component_color_value_r(i),'String')));
    g=str2num(char(get(h_edit_component_color_value_g(i),'String')));
    b=str2num(char(get(h_edit_component_color_value_b(i),'String')));
    
    link.colorvalues(i,:)= [r g b];
    set(h_component_color(i),'BackgroundColor',[r g b]);
end;
