% exportmingcallback

% Export the current knot (we can't deal with links in ming) in
% ming format.

[dummy,numcomp] = size(link.endpoints);

if numcomp ~= 1
  error('Export file: Ming files must have one component.');
end;

[export_file_name,export_path_name]=uiputfile('*','EXPORT FILE',100,100);
full_file_name = strcat(export_path_name,export_file_name);
fid = fopen(full_file_name,'w');

% first line contains {number of vertices} 
% l/3 is the number of vertices
[l,k]=size(verts);

fprintf(fid,'{%d}\n',l/3);

for i=1:l/3
    p=[verts(3*(i-1)+[1:3])]';
    fprintf(fid,'%f %f %f\n',p);
end;

fclose(fid);


 
