% exportrawcallback

% Export the current knot in raw format, which is the 3d coords
% with link components separated by empty lines

[dummy,numberOfComponents] = size(link.endpoints);

[export_file_name,export_path_name]=uiputfile('*','EXPORT FILE',100,100);
full_file_name = strcat(export_path_name,export_file_name);
fid = fopen(full_file_name,'w');

% first line contains {number of vertices} 
% l/3 is the number of vertices
[l,k]=size(verts);

component = 1;

for i=1:l/3
    p=[verts(3*(i-1)+[1:3])]';
    fprintf(fid,'%f %f %f\n',p);
    if(i==link.endpoints(component))
        fprintf(fid,'\n');
        component = component + 1;
    end;
end;

fclose(fid);


 
