% showgraphcallback
if get(H(7),'Value')==1
    set(H(14),'Position',[0.04 0.35 .75 .63]);
    H(29)=axes('Tag','PictureLengthTime','Units','normalized',...
    'Position',[0.04 0.05 .75 .25]);
else
    delete(H(29));
    set(H(14),'Position',[0.04 0.05 .75 .93]);
end;