% stopcallback

