function [vfinal] = experimental_rkode_with_bsearch(link,verts,tspan,errbound)

% FUNCTION experimental_rkode_with_bsearch attempts to model the constrained gradient flow
% of ropelength over an integration interval of tspan, with relative error bounds (errbound)
% starting from position (link,verts). 

% The function is fairly verbose, reporting its stepsizes as it proceeds. We use a 
% fairly small maxstep, to keep the accuracy of the "overstepper" called below within
% known bounds.

% We call updategraphics each time we make a step.

%% Stage 1. Set up the initial conditions.

stepsize = 0.05;         
maxstep  = 0.05;
time     = 0;

MAXNSTEPS = 1000;
indices = [];

for i=1:MAXNSTEPS 
    
    [dVdt,badstepflag,indices] = experimentalFirstvariation(link,verts,indices);
    [verts,ss_did,stepsize]    = bsearch_rkstep(link,verts,dVdt,stepsize,errbound,indices);

    time = time + ss_did;
    stepsize = min([stepsize maxstep]);  % Control growth of stepsize.
    
    sprintf('Time: %g. Accepted step of size: %g. Next step of size: %g. Length: %g',time,ss_did,stepsize,computelength(verts))
    updategraphics(0,verts,'regular');
    
    if (time > tspan) 

        vfinal = verts;
        return;
        
    end;
    
end;

sprintf('Exceeded MAXNSTEPS of %d at time %g.',MAXNSTEPS,time);
vfinal = verts;



