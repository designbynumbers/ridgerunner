function [H,current_ode_solver,saveas_file_name,movie_file_name,numcomp]=GraphicalUserInterface_Knots;

% [H,current_ode_solver,saveas_file_name,movie_file_name,numcomp]=GraphicalUserInterface_Knots;

% First, we setup some global variables

global numcomp;

% Define GUI window

   h_gui_figure=figure('Units','characters','Position',[14 22 112 32.3077],'IntegerHandle','off',...
    'MenuBar','none','Name','Knots','Tag','Knots_figure','Color',[0.8 0.8 0.8],'NumberTitle','off');

% Define uicontols

% Checkboxes
    h_tubes_off=uicontrol('Style','checkbox','String','Tubes off','Foregroundcolor',[0 0 0],...
    'Tag','Tubes','Tooltipstring','Display polygons only','Units','normalized',...
    'Position',[0.84 0.9 .14 .06],'BackgroundColor',[0.8 0.8 0.8]);

    h_vector_field=uicontrol('Style','checkbox','String','Vector Field','Foregroundcolor',[0 0 0],...
    'Tag','Vector Field','Tooltipstring','Display vector field','Units','normalized',...
    'Position',[0.84 0.82 .14 .06],'BackgroundColor',[0.8 0.8 0.8]);

    h_curves=uicontrol('Style','checkbox','String','Curves','Foregroundcolor',[0 0 0],...
    'Tag','Curves','Tooltipstring','Display curves','Units','normalized',...
    'Position',[0.84 0.74 .14 .06],'BackgroundColor',[0.8 0.8 0.8]);

    h_struts=uicontrol('Style','checkbox','String','Struts','Foregroundcolor',[0 0 0],...
    'Tag','Struts','Tooltipstring','Display struts','Units','normalized',...
    'Position',[0.84 0.66 .14 .06],'BackgroundColor',[0.8 0.8 0.8]);

    h_constraints=uicontrol('Style','checkbox','String','Constraints','Foregroundcolor',[0 0 0],...
    'Tag','Constraints','Tooltipstring','Display constraints','Units','normalized',...
    'Position',[0.84 0.58 .14 .06],'BackgroundColor',[0.8 0.8 0.8]);

    h_showgraph=uicontrol('Style','checkbox','String','Show Graph','Foregroundcolor',[0 0 0],...
    'Tag','Show Graph','Tooltipstring','Graph length over time','Units','normalized',...
    'Position',[0.84 0.26 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'Callback','showgraphcallback');

    h_record=uicontrol('Style','checkbox','String','Record','Foregroundcolor',[0 0 0],...
    'Tag','Record','Tooltipstring','Record movie frames','Units','normalized',...
    'Position',[0.84 0.18 .14 .06],'callback','recordcallback','BackgroundColor',[0.8 0.8 0.8]);

% Pushbuttons

    h_go=uicontrol('Style','pushbutton','String','GO','Foregroundcolor',[0 0 0],...
    'Tag','GO','Tooltipstring','Start simulation','Units','normalized',...
    'Position',[0.84 0.5 .14 .06],'callback','gocallback','BackgroundColor',[0.8 0.8 0.8]);

    h_stop=uicontrol('Style','pushbutton','String','STOP','Foregroundcolor',[0 0 0],...
    'Tag','STOP','Tooltipstring','Pause simulation','Units','normalized',...
    'Position',[0.84 0.42 .14 .06],'callback','stopcallaback','BackgroundColor',[0.8 0.8 0.8]);

    h_clear=uicontrol('Style','pushbutton','String','CLEAR','Foregroundcolor',[0 0 0],...
    'Tag','CLEAR','Tooltipstring','Clear figure','Units','normalized',...
    'Position',[0.84 0.34 .14 .06],'callback','clearcallback','BackgroundColor',[0.8 0.8 0.8]);

% Static text

    h_filename_text=uicontrol('Style','text','String','Input Filename','Foregroundcolor',[0 0 0],...
    'Tag','InputFilename','Units','normalized',...
    'Position',[0.84 0.1 .14 .06],'BackgroundColor',[0.8 0.8 0.8],'Visible','off');

% Editible text

    h_filename_edit_text=uicontrol('Style','edit','String','Movie_1','Foregroundcolor',[0 0 0],...
    'Tag','EditFileName','Tooltipstring','Specify file of record','Units','normalized',...
    'Position',[0.84 0.05 .14 .06],'callback','editfilenamecallback','BackgroundColor',[1 1 1],'Visible','off');

% Define axes

    h_picture_main=axes('Tag','Picture Main','Units','normalized',...
    'Position',[0.04 0.05 .75 .93]);


% Define uimenu

    h_menu_file=uimenu(h_gui_figure,'Label','File','Tag','File');

        h_menu_file_open=uimenu(h_menu_file,'Label','Open','Tag','Open','Callback','opencallback');
            
        h_menu_file_save=uimenu(h_menu_file,'Label','Save','Tag','Save','Callback','savecallback');
        
        h_menu_file_save_as=uimenu(h_menu_file,'Label','Save as','Tag','Saveas','Callback','saveascallback');
        
        h_menu_file_import=uimenu(h_menu_file,'Label','Import','Tag','Import','Callback','importcallback');
        
        h_menu_file_export=uimenu(h_menu_file,'Label','Export','Tag','Export','Callback','exportcallback');


    h_menu_edit=uimenu(h_gui_figure,'Label','Edit','Tag','Edit');

        h_menu_edit_properties=uimenu(h_menu_edit,'Label','Data properties','Tag','DataProperties','Callback','datapropertiescallback');
        
        h_menu_edit_ode_solver=uimenu(h_menu_edit,'Label','ODE solver','Tag','ODEsolver');
                h_menu_edit_ode_solver_item1=uimenu(h_menu_edit_ode_solver,'Label','ode45','Tag','ode45','Callback','odesolveritem1callback','Checked','on');
                h_menu_edit_ode_solver_item2=uimenu(h_menu_edit_ode_solver,'Label','ode23','Tag','ode23','Callback','odesolveritem2callback');
                h_menu_edit_ode_solver_item3=uimenu(h_menu_edit_ode_solver,'Label','ode113','Tag','ode113','Callback','odesolveritem3callback');
                h_menu_edit_ode_solver_item4=uimenu(h_menu_edit_ode_solver,'Label','ode15s','Tag','ode15s','Callback','odesolveritem4callback');
                h_menu_edit_ode_solver_item5=uimenu(h_menu_edit_ode_solver,'Label','ode23s','Tag','ode23s','Callback','odesolveritem5callback');
                h_menu_edit_ode_solver_item6=uimenu(h_menu_edit_ode_solver,'Label','ode23t','Tag','ode23t','Callback','odesolveritem6callback');
                h_menu_edit_ode_solver_item7=uimenu(h_menu_edit_ode_solver,'Label','ode23tb','Tag','ode23tb','Callback','odesolveritem7callback');
% Initialize

current_ode_solver='ode45';
saveas_file_name=[];
h_picture_length_time=-1;
movie_file_name=[];
numcomp=0;
H=[h_gui_figure;
   h_tubes_off;
   h_vector_field;
   h_curves;
   h_struts;
   h_constraints;
   h_showgraph;
   h_record;
   h_go;
   h_stop;
   h_clear;
   h_filename_text;
   h_filename_edit_text;
   h_picture_main;
   h_menu_file_open;
   h_menu_file_save;
   h_menu_file_save_as;
   h_menu_file_import;
   h_menu_file_export;
   h_menu_edit_properties;
   h_menu_edit_ode_solver;
   h_menu_edit_ode_solver_item1;
   h_menu_edit_ode_solver_item2;
   h_menu_edit_ode_solver_item3;
   h_menu_edit_ode_solver_item4;
   h_menu_edit_ode_solver_item5;
   h_menu_edit_ode_solver_item6;
   h_menu_edit_ode_solver_item7;
   h_picture_length_time;];

% We now setup some standard graphics options.

set(h_picture_main,'DataAspectRatio',[1 1 1]);
camproj(h_picture_main,'perspective');
lighting gouraud;
set(h_gui_figure,'Renderer','OpenGL');

   
   