% Script testfirstvariation imports a vect file, and runs firstvariation on it.

global numcomp;
global COUNTER;

[H,current_ode_solver,saveas_file_name,movie_file_name,numcomp]=GraphicalUserInterface_Knots;

%load p7_4_320 p7_4_320;
load ld.mat link;

p7_4_320 = A8_1_64_f3o2

%verts = p7_4_320';
link.endpoints(1) = 64;



link.thickness = 1;

%load ./data/vertvert1.mat link verts;
%verts = verts';

set(H(2),'Value',1);    % Turn off tubes
set(H(4),'Value',1);    % Turn on curves
%set(H(5),'Value',1);   % Turn on struts
set(H(3),'Value',1);    % Turn on vector field.

figure(H(1));

% determine axis limits

[n,k]=size(verts);
v=reshape(verts,3,n/3)';

ax1=[min(v(:,1))-1 max(v(:,1))+1 min(v(:,2))-1 max(v(:,2))+1 min(v(:,3))-1 max(v(:,3))+1];
ax2 = [];

COUNTER = 0;
dVdt = firstvariation([],verts,[],link,ax1,ax2,H([14 7 29 2 4 3 6 5 8]));
  
           
