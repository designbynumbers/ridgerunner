%editconstraintscallback

for i=1:numcomp
    
    u=(get(h_edit_component_constraints(i),'String'));
    link.constraints{i} = u;
    
    if  strcmpi(u,'surface')
        
        ff=link.surface{i};
        CC=link.colorvalues{i};
        f=surfacedialogbox(CC,ff);
        link.surface{i}=f;
        
    end;  
    
end;
