function dl = dlen(Verts,link)

% DLEN computes the first variation of (weighted) length for a link as a vector field
%
% Input: an nx3 array Verts of locations in 3-space
%        a linkdata structure link, containing the fields
%
%           link.endpoints    a list of the endpoints of all the components
%           link.closed       a cell array of text strings 'open' or 'closed' for each component
%           link.colorvalues  an ix3 array of rgb color values for the components of the link
%           link.tranparency  a cell array of text strings 'Clear', 'Transparent', or 'Opaque'
%           link.tension      an ix1 array of the tension in each component
%           link.thickness    an nx1 array of the thickness of each tube
%           link.constraints  a cell array of text strings 'None', 'Fixed', or 'Surface'
%           link.surface      a cell array of text strings in the form 'z=f(x,y)' for each
%                             endpoint with a "surface" constraint.
%
% Output: an nx3 array dl giving the first variation of length (weighted by the tensions of the 
%         components) as a vector located at each vertex of V.
%
% Algorithm: For each edge of the link, we assign to each of the endpoints a vector
% of length Tension pointing inwards in the direction of the edge. We then sum all of 
% these vectors at each edge, and return the results.

dl = zeros(size(Verts));
NumComponents = size(link.endpoints,1);

% We begin by making an array of startpoints.The first component starts at 1- the others just
% after the endpoint of the previous component. 

Startpoint=[1 link.endpoints(1:NumComponents-1)+1];

for i=1:NumComponents
    
    % First, we isolate and preprocess the vectors in this component.
    
    v=Verts(Startpoint(i):link.endpoints(i),:);
    last = size(v,1);
    
    if (strcmpi(link.closed{i},'closed'))   % If the component is closed, the vertices should wrap around
        v=[v(last,:);v;v(1,:)];
    elseif (strcmpi(link.closed{i},'open')) % If the component is open, they shouldn't
        v=[v(1,:);v;v(last,:)];  
    else
        error('link.closed contains illegal string (neither closed nor open)');
    end;
        
    % Now we compute the (unit) edges before and after each vertex.    
        
    trailedge  = normalizenx3(v(1:last,:)   - v(2:last+1,:));
    leadedge   = normalizenx3(v(3:last+2,:) - v(2:last+1,:));
    
    % Last, we assemble the results.
    
    dl(Startpoint(i):link.endpoints(i),:)=link.tension(i)*(trailedge+leadedge);
    
end;