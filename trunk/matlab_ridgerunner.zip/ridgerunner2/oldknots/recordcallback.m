%recordcallback
if get(H(8),'Value')==1
    set(H(12),'Visible','on');
    set(H(13),'Visible','on');
end;
