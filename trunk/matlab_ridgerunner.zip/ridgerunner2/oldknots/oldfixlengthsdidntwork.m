function newVerts = fixlengths(Verts,link);

% FUNCTION FIXLENGTHS fixes the lengths, so they are about the same, which is good enough for Jason
% right now, that may change

% Input: V             3nx1 list of coordinates of vertices of components
%        link          a linkdata structure, containing the fields
%
%                         link.endpoints    a list of the endpoints of all the components
%                         link.closed       a cell array of text strings 'open' or 'closed' for each component
%                         link.constraints  a cell array of text strings 'None', 'Fixed', or 'Surface'
%                         link.surface      a cell array of text strings in the form 'z=f(x,y)' for each
%                                           endpoint with a "surface" constraint.
%

% Output: nuttin honey
%
% Algorithm: We redistribute the vertices so that they are equally distributed with respect to arc length
% on the old link.  It does not make things exactly equilateral, but it is quick and works pretty well.

% We start by testing our input, and complaining if it doesn't look right.

if (nargin ~= 2)
    
    error('fixlengths: must input (Verts,link)');
    
end;

if (nargout ~= 0)
    
    error('fixlengths: sorry, no output.');
    
end;

if ((mod(size(Verts,1),3) ~= 0) | (size(Verts,2) ~= 1))
    
    error('fixlengths: Expect Verts to be a 3nx1 column vector.');
    
end;

% First, we reshape V for convenience in working with it inside the function.
% We also set n to the number of vertices in V.

[n,k]=size(Verts);
V=reshape(Verts,3,n/3)';  % This is important! The vector appears as (x1 y1 z1 x2 y2 z2 ... )'
[n,k]=size(V);            % We must reshape it so that the correct elements end up together!

vlength = 0;
newvlength = 0;

% Loop over components
[dummy,numberOfComponents] = size(link.endpoints);
component = 1;

startOfLoop = 1;
endOfLoop = link.endpoints(1);

flag = 1;

while(flag==1)
  component
  length = computelength(V,link,component)

  if(strcmp(link.closed(component),'closed') == 1)
    goal = length/(endOfLoop-startOfLoop+1)
  else
    goal = length/(endOfLoop-startOfLoop);
  end;
  
  left = norm(V(startOfLoop+1,:)- V(startOfLoop,:),2);
  tmpgoal = goal;
  used = 0;
  
  newVerts(startOfLoop,:) = V(startOfLoop,:);
  
  j = startOfLoop + 1;
  
  for i=startOfLoop:endOfLoop
    while( (left > tmpgoal) & (j <= endOfLoop) )
      if(i<endOfLoop)
	j
	newVerts(j,:) = ((tmpgoal+used)/norm(V(i+1,:)-V(i,:),2))* (V(i+1,:)-V(i,:)) + V(i,:)
	left = left - tmpgoal;
	used = used + tmpgoal;
	tmpgoal = goal;
	
	j;
	norm(V(j,:) - V(j-1,:),2);
	norm(newVerts(j,:) - newVerts(j-1,:),2);
	% vlength = vlength + norm(V(j,:) - V(j-1,:),2);
	% newvlength = newvlength + norm(newVerts(j,:) - newVerts(j-1,:),2);
	
      j = j + 1;
      else
	if(strcmp(link.closed(component),'closed') == 1)
	  j+1000
	newVerts(j,:) = ((tmpgoal+used)/norm(V(startOfLoop,:)- ...
					     V(endOfLoop,:),2)) * (V(startOfLoop,:)-V(endOfLoop,:)) + V(i,:)
	left = left - tmpgoal;
	used = used + tmpgoal;
	tmpgoal = goal;
	
	j
	norm(V(j,:) - V(j-1,:),2)
	norm(newVerts(j,:) - newVerts(j-1,:),2)
	% vlength = vlength + norm(V(j,:) - V(j-1,:),2);
	% newvlength = newvlength + norm(newVerts(j,:) - newVerts(j-1,:),2);
	
	j = j + 1;
	end;
      end;
    end;
    
    tmpgoal = tmpgoal - left;
    
    if(i<endOfLoop-1)
      i = i + 1;
      left = norm(V(i+1,:)-V(i,:),2); 
      
      %     elseif(strcmp(link.closed(component),'closed') == 1)
      %           i = i + 1;
      %           
      %           if(component == 1)
      %	      left = norm(V(1,:)-V(i,:),2);
      %            else
      %	      left = norm(V(link.endpoint(component-1) + 1,:)-V(i,:),2);
      %            end;
    end;
    used = 0;
    
  end;
  
  component = component + 1;
  j = j - 1;
  
  if(component > numberOfComponents)
    flag = 0;
    break;
  end;
  
  
  startOfLoop = endOfLoop+1;
  endOfLoop = link.endpoints(component);
end;

size(V);
size(newVerts);
newVerts;

for i=1:numberOfComponents
  i
  computelength(V,link,i)
end;

