%   gocallback
%   list of handles in H
%   h_gui_figure;1
%   h_tubes_off;2
%   h_vector_field;3
%   h_curves;4
%   h_struts;5
%   h_constraints;6
%   h_showgraph;7
%   h_record;8
%   h_go;9
%   h_stop;10
%   h_clear;11
%   h_filename_text;12
%   h_filename_edit_text;13
%   h_picture_main;14
%   h_menu_file_open;15
%   h_menu_file_save;16
%   h_menu_file_save_as;17
%   h_menu_file_import;18
%   h_menu_file_export;19
%   h_menu_edit_properties;20
%   h_menu_edit_ode_solver;21
%   h_menu_edit_ode_solver_item1;22
%   h_menu_edit_ode_solver_item2;23
%   h_menu_edit_ode_solver_item3;24
%   h_menu_edit_ode_solver_item4;25
%   h_menu_edit_ode_solver_item5;26
%   h_menu_edit_ode_solver_item6;27
%   h_menu_edit_ode_solver_item7;28
%   h_picture_length_time;29

global MOVIEMATRIX;
global COMPONENTLENGTH;
global TIME;
global COUNTER;

MOVIEMATRIX=[];
COUNTER=0;
COMPONENTLENGTH=[];
TIME=[];

%   activate gui figure

figure(H(1));

%   determine axis limits

[n,k]=size(verts);
v=reshape(verts,n/3,3);
ax1=[min(v(:,1))-1 max(v(:,1))+1 min(v(:,2))-1 max(v(:,2))+1 min(v(:,3))-1 max(v(:,3))+1];

%   open dialog box to specify the time span

timespan=timedialogbox;
ax2=timespan;

%   start integration of dV/dt=firstvariation(t,V,'',...)

[T,verts]=feval(current_ode_solver,'firstvariation',timespan,verts,[],link,ax1,ax2,H([14 7 29 2 4 3 6 5 8]));

if get(H(8),'Value')==1
    save(movie_file_name,'MOVIEMATRIX');
end;
if get(H(7),'Value')==1
    axes(H(29));
    for i=1:numcomp
        plot(TIME,COMPONENTLENGTH(:,i),'Color',link.colorvalues(i,:));
        hold on;
    end;
    set(H(29),'Xlim',ax2);
end;
helpdlg('Iterations have stoped.','Results');
    
        