function d = linfty(v,w)

% FUNCTION linfty computes the maximum (l-infinity) distance between any vertex of v and
% the corresponding vertex of w. We expect v and w to be nx3 matrices.

% First, we check the input arguments

if (nargin ~= 2) 
    
    error('linfty: Must have two arguments to compute distance.');
    
end;

if (size(v,2) ~= 3 | size(w,2) ~= 3) 
    
    error('linfty: Both v and w must be nx3 matrices.');
    
end;

% Now we compute.

df = (v - w).*(v - w);
nms = df(:,1) + df(:,2) + df(:,3);
mxnms = max(nms);

d = sqrt(mxnms);



