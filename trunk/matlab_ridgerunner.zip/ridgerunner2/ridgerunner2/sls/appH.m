function C=appH(HH,B)
% appH  Applies the orthogonal matrix Q on a vector
%       @(#)appH.m Version 1.2 9/16/97
%       Mikael Lundquist, University of Linkoping.
%       e-mail: milun@mai.liu.se
%
%       appH computes the product Q where Q is represented by the
%       householder vectors from the factorization of the frontal matrix 
%       in sqr.
%       H is obtained as output from sqrQ

% HH.nelim is the number of rows taken from the frontal matrix in step i
% HH.H represets the orthogonal manipulations on A
% HH.H(i).frontH is the householder vectors for the QR on the i:th frontal matrix
% HH.H(i).p is the rows in the i:th frontal matrix
% HH.Pr permutates A into columnleading order
% HH.rowperm is the final row permutation of A to R

% This is what happens in sqrQ: rowperm*(Qn'*...*Q1')Pr A = R

B(HH.rowperm,:)=B;

for i=length(HH.H):-1:1
  B(HH.H(i).p,:)=HH.H(i).frontH * B(HH.H(i).p,:);
end

C(HH.Pr,:)=B;


