function C=appHT(HH,B)
% appH  Applies the orthogonal matrix Q^T on a vector
%       @(#)appHT.m Version 1.2 9/16/97
%       Mikael Lundquist, University of Linkoping.
%       e-mail: milun@mai.liu.se
%
%       appH computes the product Q^T B where Q is represented by the
%       householder vectors from the factorization of the frontal matrix 
%       in sqr.
%       H is obtained as output from sqrQ

% HH.H represets the orthogonal manipulations on A
% HH.H(i).frontH is the householder vectors for the QR on the i:th frontal matrix
% HH.H(i).p is the rows in the i:th frontal matrix
% HH.Pr permutates A into columnleading order
% HH.rowperm is the final row permutation of A to R

% This is what happens in sqrQ: rowperm*(Qn'*...*Q1')Pr A = R

B=B(HH.Pr,:);

for i=1:length(HH.H)
  b=HH.H(i).frontH'*B(HH.H(i).p,:);
  B(HH.H(i).p,:)=b;
end
C=B(HH.rowperm,:);



