function ok=strut_test_suite(V,link,strutStartPoints,strutEndPoints,positions,indices,error)

% FUNCTION strut_test_suite automatically checks the struts produced by strutFinder
% to make sure that they obey the defining conditions of struts: that they be length 2,
% and normal to the tangent vectors on both their ends.

global GLOB_FVDATA;

struts = strutStartPoints - strutEndPoints;
strutnorms = sqrt(struts(:,1).^2 + struts(:,2).^2 + struts(:,3).^2);
struts = normalizenx3(struts);

lengtherror = max(abs(strutnorms - 2*GLOB_FVDATA.link.thickness));

%if (lengtherror > error) 
        
%    ok = 0;   % This is NOT ok!
%    'struts failed the strut test suite on a length error'
%    return;
    
%end;

% We are now going to check double-criticality.
% We'll need a list of all the tangent vectors coming into and out of vertices.

NumComponents = size(link.closed,1);
Startpoint=[1 link.endpoints(1:NumComponents-1)+1];

TanIn = zeros(size(V));
TanOut = zeros(size(V));

for i=1:NumComponents
    
    % First, we isolate and preprocess the vectors in this component.
    
    compv=V(Startpoint(i):link.endpoints(i),:);
    last = size(compv,1);
    
    if (strcmpi(link.closed{i},'closed'))   % If the component is closed, the vertices should wrap around
        compv=[compv(last,:);compv;compv(1,:)];
    elseif (strcmpi(link.closed{i},'open')) % If the component is open, they shouldn't
        compv=[compv(1,:);compv;compv(last,:)];  
    else
        error('link.closed contains illegal string (neither closed nor open)');
    end;
        
    % Now we compute the (unit) tangent vectors into and out of each vertex.    
        
    TanIn(Startpoint(i):link.endpoints(i),:)  = normalizenx3(compv(2:last+1,:) - compv(1:last,:));
    TanOut(Startpoint(i):link.endpoints(i),:) = normalizenx3(compv(3:last+2,:) - compv(2:last+1,:));
    
end;

strutcount = size(strutStartPoints,1);
strutdots = ones(strutcount,2);  % Initialize to something obvious!

% We now prepare to sort the failed struts as "EE" (edge-edge), "EV" (edge-vertex), and "VV" (vertex-vertex)

EE_tangents_failed = 0;
EV_tangents_failed = 0;
VV_tangents_failed = 0;

for i=1:strutcount

    if (positions(i,1) > 0 & positions(i,1) < 1.0)  % We have an edge strut.
        
        tangent1 = V(indices(i,2),:) - V(indices(i,1),:);
        tangent1 = tangent1 ./ norm(tangent1);
    
        strutdots(i,1) = dot(struts(i,:),tangent1);
        
        if (abs(strutdots(i,1)) > error) 

            if (positions(i,2) > 0 & positions(i,2) < 1.0) 
                
                EE_tangents_failed = EE_tangents_failed + 1;
                
            else 
                
                EV_tangents_failed = EV_tangents_failed + 1;
                
            end;
            
        end;  
        
    else % A vertex is involved. In this case, we take the dot with both tangent vectors.   
         % Since we are at a strut START point, the strut is coming IN. That means the
         % incoming tangent vector's dot should be NEGATIVE, and the outgoing POSITIVE.
         
        if (positions(i,1) == 0)           % We're at index 1
        
            if (dot(TanIn(indices(i,1),:),struts(i,:)) > 0 | dot(TanOut(indices(i,1),:),struts(i,:)) < 0) 
            
                if (positions(i,2) > 0 & positions(i,2) < 1.0) % we are in the EV case
                
                    EV_tangents_failed = EV_tangents_failed + 1;
                
                else 
                    
                    VV_tangents_failed = VV_tangents_failed + 1;
                
                end;
                
            end;
                                     
        elseif (positions(i,1) == 1.0)     % We're at index 2   
            
            if (dot(TanIn(indices(i,2),:),struts(i,:)) > 0 | dot(TanOut(indices(i,2),:),struts(i,:)) < 0) 
            
                if (positions(i,2) > 0 & positions(i,2) < 1.0) % we are in the EV case
                
                    EV_tangents_failed = EV_tangents_failed + 1;
                
                else 
                    
                    VV_tangents_failed = VV_tangents_failed + 1;
                
                end;
                
            end;
                      
        end; 
        
    end;
    
    if (positions(i,2) > 0 & positions(i,2) < 1.0)  % We have an edge strut.
        
        tangent2 = V(indices(i,3),:) - V(indices(i,4),:);
        tangent2 = tangent2 ./ norm(tangent2);
    
        strutdots(i,2) = dot(struts(i,:),tangent2);
            
        if (abs(strutdots(i,2)) > error) 

            if (positions(i,1) > 0 & positions(i,1) < 1.0) % we are in the EE case
                
                EE_tangents_failed = EE_tangents_failed + 1;
                
            else 
                
                EV_tangents_failed = EV_tangents_failed + 1;
                
            end;
            
        end;     
        
    else % A vertex is involved. In this case, we take the dot with both tangent vectors.
         % Since we're at a strut END point, we reverse the inequality conditions from earlier.
         
         if (positions(i,2) == 0)           % We're at index 3
        
            if (dot(TanIn(indices(i,1),:),struts(i,:)) < 0 | dot(TanOut(indices(i,1),:),struts(i,:)) > 0) 
            
                if (positions(i,1) > 0 & positions(i,1) < 1.0) % we are in the EV case
                
                    EV_tangents_failed = EV_tangents_failed + 1;
                
                else 
                    
                    VV_tangents_failed = VV_tangents_failed + 1;
                
                end;
                
            end;
                                     
        elseif (positions(i,2) == 1.0)     % We're at index 4   
            
            if (dot(TanIn(indices(i,2),:),struts(i,:)) < 0 | dot(TanOut(indices(i,2),:),struts(i,:)) > 0) 
            
                if (positions(i,1) > 0 & positions(i,1) < 1.0) % we are in the EV case
                
                    EV_tangents_failed = EV_tangents_failed + 1;
                
                else 
                    
                    VV_tangents_failed = VV_tangents_failed + 1;
                
                end;
                
            end;
                      
        end; 
                        
    end;
    
end;

if (EE_tangents_failed > 0 | EV_tangents_failed > 0 | VV_tangents_failed > 0) 
    
     ok = 0;
     message = sprintf('Dot product failures! EE: %d  EV: %d  VV: %d.\n',...
            EE_tangents_failed,EV_tangents_failed,VV_tangents_failed);     
     warning(message);
     return;
     
 end;
 
 ok = 1;
 

% END OF DEBUGGING CODE