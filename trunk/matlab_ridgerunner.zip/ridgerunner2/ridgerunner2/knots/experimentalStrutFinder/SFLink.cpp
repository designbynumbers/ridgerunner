#include "SFLink.h"
//#include <fstream>
//#include <stdio.h>
//#include <string>
#include "mex.h"

using namespace std;

const double BIGNUMBER = 65000;

bool gSelfIntersection;

SFLink::SFLink( double* inVertices, int inSize, linkdata & inLinkData )
{
    gSelfIntersection = false;
    
    mStrutCount = 0;

    mNumberOfComponents = (int)inLinkData.compNum;
    jigglingEveryone = false;
        
    mComponents =(KComponent**)mxMalloc( sizeof(KComponent*)*mNumberOfComponents );

    // we need to *get* the vertices manually here
    
    for( int i=0; i<mNumberOfComponents; i++ )
    {
        int compSize;
        if( i==(mNumberOfComponents-1) )
            compSize = inSize-inLinkData.cstart[i];
        else
            compSize = inLinkData.cstart[i+1] - inLinkData.cstart[i];
            
        compSize /= 3;
        
        KComponent *comp = (KComponent*)mxMalloc(sizeof(KComponent));
        comp->lenvtr = (vectors*)mxMalloc(sizeof(vectors));
        comp->lenvtr->myList = NULL;
        comp->side = (rawdonvector*)mxMalloc(sizeof(rawdonvector));
        comp->side->data = NULL;
        comp->angle = (vectors*)mxMalloc(sizeof(vectors));
        comp->angle->myList = NULL;
        comp->vertex = (rawdonvector*)mxMalloc(sizeof(rawdonvector));
        comp->vertex->data = NULL;
                
        comp->lenvtr->SetSize(compSize);
        comp->side->setSize(compSize);
        comp->angle->SetSize(compSize);
        comp->vertex->setSize(compSize);
               
        comp->R[0] = comp->R[1] = comp->R[2] = comp->R[3] = BIGNUMBER;
        
        comp->minRad_factor = 1; // default
        
        comp->definedThickness = inLinkData.thickness[i];
        
        comp->numSides = compSize;
                
        // get vertices
        for( int v=0; v<compSize; v++ )
        {
            comp->vertex->index(v).coord[0] = inVertices[inLinkData.cstart[i]+(3*v+0)];
            comp->vertex->index(v).coord[1] = inVertices[inLinkData.cstart[i]+(3*v+1)];
            comp->vertex->index(v).coord[2] = inVertices[inLinkData.cstart[i]+(3*v+2)];
        }
        
        mComponents[i] = comp;
    }
    
    // create dummy heaader node for strut list
    mStruts = (SFStrut*)mxMalloc(sizeof(struct SFStrut));
    mStruts->next = NULL;
    mLastStrut = mStruts;
        
    Compute();
  //  print();
//    stats();
    
/*    mexPrintf( "strut list\n" );
    // print strut list, skipping dummy header
    for( SFStrut* itr = mStruts->next; itr != NULL; itr = itr->next )
    {
        mexPrintf( "v1: %d v2: %d v3: %d v4: %d / pos1: %f pos2: %f\n", (int)itr->v1, (int)itr->v2,
                (int)itr->v3, (int)itr->v4, itr->positionEdge1, itr->positionEdge2 );
    }
    mexPrintf( "done\n" );
  */  
}

void
SFLink::print()
{
    for( int comp=0; comp<mNumberOfComponents; comp++ )
    {
        mexPrintf( "comp %d: (numsides: %d)\n", comp, mComponents[comp]->numSides );
        for( int vert=0; vert<mComponents[comp]->numSides; vert++ )
        {
            mexPrintf( "%d: (%f, %f, %f)\n", vert, mComponents[comp]->vertex->index(vert).coord[0], 
                    mComponents[comp]->vertex->index(vert).coord[1],
                    mComponents[comp]->vertex->index(vert).coord[2] );
        }
        mexPrintf( "\n" );
    }
}

void
SFLink::stats()
{
    mexPrintf( "overall ropelength: %f\n", RopeLength() );
    mexPrintf( "overall injrad: %f\n", injrad() );
    mexPrintf( "overall epsilon: %f\n", mEpsilon );
}

void
SFLink::saveAll()
{
}

// -

void
SFLink::jiggleAll()
{
    // suppress component jiggle recompute
    jigglingEveryone = true;
    for( int i=0; i<mNumberOfComponents; i++ )
        jiggle(i);
    jigglingEveryone = false;
    Compute();
}

void
SFLink::jiggle( int inComponent )
{
    int top = mComponents[inComponent]->numSides, i, j;
    double magnitude = Epsilon()*.1;
    magnitude *= 2;

    for(i=0; i < top; i++)
        for(j=0; j<3; j++)
            mComponents[inComponent]->vertex->index(i).coord[j] = mComponents[inComponent]->vertex->index(i).coord[j] + magnitude * (drand48()-.5);
    
    if( jigglingEveryone == false )
        Compute();
}

void
SFLink::jigglePoint()
{
    // pick random point and random component
    int component = fetchRandom(0, mNumberOfComponents-1);
    int	vIndex = fetchRandom(0, mComponents[component]->numSides-1);
    
    double magnitude = Epsilon()*.1;
    magnitude *= 2;

    for(int j=0; j<3; j++)
        mComponents[component]->vertex->index(vIndex).coord[j] = mComponents[component]->vertex->index(vIndex).coord[j] + (magnitude * (drand48()-.5));

    Compute();
}

void
SFLink::randomShift()
{
    // select component to shift
    int comp = fetchRandom(0, mNumberOfComponents-1);
    
    double shift[3];
    shift[0] = (drand48()-.5)*(Epsilon()*.3);
    shift[1] = (drand48()-.5)*(Epsilon()*.3);
    shift[2] = (drand48()-.5)*(Epsilon()*.3);
        
    for( int vert=0; vert<mComponents[comp]->numSides; vert++ )
    {
        for( int j=0; j<3; j++ )
            mComponents[comp]->vertex->index(vert).coord[j] = mComponents[comp]->vertex->index(vert).coord[j] + shift[j];
    }
    
    Compute();
}

void
SFLink::scaleComponent( int inComponent, double factor )
{
}

void
SFLink::scaleAll( double factor )
{
    for( int i=0; i<mNumberOfComponents; i++ )
        scaleComponent(i, factor);
}

void
SFLink::randomScale()
{
    // scale a random component, respecting epsilon
}

int 
fetchRandom( int min, int max )
{
    int size = max - min + 1;
    
    int num = rand() % size;
    return min + num;
}

// - 

void 
SFLink::rotatexy(int inComponent, const double & theta)
{
  point rotator[3];
  rotator[0].coord[0] = cos(theta);
  rotator[1].coord[1] = rotator[0].coord[0];
  rotator[1].coord[0] = sin(theta);
  rotator[0].coord[1] = -rotator[1].coord[0];
  rotator[0].coord[2] = rotator[1].coord[2] = rotator[2].coord[0] = rotator[2].coord[1] = 0;
  rotator[2].coord[2] = 1;

  int top = mComponents[inComponent]->numSides;

    for(int i=0; i< top; i++)
    {
        point temp = mComponents[inComponent]->vertex->index(i);
        for(int j=0; j<3; j++)
        {
            mComponents[inComponent]->vertex->index(i).coord[j] = rotator[j]*temp;
        }
    }
}

void 
SFLink::rotateyz(int inComponent, const double & angle)
{
  point rotator[3];
  rotator[1].coord[1] = cos(angle);
  rotator[2].coord[2] = rotator[1].coord[1];
  rotator[1].coord[2] = sin(angle);
  rotator[2].coord[1] = -rotator[1].coord[2];
  rotator[1].coord[0] = rotator[2].coord[0] = rotator[0].coord[1] = rotator[0].coord[2] = 0;
  rotator[0].coord[0] = 1;

  int top = mComponents[inComponent]->numSides;

    for(int i=0; i< top; i++)
    {
        point temp = mComponents[inComponent]->vertex->index(i);
        for(int j=0; j<3; j++)
        {    
            mComponents[inComponent]->vertex->index(i).coord[j] = rotator[j]*temp;
        }
    }
  
}

void 
SFLink::rotatezx(int inComponent, const double & phi)
{
  point rotator[3];
  rotator[0].coord[0] = cos(phi);
  rotator[2].coord[2] = rotator[0].coord[0];
  rotator[0].coord[2] = sin(phi);
  rotator[2].coord[0] = -rotator[0].coord[2];
  rotator[1].coord[0] = rotator[1].coord[2] = rotator[0].coord[1] = rotator[2].coord[1] = 0;
  rotator[1].coord[1] = 1;

  int top = mComponents[inComponent]->numSides;

    for(int i=0; i< top; i++)
    {
        point temp = mComponents[inComponent]->vertex->index(i);
        for(int j=0; j<3; j++)
            mComponents[inComponent]->vertex->index(i).coord[j] = rotator[j]*temp;
    }
}


void 
SFLink::rotateyz(int inComponent, const double & rho, const int & i, const int & j)
{
  // precondition: i<j 
  point rotator[3];
  rotator[1].coord[1] = cos(rho);
  rotator[2].coord[2] = rotator[1].coord[1];
  rotator[2].coord[1] = sin(rho);
  rotator[1].coord[2] = -rotator[2].coord[1];
  rotator[0].coord[1] = rotator[0].coord[2] = rotator[1].coord[0] = rotator[2].coord[0] = 0;
  rotator[0].coord[0] = 1;

    for(int k=i+1; k < j; k++)
    {
        point temp = mComponents[inComponent]->vertex->index(k);
        for(int n=0; n<3; n++)
            mComponents[inComponent]->vertex->index(k).coord[n] = rotator[n]*temp;
    }
}

void 
SFLink::crankInPlace(int inComponent, const double & rho, const int & i, const int & j, int inDirection)
{
  // precondition: i<j
    point rotator[3];
    
    // we use:
    
//    R = [ tx^2+c, txy+sz, txz-sy ]
//        [ txy-sz, ty^2+c, tyz+sx ]
//        [ txz+sy, tyz-sx, tz^2+c ]
//    
//    c = cos�
//    s = sin�
//    t = 1 - cos�
//    
//    <x,y,z> - a unit vector along the axis of rotation
    //
    
    // form x,y,z, a unit vector along the axis of rotation ij
    double directionOrigin[3];
    
    int startVert, endVert;
    startVert = i;
    endVert = j;
    
    // storing this directly saves a little time and makes things simpler
    directionOrigin[0] = mComponents[inComponent]->vertex->index(startVert).coord[0];
    directionOrigin[1] = mComponents[inComponent]->vertex->index(startVert).coord[1];
    directionOrigin[2] = mComponents[inComponent]->vertex->index(startVert).coord[2];
    
    double x = mComponents[inComponent]->vertex->index(endVert).coord[0] - directionOrigin[0];
    double y = mComponents[inComponent]->vertex->index(endVert).coord[1] - directionOrigin[1];
    double z = mComponents[inComponent]->vertex->index(endVert).coord[2] - directionOrigin[2];
    double mag = sqrt(x*x+y*y+z*z);
    x /= mag;
    y /= mag;
    z /= mag;
        
    // the rest is just an expression of the rotation matrix outlined above
    double c = cos(rho);
    double s = sin(rho);
    double t = 1 - c;
    
    // speed things up by caching twice used vals
    double txy = t*x*y, sz = s*z, sy = s*y, tyz = t*y*z, sx = s*x, txz = t*x*z;
    rotator[0][0] = t*x*x+c;
    rotator[0][1] = txy+sz;
    rotator[0][2] = txz-sy;
    
    rotator[1][0] = txy-sz;
    rotator[1][1] = t*y*y+c;
    rotator[1][2] = tyz+sx;
    
    rotator[2][0] = txz+sy;
    rotator[2][1] = tyz-sx;
    rotator[2][2] = t*z*z+c;
    
    if( inDirection == kItoJdir )
    {
        for(int k=i+1; k < j; k++)
        {
            point temp = mComponents[inComponent]->vertex->index(k);
            
            // translate this to be relative to our axis, which we can view as being at the origin
            // since our calculations are based on a unit vector
            temp[0] -= directionOrigin[0];
            temp[1] -= directionOrigin[1];
            temp[2] -= directionOrigin[2];
            
            // do the computations for rotation and translate back to the original position (albeit rotated)
            mComponents[inComponent]->vertex->index(k).coord[0] = temp[0]*rotator[0][0] + temp[1]*rotator[1][0] 
                                                                + temp[2]*rotator[2][0] + directionOrigin[0];
            mComponents[inComponent]->vertex->index(k).coord[1] = temp[0]*rotator[0][1] + temp[1]*rotator[1][1] 
                                                                + temp[2]*rotator[2][1] + directionOrigin[1];
            mComponents[inComponent]->vertex->index(k).coord[2] = temp[0]*rotator[0][2] + temp[1]*rotator[1][2] 
                                                                + temp[2]*rotator[2][2] + directionOrigin[2];
        }
    }
    else
    {
        int incrementer = 1;
        for(int k=j; k != i; k=((j+incrementer++)%mComponents[inComponent]->vertex->length()))
        {
            point temp = mComponents[inComponent]->vertex->index(k);
            
            // translate this to be relative to our axis, which we can view as being at the origin
            // since our calculations are based on a unit vector
            temp[0] -= directionOrigin[0];
            temp[1] -= directionOrigin[1];
            temp[2] -= directionOrigin[2];
            
            // do the computations for rotation and translate back to the original position (albeit rotated)
            mComponents[inComponent]->vertex->index(k).coord[0] = temp[0]*rotator[0][0] + temp[1]*rotator[1][0] 
                                                                + temp[2]*rotator[2][0] + directionOrigin[0];
            mComponents[inComponent]->vertex->index(k).coord[1] = temp[0]*rotator[0][1] + temp[1]*rotator[1][1] 
                                                                + temp[2]*rotator[2][1] + directionOrigin[1];
            mComponents[inComponent]->vertex->index(k).coord[2] = temp[0]*rotator[0][2] + temp[1]*rotator[1][2] 
                                                                + temp[2]*rotator[2][2] + directionOrigin[2];
        }
    }
}

void
SFLink::Crank(const int inComponent, const double & angle, const int & i, const int & j)
{
    rotateyz(inComponent,angle,i,j);
}

// - 

void
SFLink::Compute()
{
    for( int itr=0; itr<mNumberOfComponents; itr++ )
    {
        mComponents[itr]->R[0] = mComponents[itr]->R[1] = 
            mComponents[itr]->R[2] = mComponents[itr]->R[3] = BIGNUMBER;
    
        mComponents[itr]->polyLength=0;
        mComponents[itr]->epsilon = 64000;
        int last = mComponents[itr]->numSides - 1;
        
        // last is here to speed computations by avoiding modulo issues 
        
        for(int i=0; i<last; i++)
        {
            mComponents[itr]->side->index(i) = mComponents[itr]->vertex->index(i+1) - mComponents[itr]->vertex->index(i);
            (*mComponents[itr]->lenvtr)[i] = mComponents[itr]->side->index(i).norm();
            if( (*mComponents[itr]->lenvtr)[i] < mComponents[itr]->epsilon )
                mComponents[itr]->epsilon = (*mComponents[itr]->lenvtr)[i];
            mComponents[itr]->polyLength += (*mComponents[itr]->lenvtr)[i];
        }
        
        mComponents[itr]->side->index(last) = mComponents[itr]->vertex->index(0) - mComponents[itr]->vertex->index(last);
        (*mComponents[itr]->lenvtr)[last] = mComponents[itr]->side->index(last).norm();
        if( (*mComponents[itr]->lenvtr)[last] < mComponents[itr]->epsilon )
            mComponents[itr]->epsilon = (*mComponents[itr]->lenvtr)[last];
        mComponents[itr]->polyLength += (*mComponents[itr]->lenvtr)[last];
        
        // at this point, epsilon is min edge length
    }
        
    ThicknessData();
}

void
SFLink::ThicknessData()
{
    int k,i,j;
    double sumangle, totalcurvature=0, dummy;
    double a,b,d;

    // angle data
    for( int itr=0; itr<mNumberOfComponents; itr++ )
    {
        double maxCurvature=0;
        
        double value = (mComponents[itr]->side->index(mComponents[itr]->numSides-1)*mComponents[itr]->side->index(0)) / ((*mComponents[itr]->lenvtr)[mComponents[itr]->numSides-1]*(*mComponents[itr]->lenvtr)[0]);
        if (value >= 1)
            mComponents[itr]->angle[0] = 0;
        else if (value <= -1)
            mComponents[itr]->angle[0] = M_PI;
        else
        {
            (*mComponents[itr]->angle)[0]=acos(value);
            totalcurvature = (*mComponents[itr]->angle)[0];
            double num = (2*tan((*mComponents[itr]->angle)[0]*.5));
            // check to see if curvature is bigger than the maximum 
            dummy = num/(*mComponents[itr]->lenvtr)[0];
            if(dummy>maxCurvature)
                maxCurvature=dummy;
            dummy = (num/(*mComponents[itr]->lenvtr)[mComponents[itr]->numSides-1]);
            if(dummy>maxCurvature)
                maxCurvature=dummy;
        }
        
        for (k=1; k<mComponents[itr]->numSides; k++)
        {
            // angle[k] is the exterior angle at vertex[k] which is the 
             //   angle between side[k-1] and side[k] 
            double value = (mComponents[itr]->side->index(k-1)*mComponents[itr]->side->index(k)) / ((*mComponents[itr]->lenvtr)[k-1]*(*mComponents[itr]->lenvtr)[k]);
            if (value >= 1)
                (*mComponents[itr]->angle)[k] = 0;
            else if (value <= -1)
                (*mComponents[itr]->angle)[k] = M_PI;
            else
            {
                (*mComponents[itr]->angle)[k]=acos(value);
                totalcurvature += (*mComponents[itr]->angle)[k];
                double num = (2*tan((*mComponents[itr]->angle)[k]/2));
                dummy = num/(*mComponents[itr]->lenvtr)[k];
                // check to see if curvature is bigger than the maximum 
                if(dummy > maxCurvature)
                    maxCurvature=(num/(*mComponents[itr]->lenvtr)[k]);
                dummy = (num/(*mComponents[itr]->lenvtr)[k-1]);
                if(dummy > maxCurvature)
                    maxCurvature=dummy;
            }
        }
        
        // so we've got maxcurvature, and all the angles are set.
        
        mComponents[itr]->R[0] = (1/maxCurvature);
        if( mComponents[itr]->minRad_factor != 0 )
            mComponents[itr]->injRadius =  mComponents[itr]->R[0] * mComponents[itr]->minRad_factor;
        else 
            mComponents[itr]->injRadius = 65000;
            
        // check for dcsd over all points over all components, in the case of our own component, we 
        // can skip sides until curvature hits pi
        
        int top = mComponents[itr]->numSides - 1;
        for (i=0; i<=top; i++) // LESS THAN OR EQUAL TOP! WHEW! The stuff you have to do to mod for multiple components!
        {
            if( i!=top)
                sumangle = (*mComponents[itr]->angle)[i];
                            
            for( int compIndex=itr; compIndex<mNumberOfComponents; compIndex++ )
            {
                if( compIndex == itr ) // this is our component, skip till curvature pi
                {
                    if( i==top )
                        continue;
                
                    k=i;
                    j = mComponents[itr]->numSides - 1; // this is so the computation below is quick
                    do
                    {
                        k++;
                        sumangle += (*mComponents[itr]->angle)[k];
                    }while((sumangle<M_PI) && (k<j));
                    
                    sumangle = totalcurvature + (*mComponents[itr]->angle)[i] + (*mComponents[itr]->angle)[k] - sumangle;
                }
                else
                    k=0;
                
                for (j=k; (j<mComponents[compIndex]->numSides); j++)
                {
                    // early stop condition for our own component
                    if( !(sumangle >= M_PI) && (compIndex==itr) )
                        break;
                        
                    if( compIndex == itr )
                        sumangle -= (*mComponents[itr]->angle)[j];
                        
                       // if( compIndex != itr )
                    
                //    if (( (j-i)>1 ) && !( (i==0) && (j==top)))
                //    {
                    if( !(((j-i)>1 ) && !((i==0) && (j==top))) && (compIndex==itr) )
                        continue;
                        
                        // define dcsd to be this comp's thickness plus
                        // comparison comp's thickness
                        double	dcsd = mComponents[compIndex]->definedThickness +
                                        mComponents[itr]->definedThickness;
                                
                        double tooShort = 0.9*dcsd;
                        
                        bool    foundStrut = false;
                        
                        // new IntToInt starts here
                        if (find_rate(itr, compIndex, i,j,a,b,d))
                        {
                            if(d<mComponents[itr]->R[1])
                                mComponents[itr]->R[1] = d;
                               
                            foundStrut = true;
                            
                            if( tooShort < d && d <= dcsd )
                            {
                                addStrut( itr, compIndex, i, j, a, b );
                            }
                            else if( d < tooShort )
                            {
                                gSelfIntersection = true;
                                return;
                            }
                        
                        }
                        
                        // start VertToInt here, i vertex, j side 
                        point e=(mComponents[itr]->vertex->index(i)-mComponents[compIndex]->vertex->index(j));
                        a=(e*mComponents[compIndex]->side->index(j))/((*mComponents[compIndex]->lenvtr)[j]*(*mComponents[compIndex]->lenvtr)[j]);
                        if (0<=a && a<=1)
                        {
                            if(!foundStrut && IsDC(itr, compIndex, i,j,a))
                            {
                                d=(mComponents[itr]->vertex->index(i)+(a-1)*mComponents[compIndex]->vertex->index(j)+(-a)*mComponents[compIndex]->vertex->index(((j+1)%mComponents[compIndex]->numSides))).norm();
                                if(d<mComponents[itr]->R[2])
                                    mComponents[itr]->R[2]=d;
                                    
                                foundStrut = true;
                                
                                if( tooShort < d && d<= dcsd )
                                    addStrut( itr, compIndex, i, j, 0, a );
                                else if( d < tooShort )
                                {
                                    gSelfIntersection = true;
                                    return;
                                }
                            }
                        }
    
                        // j vertex, i side 
                        e=(mComponents[compIndex]->vertex->index(j)-mComponents[itr]->vertex->index(i));
                        a=(e*mComponents[itr]->side->index(i))/(mComponents[itr]->side->index(i)*mComponents[itr]->side->index(i));
                        if (0<=a && a<=1)
                        {
                            if(!foundStrut && IsDC(compIndex, itr, j,i,a))
                            {
                                d=(mComponents[compIndex]->vertex->index(j)+(a-1)*mComponents[itr]->vertex->index(i)+(-a)*mComponents[itr]->vertex->index(((i+1)%mComponents[itr]->numSides))).norm();
                                if(d<mComponents[itr]->R[2])
                                    mComponents[itr]->R[2]=d;
                                
                                foundStrut = true;
                                    
                                if( tooShort < d && d<= dcsd )
                                    addStrut( compIndex, itr, j, i, 0, a );
                                else if( d < tooShort )
                                {
                                    gSelfIntersection = true;
                                    return;
                                }
                            }
                        }
                        
                        // start VertToVert here 
                        if(!foundStrut && IsDC(itr, compIndex, i,j,0) && IsDC(compIndex, itr, j,i,0))
                        {
                            d=(mComponents[itr]->vertex->index(i)-mComponents[compIndex]->vertex->index(j)).norm();
                            if (d<mComponents[itr]->R[3])
                                mComponents[itr]->R[3]=d;
                            
                            if( tooShort < d && d<= dcsd )
                                addStrut( itr, compIndex, i, j, 0, 0 );
                            else if( d < tooShort )
                            {
                                gSelfIntersection = true;
                                return;
                            }
                        }
                        
                }
            }
        }
        
        for(i=1;i<4;i++)
        {
            mComponents[itr]->R[i]*=.5;
            if(mComponents[itr]->R[i]<mComponents[itr]->injRadius)
                mComponents[itr]->injRadius = mComponents[itr]->R[i];
        }
        
   /*     mexPrintf( "comp %d R[0]: %f\n", itr, mComponents[itr]->R[0] );
        mexPrintf( "comp %d R[1]: %f\n", itr, mComponents[itr]->R[1] );
        mexPrintf( "comp %d R[2]: %f\n", itr, mComponents[itr]->R[2] );
        mexPrintf( "comp %d R[3]: %f\n", itr, mComponents[itr]->R[3] );
     */   
        if( mComponents[itr]->injRadius < mComponents[itr]->epsilon)
            mComponents[itr]->epsilon = mComponents[itr]->injRadius;
        
    }
    
    // min epsilon over all components
    mEpsilon = BIGNUMBER;
    for( int i=0; i<mNumberOfComponents; i++ )
        if( mEpsilon > mComponents[i]->epsilon )
            mEpsilon = mComponents[i]->epsilon;
    
}

int 
SFLink::find_rate(int iComponent, int jComponent, const int & i, const int & j, 
		     double & a, double & b, double & d)
{ 
  double vv;
  point v;
  
  // we use this to store temporarily created points for use with 
  // createCrossPoint to speed things up a little
  point	pointCache;
  // vertex->index(j) - vertex->index(i) cache
  point vertexJminusI = mComponents[jComponent]->vertex->index(j) - mComponents[iComponent]->vertex->index(i);
  
  point::createCrossPoint( mComponents[iComponent]->side->index(i), mComponents[jComponent]->side->index(j), v );

//  v = side[i] & side[j];
  if ((vv = v * v)!= 0) {
    vv = 1/vv;
//    a = (((vertex->index(j) - vertex->index(i)) & side[j]) * v) * vv;
//    b = (((vertex->index(j) - vertex->index(i)) & side[i]) * v) * vv;

        point::createCrossPoint( vertexJminusI, mComponents[jComponent]->side->index(j), pointCache );
        a = (pointCache * v) * vv;
        
        point::createCrossPoint( vertexJminusI, mComponents[iComponent]->side->index(i), pointCache );
        b = (pointCache * v) * vv;
   }
  else 
    {
      double dummy = 1 / (mComponents[iComponent]->side->index(i) * mComponents[iComponent]->side->index(i));
     // double c = (vertex->index(j) - vertex->index(i)) * side[i] * dummy;
      double c = vertexJminusI * mComponents[iComponent]->side->index(i) * dummy;
      double d = ((mComponents[jComponent]->vertex->index(((j+1)%mComponents[jComponent]->numSides)) - mComponents[iComponent]->vertex->index(i)) * mComponents[iComponent]->side->index(i)) * dummy;
      if ( (c<0 && d<0) || (c>1 && d>1))
	a=-1, b=-1;
      else if (0<=c && 1>=c)
        a=c, b=0;
      else if (0<=d && 1>=d)
	a=d, b=1;
      else 
	{
	  a = 0;
	  b = (mComponents[iComponent]->vertex->index(i) - mComponents[jComponent]->vertex->index(j)) * mComponents[jComponent]->side->index(j) / (mComponents[jComponent]->side->index(j)*mComponents[jComponent]->side->index(j));
	}
    }

  if (0 <= a && a<=1 && 0<=b && b<=1)
    {
      d = ((mComponents[iComponent]->vertex->index(i) + a * mComponents[iComponent]->side->index(i)) - (mComponents[jComponent]->vertex->index(j) + b * mComponents[jComponent]->side->index(j))).norm();
      return 1;
    }
  else 
    return 0;
  
}

int 
SFLink::IsDC(int iComponent, int jComponent, const int & i, const int & j, const double & a)
{

  point v=(mComponents[jComponent]->vertex->index(j)+a*mComponents[jComponent]->side->index(j)-mComponents[iComponent]->vertex->index(i));

  int s;

  if(i>0)
  {
    s=( (v * mComponents[iComponent]->side->index(i-1)) >= 0);
  }
  else
  {
      s=( (v * mComponents[iComponent]->side->index(mComponents[iComponent]->numSides-1)) >= 0);
  }
    
  int t=(v*mComponents[iComponent]->side->index(i) <= 0);
    
  if (s == t)
    return 1;
  else
    return 0;
}

double
SFLink::RopeLength()
{    
    // total poly length over min injectivity radius
    double totalLen = 0;
    for( int i=0; i<mNumberOfComponents; i++ )
        totalLen += mComponents[i]->polyLength;
    
    return totalLen/injrad();
}

double
SFLink::injrad()
{
    double min = BIGNUMBER;
    for( int i=0; i<mNumberOfComponents; i++ )
    {
        if( mComponents[i]->injRadius < min )
            min = mComponents[i]->injRadius;
    }
    return min;
}

double
SFLink::Epsilon()
{
    return mEpsilon;
}

// translates knot so that vertex_i is at the origin and vertex_j lies
//   on the positive x-axis (y and z coords are 0)
void
SFLink::Normalize(int inComponent, const int & i, const int & j)
{
  int k;
  
  // Translate 
  point newOrigin = mComponents[inComponent]->vertex->index(i);
  
  for( int compIndex=0; compIndex<mNumberOfComponents; compIndex++ )
  {
    for(k=0; k<mComponents[compIndex]->vertex->length(); k++)
        mComponents[compIndex]->vertex->index(k) = mComponents[compIndex]->vertex->index(k) - newOrigin;
  }
  
  // M_PI and M_PI_2 are constants in math.h 
  // Rotate so that vertex j is on the x-axis 
  double theta = -atan( mComponents[inComponent]->vertex->index(j).coord[1] / mComponents[inComponent]->vertex->index(j).coord[0] );
  if( mComponents[inComponent]->vertex->index(j).coord[0] < 0 )
    theta = -M_PI + theta;

  long double phi = (mComponents[inComponent]->vertex->index(j).coord[2] / ( sqrt( mComponents[inComponent]->vertex->index(j).coord[0]*mComponents[inComponent]->vertex->index(j).coord[0] + 
	       		  mComponents[inComponent]->vertex->index(j).coord[1]*mComponents[inComponent]->vertex->index(j).coord[1] + mComponents[inComponent]->vertex->index(j).coord[2]*mComponents[inComponent]->vertex->index(j).coord[2] )) );
  if(phi >= 1)
    phi = 0;
  else
    phi = acos(phi);

  // phi correction gives angle to x-axis 
  phi = M_PI_2 - phi;
   
    for( int compIndex=0; compIndex<mNumberOfComponents; compIndex++ )
    {
        rotatexy(compIndex,theta);
  	rotatezx(compIndex,phi);
    }
}  

// this requires the link be equilateral
double
SFLink::ComputeMaxAngle(const int inComponent, const int & i, const int & j, int inDirection)
{
  point diff = mComponents[inComponent]->vertex->index(j) - mComponents[inComponent]->vertex->index(i);
  double d = (diff[0]*diff[0]) + (diff[1]*diff[1]) + (diff[2]*diff[2]);
  if (d<=0)
    {
      exit(-1);
    }
      
  double b;
    if (inDirection==kJtoIdir)
	b = (*mComponents[inComponent]->lenvtr)[0] * double(mComponents[inComponent]->vertex->length() - j + i);
    else
	b = (*mComponents[inComponent]->lenvtr)[0] * double(j-i);

  b = b*b;
//  d = d*d; we never took the sqrt in the distance calc above, so this is already dist squared
  double theta = ((2*injrad()) / (sqrt(b + d)));
  // make sure that we aren't taking asin of a big number 
  if(theta >= 1)
    {
      theta = M_PI_2;
    }
  else
    theta = 2 * asin(theta);

  return theta;
}

void
SFLink::addStrut( int comp1, int comp2, int v1, int v2, double pos1, double pos2 )
{
    SFStrut* newStrut = (SFStrut*)mxMalloc(sizeof(struct SFStrut));
    newStrut->next = NULL;
    
    newStrut->v1 = v1;
    newStrut->v2 = ((v1+1) % mComponents[comp1]->numSides);
    newStrut->v3 = v2;
    newStrut->v4 = ((v2+1) % mComponents[comp2]->numSides);
    
    newStrut->positionEdge1 = pos1;
    newStrut->positionEdge2 = pos2;
    
    mLastStrut->next = newStrut;
    mLastStrut = newStrut;
    
    mStrutCount++;
}