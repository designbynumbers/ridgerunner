function v = isendvert(thisvert,verts,linkdata)

% FUNCTION isendvert checks to see whether the vertex thisvert
% is an end vertex of the link described 

% First, we test the input arguments.

if (nargin ~= 3) 
    error('nextvert: requires three input arguments, thisvert, verts, and linkdata');    
end;

if (thisvert > size(verts,1) | thisvert < 1) 
    error('nextvert: thisvert must be a valid vertex number');
end;

% Next, we go ahead and check whether we're at the end of a 
% component. If so, a component start will have index one larger
% than ours, or we will be at the end of the array.

if (thisvert == size(verts,1)) 
    comp = size(linkdata.cstart,1);
else 
    comp = find(linkdata.cstart == thisvert+1)-1;
end;

% If neither of these is true, then we are in the simple case.

if (isempty(comp)) 
    
    v = thisvert + 1;
    return;
    
end;

% We should check to make sure that nothing weird has happened.

if (size(comp,2) ~= 1)
    error('nextvert: Internal error.');
end;
    
% Now we check whether this component is closed.

if (linkdata.closed(comp(1))) 
    v = linkdata.cstart(comp(1));
else 
    v = 0;   % There is no next vertex!
end;
