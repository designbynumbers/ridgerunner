function adj = adjverts(thisvert,verts,linkdata)

% FUNCTION adjverts returns the adjacent vertices from thisvert in the
% link data structure described by verts and linkdata. There may be either
% one or two of these vertices, if thisvert is at one end of a non-closed
% component. We expect verts to be a V x 3 array of vertex positions.

% First, we test the input arguments.

if (nargin ~= 3) 
    error('adjverts: requires three input arguments, thisvert, verts, and linkdata');    
end;

if (size(verts,2) ~= 3)
    error('adjverts: expects verts to be a V x 3 array of vertex positions.');
end;

if (thisvert > size(verts,1) | thisvert < 1) 
    error('adjverts: thisvert must be a valid vertex number');
end;

% We now go ahead and set up the array to receive the new verts.

adj = [];

% Next, we go ahead and check whether we're at the end of a 
% component. If so, a component start will have index one larger
% than ours, or we will be at the end of the array.

if (thisvert == size(verts,1)) 
    comp = size(linkdata.cstart,1);
else 
    comp = find(linkdata.cstart == thisvert+1)-1;
end;

% If neither of these is true, then we are in the simple case.

if (isempty(comp)) 
    
     cat(adj,thisvert + 1,2);
    
end;

% We should check to make sure that nothing weird has happened.

if (size(comp,2) ~= 1)
    error('adjverts: Internal error finding next vertex.');
end;
    
% Now we check whether this component is closed.
% If so, we wrap around to the first vertex.

if (linkdata.closed(comp(1))) 
    cat(adj,linkdata.cstart(comp(1)),2);
end;

% We now do essentially the same thing to find the previous vertex.

% First, we go ahead and check whether we're at the start of a 
% component. If so, a component start will have the same index as
% our guy, or we will be at the start of the array.

if (thisvert == 1) 
    comp = 1;
else 
    comp = find(linkdata.cstart == thisvert);
end;

% If neither of these is true, then we are in the simple case.

if (isempty(comp)) 
    
     cat(adj,thisvert - 1,2);
    
end;

% We should check to make sure that nothing weird has happened.

if (size(comp,2) ~= 1)
    error('adjverts: Internal error finding previous vertex.');
end;
    
% Now we check whether this component is closed.
% If so, we wrap around to the last vertex. Note that we get
% this vertex by taking the start vertex of the next component
% and subtracting one.

if (linkdata.closed(comp(1))) 
    
    if (comp(1) == size(linkdata.cstart,1))  % We are on the last component.
        cat(adj,size(verts,1),2)
    else                                     % There is a higher-numbered component.
        cat(adj,linkdata.cstart(comp(1)+1)-1,2);
    end;
    
end;

